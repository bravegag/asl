#!/bin/sh

# /***************************************************************/
# /* Created By  : Giovanni Azua Garcia                          */
# /* Created On  : 06 Oct 2007                                   */
# /* Description : A simple batch file to run this project's     */
# /*               maven build script.                           */
# /* Requires    : Maven 3.x installed http://maven.apache.org/  */
# /*             : $M2_HOME env variable properly set            */
# /*             : JDK or JRE at least 1.5 recommended 1.6.0_02  */
# /***************************************************************/
# /* See         : http://perfectjpattern.sourceforge.net/       */
# /***************************************************************/

# check for M2_HOME
if [ ! -x "$M2_HOME" ] ; then
  echo "ERROR: M2_HOME not found in your environment."
  echo "Please set the M2_HOME variable in your environment to match the"
  echo "location of your Maven 2.x installation."
  exit 1
fi

rm -rf ./build.log
touch ./build.log

# show maven version
echo "******************************************************************************************" >> build.log
$M2_HOME/bin/mvn -version                                                                         >> build.log
echo "******************************************************************************************" >> build.log

mvn clean install >> build.log && mvn site -Denable.statsvn=false >> build.log && mvn eclipse:clean eclipse:eclipse -DdownloadSources=true >> build.log
