/**
 * BlockingIOTest.java
 */
package ch.ethz.asl.common.remoting.classic;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

import org.junit.*;
import static org.junit.Assert.*;

import org.perfectjpattern.core.api.behavioral.observer.*;
import org.perfectjpattern.core.api.creational.factorymethod.*;
import org.perfectjpattern.core.api.structural.composite.*;
import org.perfectjpattern.core.structural.composite.*;
import org.slf4j.*;

import com.google.common.collect.*;
import com.google.common.net.HostAndPort;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.common.sql.*;

/**
 * Test suite for the Blocking IO Socket implementation.
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 */
public class BlockingIOTest {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	public static final Logger LOGGER = LoggerFactory.getLogger(BlockingIOTest.class);

	/**
	 * define Factory that creates requests
	 */
	private final IFactoryMethod<RequestData> requestFactory = new IFactoryMethod<RequestData>() {
		@Override
		public RequestData create() {
			RequestData requestData = new RequestData();
			requestData.addWorkload(TpchWorkload.QUERY_1, ImmutableMap.<String, Object> builder()
					.build());
			return requestData;
		}
	};

	/**
	 * define client policy that only ever uses the first middleware
	 */
	private final IClientRequestAssignmentPolicy clientPolicy = new IClientRequestAssignmentPolicy() {
		@Override
		public int nextIndex(RequestData request) {
			return 0;
		}
	};

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Test basic setup: One BlockingIOClient and one BlockingIOServer
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testBasicOneServerOneClient() throws Exception {
		// where the requests are stored
		final BlockingQueue<IJob> requestQueue = new ArrayBlockingQueue<IJob>(1);

		// define simplest Queue provider
		IQueueProvider<IJob> queueProvider = new IQueueProvider<IJob>() {
			@Override
			public void put(IJob job) throws InterruptedException {
				requestQueue.put(job);
			}

            @Override
            public boolean offer(IJob job) {
                return requestQueue.offer(job);
            }
		};

		// ---------------------------------------------
		// Setup the "echo" Server
		// ---------------------------------------------

		final IServer echoServer = new BlockingIOServer("1");
		echoServer.start(5555, queueProvider);

		// ---------------------------------------------
		// Setup the "echo" client
		// ---------------------------------------------

		// connect the client
		final IClient echoClient = new BlockingIOClient(requestFactory, "1", clientPolicy);

		// define Observer that will stop the processing on the first completion
		final Thread testThread = Thread.currentThread();
		IObserver<ResponseData> responseObserver = new IObserver<ResponseData>() {
			@Override
			public void update(ResponseData responseData) {
				assertEquals("Incorrect message received", TpchWorkload.QUERY_1.getSql(),
						responseData.getResults().get(0));
				LOGGER.info("The response message arrive correctly!");

				// stop and wait for the Client
				echoClient.stop();

				// stop the Server
				echoServer.stop();

				// stop the test Thread
				testThread.interrupt();
			}
		};
		echoClient.attach(responseObserver);
		echoClient.connect(ImmutableList.of(HostAndPort.fromParts("localhost", 5555)));

		// ---------------------------------------------
		// Setup the "echo" processor "this Test"
		// ---------------------------------------------

		// blocking call!
		IJob job = requestQueue.take();

		// do the "echo processing"
		ResponseData responseData = new ResponseData();

		// get the Job and process it
		List<String> results = Lists.newArrayList();
		results.add(job.getRequestData().getWorkload().entrySet().iterator().next().getValue());
		responseData.setResults(results);

		// sends the responseData back
		job.getObserver().update(responseData);

		try {
			// wait for one minute
			Thread.sleep(60000);
			fail("something must have gone wrong!");
		}
		catch (InterruptedException exception) {
			// OK
		}
	}

	/**
	 * Test basic setup: One BlockingIOServer and multiple BlockingIOClient
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testOneServerMultipleClients() throws Exception {
		// important parameters for the test
		final int BLOCKING_QUEUE_CAPACITY = 1;
		final int NUMBER_OF_CLIENTS = 1000;

		// where the requests are stored
		final BlockingQueue<IJob> requestQueue = new ArrayBlockingQueue<IJob>(
				BLOCKING_QUEUE_CAPACITY, true);

		IQueueProvider<IJob> queueProvider = new IQueueProvider<IJob>() {
			@Override
			public void put(IJob job) throws InterruptedException {
				requestQueue.put(job);
			}
			
            @Override
            public boolean offer(IJob job) {
                return requestQueue.offer(job);
            }			
		};

		// ---------------------------------------------
		// Setup the "echo" Server
		// ---------------------------------------------

		final IServer echoServer = new BlockingIOServer("1");
		echoServer.start(6666, queueProvider);

		// ---------------------------------------------
		// Setup the "echo" client
		// ---------------------------------------------

		// define multiple clients
		final IComposite<IClient> composite = new Composite<IClient>(IClient.class);
		for (int i = 0; i < NUMBER_OF_CLIENTS; i++) {
			composite
					.add(new BlockingIOClient(requestFactory, String.valueOf(i + 1), clientPolicy));
		}

		final IClient echoClients = composite.getComponent();
		echoClients.setMaxRequests(1);

		// define Observer that will stop the processing on the first completion
		final Thread testThread = Thread.currentThread();
		IObserver<ResponseData> responseObserver = new IObserver<ResponseData>() {
			private final AtomicInteger counter = new AtomicInteger(0);

			@Override
			public void update(ResponseData responseData) {
				assertEquals("Incorrect message received", TpchWorkload.QUERY_1.getSql(),
						responseData.getResults().get(0));

				counter.getAndIncrement();
				LOGGER.info(counter.get() + " clients checked in");
				if (counter.get() == NUMBER_OF_CLIENTS) {
					LOGGER.info("The response messages arrived correctly!");

					// stop and wait for the Client
					echoClients.stop();

					// stop the Server
					echoServer.stop();

					// stop the test Thread
					testThread.interrupt();
				}
			}
		};
		echoClients.attach(responseObserver);
		echoClients.connect(ImmutableList.of(HostAndPort.fromParts("localhost", 6666)));

		// ---------------------------------------------
		// Setup the "echo" processor "this Test"
		// ---------------------------------------------

		// send the responseData back
		for (int i = 0; i < NUMBER_OF_CLIENTS; i++) {
			// blocking call!
			IJob job = requestQueue.take();

			// do the "echo processing"
			ResponseData responseData = new ResponseData();

			// get the Job and process it
			List<String> results = Lists.newArrayList();
			results.add(job.getRequestData().getWorkload().entrySet().iterator().next().getValue());
			responseData.setResults(results);

			// sends the responseData back
			job.getObserver().update(responseData);
		}

		try {
			// wait for ten minutes
			Thread.sleep(600000);
			fail("something must have gone wrong!");
		}
		catch (InterruptedException exception) {
			// OK
		}
	}
}
