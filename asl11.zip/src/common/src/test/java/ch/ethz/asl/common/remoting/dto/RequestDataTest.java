/**
 * RequestDataTest.java
 */
package ch.ethz.asl.common.remoting.dto;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.junit.*;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import ch.ethz.asl.common.sql.TpchMetadata;
import ch.ethz.asl.common.sql.TpchWorkload;

/**
 * Test suite for the the {@link RequestData} implementation.
 * 
 * @author <a href="mailto:zchothia@student.ethz.ch">Chothia Zaheer</a>
 */
public class RequestDataTest {
	private static final Map<TpchWorkload, Boolean> workloadIsQuery = ImmutableMap.of(TpchWorkload.QUERY_1, true,
			TpchWorkload.REFRESH_1_1, false, TpchWorkload.REFRESH_1_2, false, TpchWorkload.REFRESH_2_1, false,
			TpchWorkload.REFRESH_2_2, false);

	private final Map<String, Object> reusableParameters = new ImmutableMap.Builder<String, Object>()
			.put(TpchMetadata.L_ORDERKEY.getColumnName(), 3)
			.put(TpchMetadata.O_TOTALPRICE.getColumnName(), BigDecimal.valueOf(-0.00009)).build();
	private final RequestDataItem queryDataItem = new RequestDataItem(TpchWorkload.QUERY_1, reusableParameters);
	private final RequestDataItem insertDataItem = new RequestDataItem(TpchWorkload.REFRESH_1_1, reusableParameters);
	private final RequestDataItem deleteDataItem = new RequestDataItem(TpchWorkload.REFRESH_2_1, reusableParameters);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Tests that the order of workload items is correctly preserved.
	 */
	@Test
	public void testWorkloadOrder() throws Exception {
		List<RequestDataItem> parameters = Lists.newArrayList();
		parameters.add(queryDataItem);
		parameters.add(insertDataItem);
		parameters.add(deleteDataItem);

		RequestData requestData = new RequestData();
		requestData.addWorkload(queryDataItem.getWorkload(), queryDataItem.getArguments());
		requestData.addWorkload(insertDataItem.getWorkload(), insertDataItem.getArguments());
		requestData.addWorkload(deleteDataItem.getWorkload(), deleteDataItem.getArguments());

		for (int i = 0; i < parameters.size(); i++) {
			assertEquals("Parameters ordering has been violated", parameters.get(i).getWorkload(), requestData
					.getParameters().get(i).getWorkload());
			assertEquals("Parameters ordering has been violated", parameters.get(i).getArguments(), requestData
					.getParameters().get(i).getArguments());
		}

	}

	/**
	 * Tests that queries are correctly detected ({@link isQuery()}).
	 */
	@Test
	public void testIsQuery() {
		final Map<String, Object> emptyParameters = Maps.newHashMap();
		for (Map.Entry<TpchWorkload, Boolean> entry : workloadIsQuery.entrySet()) {
			RequestData requestData = new RequestData();
			requestData.addWorkload(entry.getKey(), emptyParameters);
			assertEquals(requestData.isQuery(), entry.getValue());
		}
	}

	/**
	 * Tests that requests are assigned their corresponding partition index (
	 * {@link getPartitionIndex()}).
	 */
	@Test
	public void testPartitionQuery1() {
		final int numPartitions = 10;
		RequestData requestData = new RequestData();
		requestData.addWorkload(queryDataItem.getWorkload(), queryDataItem.getArguments());

		try {
			requestData.getPartitionIndex(numPartitions);
			fail("Request of type 'query 1' cannot be answered by a single partition");
		} catch (IllegalStateException exception) {
			// Expected behaviour
		}
	}

	@Test
	public void testPartitionRefresh1() {
		final List<Integer> NUM_PARTITIONS = ImmutableList.of(1, 2, 3, 10, 100, 1000, Integer.MAX_VALUE);

		final List<Integer> CUSTKEY = ImmutableList.of(1, 2, 3, 4, 5, 10, 20, 50, 100, 200, 500, 1000, 10000,
				Integer.MAX_VALUE);

		for (Integer numPartitions : NUM_PARTITIONS) {
			for (Integer custkey : CUSTKEY) {
				final Integer partition = custkey % numPartitions;

				RequestData requestData = new RequestData();
				requestData.addWorkload(TpchWorkload.REFRESH_1_1,
						ImmutableMap.of(TpchMetadata.O_CUSTKEY.getColumnName(), (Object) custkey));

				assertEquals("Incorrect partition returned for ORDER (refresh 1)", (int) partition,
						requestData.getPartitionIndex(numPartitions));
			}
		}
	}

	@Test
	public void testPartitionRefresh1LineitemOnly() {
		final int numPartitions = 10;
		final Map<String, Object> emptyParameters = Maps.newHashMap();
		RequestData requestData = new RequestData();
		requestData.addWorkload(TpchWorkload.REFRESH_1_2, emptyParameters);

		try {
			requestData.getPartitionIndex(numPartitions);
			fail("Cannot derive partition of 'refresh 1' request if only LINEITEM present");
		} catch (IllegalStateException exception) {
			// Expected behaviour
		}
	}

	@Test
	public void testPartitionRefresh2() {
		final int numPartitions = 10;
		RequestData requestData = new RequestData();
		requestData.addWorkload(deleteDataItem.getWorkload(), deleteDataItem.getArguments());

		try {
			requestData.getPartitionIndex(numPartitions);
			fail("Request of type 'refresh 2' cannot be answered by a single partition");
		} catch (IllegalStateException exception) {
			// Expected behaviour
		}
	}

	@Test
	public void testPartitionWithNoWorkload() {
		final List<Integer> NUM_PARTITIONS = ImmutableList.of(1, 2, 3, 10, 100, 1000, Integer.MAX_VALUE);
		RequestData requestData = new RequestData();
		for (Integer numPartitions : NUM_PARTITIONS) {
			try {
				requestData.getPartitionIndex(numPartitions);
				fail("Request with no workload should never have a valid partition");
			} catch (IllegalStateException exception) {
				// Expected behaviour
			}
		}
	}
}
