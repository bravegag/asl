/**
 * IJob.java
 */
package ch.ethz.asl.common.remoting;

import org.perfectjpattern.core.api.behavioral.observer.*;

import ch.ethz.asl.common.remoting.dto.*;

/**
 * Abstract definition of a Job, a Job is a tuple of a {@link RequestData} and
 * an {@link IObserver} to be notified once the processing has completed
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 5, 2011
 */
public interface IJob {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Returns the request data
	 *
	 * @return the request data
	 */
	public RequestData getRequestData();

	/**
	 * Returns the {@link IObserver} instance to notify once the request has
	 * been processed.
	 *
	 * @return the {@link IObserver} instance
	 */
	public IObserver<ResponseData> getObserver();

	/**
	 * Destination this {@link Job} must be sent to.
	 */
	enum Destination {
		ALL, ANY, SPECIFIC;
	};

	/**
	 * Returns the {@link Destination}
	 *
	 * @return the {@link Destination}
	 */
	public Destination getDestination();

	/**
	 * Sets the destination
	 *
	 * @param destination
	 *            to set
	 */
	public void setDestination(Destination destination);
}