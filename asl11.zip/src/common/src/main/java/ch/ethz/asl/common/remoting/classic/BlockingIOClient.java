/**
 * BlockingIOClient.java
 */
package ch.ethz.asl.common.remoting.classic;

import java.io.*;
import java.net.*;
import java.util.List;
import java.util.concurrent.atomic.*;

import org.apache.commons.lang.*;
import org.perfectjpattern.core.api.creational.factorymethod.*;
import org.perfectjpattern.core.behavioral.observer.*;
import org.slf4j.*;

import com.google.common.net.HostAndPort;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;

/**
 * Concrete classic Blocking IO implementation of {@link IClient}. The
 * {@link BlockingIOClient} once started can be stopped in three different ways:
 * <ul>
 * <li>Calling {@link #stop()} will signal the underlying {@link Thread} to stop
 * and optionally calling {@link #waitFor()} will block the caller until this
 * happens.</li>
 * <li>Setting the maximum number of requests via {@link #setMaxRequests(int)},
 * the client will stop once maxRequests are sent and received</li>
 * <li>By returning <code>null</code> as {@link RequestData} via the Request
 * {@link IFactoryMethod}</li>
 * </ul>
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @author <a href="mailto:zchothia@student.ethz.ch">Chothia Zaheer</a>
 */
public class BlockingIOClient extends Subject<ResponseData> implements IClient, Runnable {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	public static final Logger LOGGER = LoggerFactory.getLogger(BlockingIOClient.class);

	/**
	 * Client socket.
	 */
	private Socket[] clientSockets = null;

	/**
	 * Client Thread
	 */
	private Thread socketThread = null;

	/**
	 * Factory that creates requests
	 */
	private IFactoryMethod<RequestData> requestFactory = null;
	private ObjectInputStream[] in = null;
	private ObjectOutputStream[] out = null;
	private final String clientId;
	private final IClientRequestAssignmentPolicy assignmentPolicy;
	private int maxRequests = Integer.MAX_VALUE;
	private int numberOfMiddlewares;
	private final AtomicBoolean stopRequested = new AtomicBoolean(false);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs an instance of {@link BlockingIOClient}
	 * 
	 * @param requestFactory
	 * @param clientId
	 * @param assignmentPolicy
	 */
	public BlockingIOClient(IFactoryMethod<RequestData> requestFactory, String clientId,
			IClientRequestAssignmentPolicy assignmentPolicy) {
		Validate.notNull(requestFactory, "'requestFactory' must not be null");
		Validate.notEmpty(clientId, "'clientId' must not be null or empty");
		Validate.notNull(assignmentPolicy, "'assignmentPolicy' must not be null");

		this.requestFactory = requestFactory;
		this.clientId = clientId;
		this.assignmentPolicy = assignmentPolicy;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void connect(List<HostAndPort> hosts) {
		Validate.notEmpty(hosts, "'hosts' must not be null nor empty");

		numberOfMiddlewares = hosts.size();
		clientSockets = new Socket[numberOfMiddlewares];
		out = new ObjectOutputStream[numberOfMiddlewares];
		in = new ObjectInputStream[numberOfMiddlewares];

		try {
			LOGGER.debug("attempting to connect ...");

			for (int i = 0; i < numberOfMiddlewares; i++) {
				HostAndPort host = hosts.get(i);
				clientSockets[i] = new Socket(host.getHostText(), host.getPort());
			}

			LOGGER.debug("connected!");
		}
		catch (Exception exception) {
			exception.printStackTrace();
			LOGGER.error("", exception);
			throw new RuntimeException(exception);
		}

		socketThread = new Thread(this, getClass().getSimpleName() + "-" + clientId + "-Thread");
		socketThread.start();

		LOGGER.debug("client-thread started");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void run() {
		try {
			LOGGER.debug("getting out/in streams");
			for (int i = 0; i < numberOfMiddlewares; ++i) {
				out[i] = new ObjectOutputStream(clientSockets[i].getOutputStream());
				in[i] = new ObjectInputStream(clientSockets[i].getInputStream());
			}
			LOGGER.debug("done getting out/in streams");

			LOGGER.debug("sending clientId");
			for (int i = 0; i < numberOfMiddlewares; ++i) {
				out[i].writeObject(clientId);
			}
			LOGGER.debug("clientId sent");

			LOGGER.debug("starting client loop ...");
			final int totalRequests = maxRequests == Integer.MAX_VALUE ? Integer.MAX_VALUE
					: maxRequests * numberOfMiddlewares;
			for (int r = 0; r < totalRequests && !stopRequested.get(); ++r) {
				LOGGER.debug("creating request ...");
				RequestData requestData = requestFactory.create();

				// is requestData ready to send?
				if (requestData != null) {
					LOGGER.debug("request created");

					// get the next index according to the given assignment policy
					int index = assignmentPolicy.nextIndex(requestData);
					assert (0 <= index && index < numberOfMiddlewares);
					LOGGER.debug("request will be sent to middleware {}", index);

					out[index].writeObject(requestData);
					LOGGER.debug("request sent!");

					// block-wait for response data
					ResponseData responseData = (ResponseData) in[index].readObject();
					LOGGER.debug("response arrived");

					// process response
					notifyObservers(responseData);
				}
				else {
					// if we got a null requestData is also interpreted as stop
					// request
					LOGGER.debug("null requestData, client {} stopping ...", clientId);
					break;
				}
			}

			if (!stopRequested.get()) {
				LOGGER.debug("client finished " + clientId);
			}
		}
		catch (Throwable exception) {
			exception.printStackTrace();
			LOGGER.error("failed", exception);
			throw new RuntimeException(exception);
		}
		finally {
			// close the sockets directly
			for (int i = 0; i < numberOfMiddlewares; i++) {
				try {
					clientSockets[i].close();
				}
				catch (Throwable exception) {
					exception.printStackTrace();
				}
			}

			if (stopRequested.get()) {
				LOGGER.debug("stop completed client " + clientId + " /");
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void stop() {
		stopRequested.set(true);

		LOGGER.debug("stop requested client " + clientId + " \\");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void waitFor() {
		// watch for dangerous mistakes
		if (Thread.currentThread() != socketThread) {
			try {
				LOGGER.debug("waiting for client {} to surrender", clientId);
				socketThread.join();
			}
			catch (InterruptedException exception) {
				exception.printStackTrace();
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public final void setMaxRequests(int maxRequests) {
		this.maxRequests = maxRequests;
	}
}
