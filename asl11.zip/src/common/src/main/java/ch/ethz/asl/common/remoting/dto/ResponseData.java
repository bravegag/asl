/**
 * MessageData.java
 */
package ch.ethz.asl.common.remoting.dto;

import java.io.*;
import java.util.*;

/**
 * Serializable Response DTO
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @author <a href="mailto:zchothia@student.ethz.ch">Chothia Zaheer</a>
 */
public class ResponseData extends IdentifyableData implements Serializable {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private static final long serialVersionUID = -968998255569678923L;
	private String error;
	private List<String> results;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	public final void setResults(List<String> results) {
		this.results = results;
	}

	/**
	 * Returns the error
	 *
	 * @return the error
	 */
	public final String getError() {
		return error;
	}

	/**
	 * Sets the error
	 *
	 * @param error
	 *            to set
	 */
	public final void setError(String error) {
		this.error = error;
	}

	/**
	 * Returns the results
	 *
	 * @return the results
	 */
	public final List<String> getResults() {
		return results;
	}

	/**
	 * Returns true if this response is the result of a successful completion,
	 * false otherwise.
	 *
	 * @return true if this response is the result of a successful completion,
	 *         false otherwise.
	 */
	public final boolean isSuccessful() {
		return error == null;
	}
}
