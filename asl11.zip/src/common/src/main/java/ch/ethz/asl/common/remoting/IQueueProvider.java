/**
 * IQueueProvider.java
 */
package ch.ethz.asl.common.remoting;

import java.util.concurrent.*;

/**
 * Abstract definition of application "Queueing services". In most cases this
 * interface is going to be simply backed by a {@link BlockingQueue}
 * implementation but in some cases there may be multiple {@link BlockingQueue}. <br/>
 * <br/>
 * The idea is to have multiple implementations behind that best match the given
 * scenario performance-wise i.e. only one {@link BlockingQueue} or multiple
 * {@link BlockingQueue} e.g. one per database etc.
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 3, 2011
 */
public interface IQueueProvider<J extends IJob> {
	/**
	 * Enqueues the given {@link IJob} into the Queue. The method is consistent
	 * with {@link BlockingQueue#put(Object)} as it will block the caller until
	 * there is a free slot in the underlying {@link BlockingQueue}
	 *
	 * @param job
	 *            The {@link IJob} to put in the Queue.
	 */
	public void put(J job) throws InterruptedException;

	/**
	 * Returns true if the given {@link IJob} was successfully enqueued, false
	 * otherwise. Enqueues the given {@link IJob} into the Queue. The method is
	 * consistent with {@link BlockingQueue#offer(Object)} as it will not block
	 * the caller.
	 *
	 * @param job
	 *            The {@link IJob} to put in the Queue.
	 * @return true if the given {@link IJob} was successfully enqueued, false
	 *          otherwise.
	 */
	public boolean offer(J job);
}
