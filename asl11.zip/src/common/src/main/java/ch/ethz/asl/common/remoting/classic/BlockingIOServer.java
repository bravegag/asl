/**
 * BlockingIOServer.java
 */
package ch.ethz.asl.common.remoting.classic;

import java.io.*;
import java.net.*;
import java.util.*;

import org.apache.commons.lang.*;
import org.slf4j.*;

import com.google.common.collect.*;

import ch.ethz.asl.common.remoting.*;

/**
 * Concrete classic Blocking IO implementation of {@link IServer}
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @author <a href="mailto:zchothia@student.ethz.ch">Chothia Zaheer</a>
 */
public class BlockingIOServer implements IServer, Runnable {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	public static final Logger LOGGER = LoggerFactory.getLogger(BlockingIOServer.class);

	/**
	 * Need to keep track of the clients, so we can shut them down.
	 */
	private final List<ThreadPerClientSocket> clients = Lists.newArrayList();

	/**
	 * Server socket to accept incoming connections.
	 */
	private ServerSocket serverSocket = null;

	/**
	 * Queue where the requests are stored and outside processed.
	 */
	private IQueueProvider<IJob> queueProvider = null;

	/**
	 * Thread dedicated to listening for incoming client Socket connections
	 */
	private Thread listenerThread = null;

	/**
	 * Id of this server, a unique user-friendly label for the Logging e.g. "1"
	 */
	private final String serverId;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link BlockingIOServer}
	 *
	 * @param serverId
	 */
	public BlockingIOServer(String serverId) {
		Validate.notNull(serverId, "'serverId' must not be null");

		this.serverId = serverId;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void start(int port, IQueueProvider<IJob> queueProvider) {
		Validate.isTrue(port > 0, "'port' must be greater than zero");
		Validate.notNull(queueProvider, "'queueProvider' must not be null");

		try {
			LOGGER.debug("server starting ...");
			serverSocket = new ServerSocket(port);
		}
		catch (IOException exception) {
			exception.printStackTrace();
			throw new RuntimeException(exception);
		}

		this.queueProvider = queueProvider;

		// start this Thread
		listenerThread = new Thread(this, getClass().getSimpleName() + "-Listener-Thread");
		listenerThread.start();

		LOGGER.debug("server started");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void stop() {
		LOGGER.debug("stop requested \\");

		try {
			// close the socket directly
			serverSocket.close();
		}
		catch (Throwable exception) {
			exception.printStackTrace();
		}

		// interrupt the thread
		listenerThread.interrupt();

		// close the clients
		for (ThreadPerClientSocket client : clients) {
			client.stop();
		}

		LOGGER.debug("stop completed /");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void run() {
		try {
			LOGGER.debug("listening for connections ...");
			while (true) {
				// this call is blocking
				Socket clientSocket = serverSocket.accept();
				LOGGER.debug("accepting connection for client '"
						+ clientSocket.getInetAddress().getHostName() + "'");

				ThreadPerClientSocket client = new ThreadPerClientSocket(serverId, clientSocket,
						queueProvider);
				clients.add(client);

				// start this new client
				client.start();
			}
		}
		catch (SocketException exception) {
			LOGGER.warn("operation failed, apparently a stop request");
		}
		catch (Throwable exception) {
			exception.printStackTrace();
			LOGGER.error("failed", exception);
			throw new RuntimeException(exception);
		}
	}
}
