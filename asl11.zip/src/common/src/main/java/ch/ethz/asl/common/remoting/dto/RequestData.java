/**
 * MessageData.java
 */
package ch.ethz.asl.common.remoting.dto;

import java.io.*;
import java.util.*;

import org.apache.commons.lang.*;

import ch.ethz.asl.common.sql.*;

import com.google.common.collect.*;

/**
 * Serializable Request DTO
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @author <a href="mailto:zchothia@student.ethz.ch">Chothia Zaheer</a>
 */
public class RequestData extends IdentifyableData implements Serializable {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private static final long serialVersionUID = 7535426063636346047L;
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");

	/**
	 * Workload as a unique set of {@link TpchWorkload} elements. The SQL
	 * strings per {@link TpchWorkload} are included once
	 */
	private Map<TpchWorkload, String> workload = Maps.newHashMap();

	/**
	 * Parameters for the different {@link TpchWorkload}. There are many
	 * parameters as there are repetitions of the same {@link TpchWorkload}
	 * workload
	 */
	private List<RequestDataItem> parameters = Lists.newArrayList();

	/**
	 * Keeps track whether this is a Query RequestData or not. It is true by
	 * default unless proven otherwise
	 */
	private boolean query = true;

	/**
	 * Reusable and Thread-local {@link StringBuilder} instance
	 */
	private static final ThreadLocal<StringBuilder> STRING_BUILDER = new ThreadLocal<StringBuilder>();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Adds additional workload and the corresponding parameters
	 *
	 * @param additionalWorkload
	 *            Additional workload to add
	 * @param additionalParameters
	 *            Parameters corresponding to the additional workload
	 */
	public void addWorkload(TpchWorkload additionalWorkload,
			Map<String, Object> additionalParameters) {
		// make sure that the SQL is always sent as part of the request
		// this is to make the requests look as realistic as possible
		workload.put(additionalWorkload, additionalWorkload.getSql());

		// populate the parameters List
		parameters.add(new RequestDataItem(additionalWorkload, additionalParameters));

		// check whether this is a query request or not
		query = query && additionalWorkload.isQuery();
	}

	/**
	 * Returns the partition index for this request. This only makes sense for
	 * requests on the partitioning attribute.
	 *
	 * The returned value is in the range i.e. [0 .. numPartitions) or
	 * -1 otherwise.
	 *
	 * @param numPartitions
	 *            Number of database partitions
	 *
	 * @return the partition index for this request or -1 otherwise.
	 */
	public int getPartitionIndex(int numPartitions) {
		Validate.isTrue(numPartitions > 0, "'numPartitions' must be positive");

		int partitionIndex = 0;
		for (RequestDataItem requestDataItem : parameters) {
			TpchWorkload workload = requestDataItem.getWorkload();
			if (workload.getType() != TpchWorkload.Type.INSERT)
				continue;

			Map<String, Object> arguments = requestDataItem.getArguments();
			Integer custKey = (Integer) arguments.get(TpchMetadata.O_CUSTKEY.getColumnName());
			if (custKey != null) {
				// This needs to match the database partitioning criteria
				// See 'InitDBTask._partition_data.partition_customer' in
				// 'scripts/manage.py'
				partitionIndex = custKey % numPartitions;
				assert (0 <= partitionIndex && partitionIndex <= numPartitions);
				return partitionIndex;
			}
		}
		throw new IllegalStateException("Cannot derive partition index without CUSTKEY");
	}

	/**
	 * Returns the parameters
	 *
	 * @return the parameters
	 */
	public final List<RequestDataItem> getParameters() {
		return parameters;
	}

	/**
	 * Returns the workload
	 *
	 * @return the workload
	 */
	public final Map<TpchWorkload, String> getWorkload() {
		return workload;
	}

	/**
	 * Returns true if this is a Query {@link RequestData}, false otherwise
	 *
	 * @return true if this is a Query {@link RequestData}, false otherwise
	 */
	public final boolean isQuery() {
		return query;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		// reusable Thread-safe StringBuilder instance
		if (STRING_BUILDER.get() == null) {
			STRING_BUILDER.set(new StringBuilder());
		}
		final StringBuilder builder = STRING_BUILDER.get();
		builder.setLength(0);

		builder.append(LINE_SEPARATOR);
		builder.append("Id=[");
		builder.append(getId());
		builder.append(']');
		builder.append(LINE_SEPARATOR);
		builder.append("workload=[");
		builder.append(workload.toString());
		builder.append(']');
		builder.append(LINE_SEPARATOR);
		builder.append("parameters=");
		builder.append(parameters.toString());
		builder.append(LINE_SEPARATOR);

		return builder.toString();
	}
}
