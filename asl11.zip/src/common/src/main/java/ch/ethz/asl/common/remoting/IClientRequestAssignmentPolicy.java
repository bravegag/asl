/**
 * IClientRequestAssignmentPolicy.java
 */
package ch.ethz.asl.common.remoting;

import ch.ethz.asl.common.remoting.dto.RequestData;

/**
 * Abstract definition of client request assignment policy.
 *
 * @author <a href="mailto:zchothia@student.ethz.ch">Zaheer Chothia</a>
 * @since Oct 17, 2011
 */
public interface IClientRequestAssignmentPolicy {
	/**
	 * Returns the index for the destination host of this request according to
	 * this dispatch policy. The returned index is in [0, numberOfMiddlewares).
	 * The first host is assumed to be the update middleware.
	 *
	 * @param requestData
	 *            The {@link RequestData} in consideration
	 * @return index for the destination host of this request
	 */
	public int nextIndex(RequestData requestData);
}
