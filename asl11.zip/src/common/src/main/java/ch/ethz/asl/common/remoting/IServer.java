/**
 * IServer.java
 */
package ch.ethz.asl.common.remoting;

import org.perfectjpattern.core.api.behavioral.observer.*;

import ch.ethz.asl.common.remoting.dto.*;

/**
 * Abstract definition of Server
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @author <a href="mailto:zchothia@student.ethz.ch">Chothia Zaheer</a>
 */
public interface IServer {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Starts the server using the given port. All incoming requests are
	 * enqueued in the given queueProvider. The Job includes a reference to an
	 * {@link IObserver} that must be notified once the Job has been processed.
	 * The notification includes an instance of the corresponding
	 * {@link ResponseData}.
	 *
	 * @param port
	 *            Port to bind to.
	 * @param queueProvider
	 *            The Queue provider to write the Jobs to.
	 */
	public void start(int port, IQueueProvider<IJob> queueProvider);

	/**
	 * Stop the server.
	 */
	public void stop();
}
