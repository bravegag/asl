/**
 * RequestDataItem.java
 */
package ch.ethz.asl.common.remoting.dto;

import java.io.*;
import java.util.*;

import org.apache.commons.lang.*;

import ch.ethz.asl.common.sql.*;

/**
 * Represents one Item of the {@link RequestData} DTO i.e. this is a tuple of a
 * {@link TpchWorkload} and the needed arguments to execute it.
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 15, 2011
 */
public class RequestDataItem implements Serializable {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private static final long serialVersionUID = 2979854508321616208L;
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");

	private TpchWorkload workload;
	private Map<String, Object> arguments;

	/**
	 * Reusable and Thread-local {@link StringBuilder} instance
	 */
	private static final ThreadLocal<StringBuilder> STRING_BUILDER = new ThreadLocal<StringBuilder>();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Default Constructor {@link RequestDataItem}
	 */
	public RequestDataItem() {
		// empty
	}

	/**
	 * Constructor {@link RequestDataItem}
	 *
	 * @param workload
	 * @param arguments
	 */
	public RequestDataItem(TpchWorkload workload, Map<String, Object> arguments) {
		Validate.notNull(workload, "'workload' must not be null");
		Validate.notNull(arguments, "'arguments' must not be null");

		this.workload = workload;
		this.arguments = arguments;
	}

	/**
	 * Returns the workload
	 *
	 * @return the workload
	 */
	public final TpchWorkload getWorkload() {
		return workload;
	}

	/**
	 * Returns the arguments
	 *
	 * @return the arguments
	 */
	public final Map<String, Object> getArguments() {
		return arguments;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		// reusable Thread-safe StringBuilder instance
		if (STRING_BUILDER.get() == null) {
			STRING_BUILDER.set(new StringBuilder());
		}
		final StringBuilder builder = STRING_BUILDER.get();
		builder.setLength(0);

		builder.append(workload);
		builder.append(LINE_SEPARATOR);
		builder.append(arguments);
		builder.append(LINE_SEPARATOR);

		return builder.toString();
	}
}
