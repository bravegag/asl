/**
 * ClientSocketRunnable.java
 */
package ch.ethz.asl.common.remoting.classic;

import java.io.*;
import java.net.*;
import java.util.concurrent.locks.*;

import org.apache.commons.lang.*;
import org.perfectjpattern.core.api.behavioral.observer.*;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;

/**
 * A Runnable implementation that corresponds to one Client Socket
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @author <a href="mailto:zchothia@student.ethz.ch">Chothia Zaheer</a>
 */
public class ThreadPerClientSocket implements Runnable, IObserver<ResponseData> {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	public static final Logger LOGGER = LoggerFactory.getLogger(ThreadPerClientSocket.class);

	private final Lock responseReadyLock = new ReentrantLock();
	private final Condition responseReady = responseReadyLock.newCondition();
	private final Socket clientSocket;
	private final IQueueProvider<IJob> queueProvider;
	private final String serverId;
	private static final long NANO_TO_MILLISECONDS = 1000000;

	private ResponseData responseData = null;
	private Thread socketThread = null;
	private ObjectInputStream in = null;
	private ObjectOutputStream out = null;
	private String clientId = null;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link ThreadPerClientSocket}
	 *
	 * @param serverId
	 * @param clientSocket
	 * @param queueProvider
	 */
	public ThreadPerClientSocket(String serverId, Socket clientSocket,
			IQueueProvider<IJob> queueProvider) {
		Validate.notNull(serverId, "'serverId' must not be null");
		Validate.notNull(clientSocket, "'clientSocket' must not be null");
		Validate.notNull(queueProvider, "'queueProvider' must not be null");

		this.serverId = serverId;
		this.clientSocket = clientSocket;
		this.queueProvider = queueProvider;
	}

	/**
	 * Starts this Runnable
	 */
	public void start() {
		// set the initial Thread name
		socketThread = new Thread(this, getClass().getSimpleName() + "-Thread");
		socketThread.start();

		LOGGER.debug("client-socket started, waiting for data ...");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void run() {
		try {
			LOGGER.debug("getting out/in streams ...");
			out = new ObjectOutputStream(clientSocket.getOutputStream());
			in = new ObjectInputStream(clientSocket.getInputStream());
			LOGGER.debug("done getting out/in streams");

			LOGGER.debug("reading clientId ...");
			clientId = (String) in.readObject();
			LOGGER.debug("clientId read");

			// update the Thread name using the incoming clientId
			Thread.currentThread().setName(getClass().getSimpleName() + "-" + clientId + "-Thread");

			LOGGER.debug("starting thread-per-client loop ...");
			while (true) {
				// block-wait for request data
				RequestData requestData = (RequestData) in.readObject();

				long currentTime = System.nanoTime();
				long elapsedTime = currentTime;
				currentTime /= NANO_TO_MILLISECONDS;
				LOGGER.info(
						"received request jobId=[{}] clientId=[{}] serverId=[{}] time=[{}] request={}",
						new Object[] { requestData.getId(), clientId, serverId, currentTime,
								requestData.getWorkload().keySet() });

				// setup the callback
				IObserver<ResponseData> observer = this;
				IJob job = new Job(requestData, observer);

				// initialize responseData to null
				responseData = null;

				// wait until responseData is ready
				responseReadyLock.lock();
				try {
					LOGGER.debug("enqueing ... ");
					queueProvider.put(job);
					LOGGER.debug("done enqueing request");

					LOGGER.debug("waiting for response ...");
					while (responseData == null) {
						responseReady.await();
					}
					LOGGER.debug("response received");
				}
				finally {
					responseReadyLock.unlock();
				}

				// data ready? send
				out.writeObject(responseData);

				// measure response time
				currentTime = System.nanoTime();
				elapsedTime = (currentTime - elapsedTime) / NANO_TO_MILLISECONDS;
				currentTime /= NANO_TO_MILLISECONDS;

				// print to INFO only in case it was successful
				if (responseData.isSuccessful()) {
					LOGGER.info(
							"sending response jobId=[{}] clientId=[{}] serverId=[{}] time=[{}] request={} elapsed=[{}ms]",
							new Object[] { responseData.getId(), clientId, serverId, currentTime,
									requestData.getWorkload().keySet(), Long.valueOf(elapsedTime) });
				}

				LOGGER.debug("response sent!");
			}
		}
		catch (SocketException exception) {
			LOGGER.warn("operation failed, apparently a stop request");
		}
		catch (EOFException exception) {
			LOGGER.warn("operation failed, apparently a stop request");
		}
		catch (InterruptedException exception) {
			LOGGER.warn("operation failed, apparently a stop request");
		}
		catch (Throwable exception) {
			exception.printStackTrace();
			LOGGER.error("failed", exception);
			throw new RuntimeException(exception);
		}
	}

	/**
	 * Stops the current thread more gracefully by cleaning up e.g. releasing
	 * all the resources.
	 */
	public void stop() {
		LOGGER.debug("stop requested client " + clientId + " \\");

		try {
			// close the socket directly
			clientSocket.close();
		}
		catch (Throwable exception) {
			exception.printStackTrace();
		}

		// interrupt the thread
		socketThread.interrupt();

		LOGGER.debug("stop completed client " + clientId + " /");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void update(ResponseData data) {
		responseReadyLock.lock();
		try {
			responseData = data;

			// signal that the responseData is ready
			responseReady.signal();

			LOGGER.debug("request processed, sending response ...");
		}
		finally {
			responseReadyLock.unlock();
		}
	}
}
