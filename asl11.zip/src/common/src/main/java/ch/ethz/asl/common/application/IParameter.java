/**
 * IParameter.java
 */
package ch.ethz.asl.common.application;

/**
 * Abstract definition of an application parameter
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 */
public interface IParameter {
	/**
	 * Returns the parameter name in lower case
	 *
	 * @return the parameter name in lower case
	 */
	public String getParameter();

	/**
	 * Returns the example for this parameter
	 *
	 * @return the example for this parameter
	 */
	public String getExample();
}
