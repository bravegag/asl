/**
 * Job.java
 */
package ch.ethz.asl.common.remoting;

import org.apache.commons.lang.*;
import org.perfectjpattern.core.api.behavioral.observer.*;

import ch.ethz.asl.common.remoting.dto.*;

/**
 * Concrete implementation of {@link IJob} <br/>
 * <br/>
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @author <a href="mailto:zchothia@student.ethz.ch">Chothia Zaheer</a>
 * @see IJob
 */
public class Job implements IJob {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private final RequestData requestData;
	private final IObserver<ResponseData> observer;
	private IJob.Destination destination;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link Job}
	 *
	 * @param requestData
	 *            {@link RequestData} received for processing
	 * @param observer
	 *            {@link IObserver} to notify once the {@link RequestData} has
	 *            been processed
	 */
	public Job(RequestData requestData, IObserver<ResponseData> observer) {
		Validate.notNull(requestData, "'requestData' must not be null");
		Validate.notNull(observer, "'observer' must not be null");

		this.requestData = requestData;
		this.observer = observer;
	}

	/**
	 * Constructs a {@link Job}
	 *
	 * @param requestData
	 *            {@link RequestData} received for processing
	 * @param observer
	 *            {@link IObserver} to notify once the {@link RequestData} has
	 *            been processed
	 * @param destination
	 * 			   IJob.Destination
	 */
	public Job(RequestData requestData, IObserver<ResponseData> observer, IJob.Destination destination) {
		this(requestData, observer);

		Validate.notNull(destination, "'destination' must not be null");

		this.destination = destination;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public final RequestData getRequestData() {
		return requestData;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public final IObserver<ResponseData> getObserver() {
		return observer;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Destination getDestination() {
		return destination;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setDestination(Destination destination) {
		this.destination = destination;
	}
}
