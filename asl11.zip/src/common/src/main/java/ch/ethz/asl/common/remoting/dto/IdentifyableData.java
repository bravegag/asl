/**
 * IdentifyableData.java
 */
package ch.ethz.asl.common.remoting.dto;

import java.io.*;

/**
 * {@link Serializable} identifyable Data Transfer Object (DTO)
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 16, 2011
 */
public class IdentifyableData implements Serializable {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private static final long serialVersionUID = 4046932503146817180L;

	/**
	 * The id
	 */
	private String id;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Returns the id
	 *
	 * @return the id
	 */
	public final String getId() {
		return id;
	}

	/**
	 * Sets the id
	 *
	 * @param id
	 *            the id to set
	 */
	public final void setId(String id) {
		this.id = id;
	}
}
