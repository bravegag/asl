/**
 * TpchMetadata.java
 */
package ch.ethz.asl.common.sql;

import java.math.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.Date;

import org.apache.commons.lang.*;

import com.google.common.collect.ImmutableList;

/**
 * Contains all the TPCH column names with appropriate type information and
 * offers e.g. type conversion facilities to ease importing data files.
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 15, 2011
 */
public enum TpchMetadata {
	O_ORDERKEY(Integer.class),
	O_CUSTKEY(Integer.class),
	O_ORDERSTATUS(String.class),
	O_TOTALPRICE(BigDecimal.class),
	O_ORDERDATE(Timestamp.class),
	O_ORDERPRIORITY(String.class),
	O_CLERK(String.class),
	O_SHIPPRIORITY(Integer.class),
	O_COMMENT(String.class),
	L_ORDERKEY(Integer.class),
	L_PARTKEY(Integer.class),
	L_SUPPKEY(Integer.class),
	L_LINENUMBER(Integer.class),
	L_QUANTITY(BigDecimal.class),
	L_EXTENDEDPRICE(BigDecimal.class),
	L_DISCOUNT(BigDecimal.class),
	L_TAX(BigDecimal.class),
	L_RETURNFLAG(String.class),
	L_LINESTATUS(String.class),
	L_SHIPDATE(Timestamp.class),
	L_COMMITDATE(Timestamp.class),
	L_RECEIPTDATE(Timestamp.class),
	L_SHIPINSTRUCT(String.class),
	L_SHIPMODE(String.class),
	L_COMMENT(String.class);

	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	public static final List<TpchMetadata> ORDER_COLUMNS = ImmutableList.of(O_ORDERKEY, O_CUSTKEY,
			O_ORDERSTATUS, O_TOTALPRICE, O_ORDERDATE, O_ORDERPRIORITY, O_CLERK, O_SHIPPRIORITY,
			O_COMMENT);
	public static final List<TpchMetadata> LINEITEM_COLUMNS = ImmutableList.of(L_ORDERKEY,
			L_PARTKEY, L_SUPPKEY, L_LINENUMBER, L_QUANTITY, L_EXTENDEDPRICE, L_DISCOUNT, L_TAX,
			L_RETURNFLAG, L_LINESTATUS, L_SHIPDATE, L_COMMITDATE, L_RECEIPTDATE, L_SHIPINSTRUCT,
			L_SHIPMODE, L_COMMENT);

	private final Class<?> type;
	private final DateFormat TIMESTAMP_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Returns the correct {@link Object} type for the given value
	 *
	 * @param value
	 *            The String value
	 * @return the correct {@link Object} type for the given value
	 * @throws UnsupportedOperationException
	 * @throws ParseException
	 */
	public Object toObject(String value) throws UnsupportedOperationException, ParseException {
		Validate.notNull(value, "'value' must not be null");

		Object result = null;

		if (String.class.equals(type)) {
			result = value;
		}
		else if (Timestamp.class.equals(type)) {
			result = new Timestamp(((Date) TIMESTAMP_FORMAT.parseObject(value.trim())).getTime());
		}
		else if (Integer.class.equals(type)) {
			result = Integer.valueOf(value.trim());
		}
		else if (BigDecimal.class.equals(type)) {
			result = new BigDecimal(value.trim());
		}
		else {
			throw new UnsupportedOperationException("unsupported type for value '" + value + "'");
		}

		return result;
	}

	/**
	 * Return this as a column name i.e. lower case
	 *
	 * @return this as a column name i.e. lower case
	 */
	public final String getColumnName() {
		return this.toString().toLowerCase();
	}

	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	/**
	 * Constructs an instance of {@link TpchMetadata} using the appropriate type
	 * information
	 *
	 * @param type
	 */
	private TpchMetadata(Class<?> type) {
		Validate.notNull(type, "'type' must not be null");

		this.type = type;
	}
}
