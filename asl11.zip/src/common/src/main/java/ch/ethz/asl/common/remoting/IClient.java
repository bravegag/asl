/**
 * IClient.java
 */
package ch.ethz.asl.common.remoting;

import java.util.*;

import org.perfectjpattern.core.api.behavioral.observer.*;
import org.perfectjpattern.core.api.creational.factorymethod.*;

import ch.ethz.asl.common.remoting.dto.*;

import com.google.common.net.*;

/**
 * Abstract definition of Client. Concrete {@link IClient} implementations must
 * implement and adhere to the following three simple stop criteria:
 * <ul>
 * <li>Calling {@link #stop()} will signal the underlying {@link Thread} to stop
 * and optionally calling {@link #waitFor()} will block the caller until this
 * happens.</li>
 * <li>Setting the maximum number of requests via {@link #setMaxRequests(int)},
 * the client will stop once maxRequests are sent and received</li>
 * <li>By returning <code>null</code> as {@link RequestData} via the Request
 * {@link IFactoryMethod}</li>
 * </ul>
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @author <a href="mailto:zchothia@student.ethz.ch">Chothia Zaheer</a>
 */
public interface IClient extends ISubject<ResponseData> {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Connect to the servers identified by the given {@link List} of
	 * {@link HostAndPort} instances.
	 * 
	 * @param hosts
	 */
	public void connect(List<HostAndPort> hosts);

	/**
	 * Sets the maximum number of requests to submit for this {@link IClient}.
	 * The default value is {@link Integer#MAX_VALUE}
	 * 
	 * @param maxRequests
	 *            maximum number of requests to submit.
	 */
	public void setMaxRequests(int maxRequests);

	/**
	 * Requests this client to stop its communication.
	 */
	public void stop();

	/**
	 * Make the calling {@link Thread} to wait for this client to stop
	 */
	public void waitFor();
}
