/**
 * TpchWorkload.java
 */
package ch.ethz.asl.common.sql;

import java.sql.*;

/**
 * Enum containing the TPCH Workload i.e. all SQL statements supported.
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 4, 2011
 */
public enum TpchWorkload {
	QUERY_1(Type.QUERY),
	REFRESH_1_1(Type.INSERT),
	REFRESH_1_2(Type.INSERT),
	REFRESH_2_1(Type.DELETE),
	REFRESH_2_2(Type.DELETE);

	// ------------------------------------------------------------------------
	// static members
	// ------------------------------------------------------------------------
	/**
	 * Section 2.4.1, page 28 - Pricing Summary Report Query (Q1)
	 *
	 * For the ASL course we are permitted to drop the ORDER BY and GROUP BY
	 * clause.  Note that doing so implies that the attributes 'l_returnflag'
	 * and 'l_linestatus' should also be dropped.
	 */
	private static String QUERY_1_TEMPLATE =
			"select " +
				"l_returnflag, " +
		    	"l_linestatus, " +
		    	"sum(l_quantity) as sum_qty, " +
		    	"sum(l_extendedprice) as sum_base_price, " +
		    	// different than TPCH, needed for computing avg of l_discount
		    	"sum(l_discount) as sum_disc, " +
		    	"sum(l_extendedprice * (1 - l_discount)) as sum_disc_price, " +
		    	"sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge, " +
		    	"avg(l_quantity) as avg_qty, " +
		    	"avg(l_extendedprice) as avg_price, " +
		    	"avg(l_discount) as avg_disc, " +
		    	"count(*) as count_order " +
		    "from " +
		    	"lineitem " +
		    "where " +
		    	"l_shipdate <= date '1998-12-01' - cast (:delta as interval) " +
	    	"group by " +
	    		"l_returnflag, l_linestatus " +
    		"order by " +
    			"l_returnflag, l_linestatus";

	/**
	 * Section 2.6, page 67 - New Sales Refresh Function (RF1)
	 */
	private static String REFRESH_1_1_TEMPLATE =
			"insert into orders " +
				"(o_orderkey, " +
				 "o_custkey, " +
				 "o_orderstatus, " +
				 "o_totalprice, " +
				 "o_orderdate, " +
				 "o_orderpriority, " +
				 "o_clerk, " +
				 "o_shippriority, " +
				 "o_comment) " +
		 	"values " +
				"(:o_orderkey, " +
				 ":o_custkey, " +
				 ":o_orderstatus, " +
				 ":o_totalprice, " +
				 ":o_orderdate, " +
				 ":o_orderpriority, " +
				 ":o_clerk, " +
				 ":o_shippriority, " +
				 ":o_comment)";

	private static String REFRESH_1_2_TEMPLATE =
			"insert into lineitem " +
				"(l_orderkey, " +
				 "l_partkey, " +
				 "l_suppkey, " +
				 "l_linenumber, " +
				 "l_quantity, " +
				 "l_extendedprice, " +
				 "l_discount, " +
				 "l_tax, " +
				 "l_returnflag, " +
				 "l_linestatus, " +
				 "l_shipdate, " +
				 "l_commitdate, " +
				 "l_receiptdate, " +
				 "l_shipinstruct, " +
				 "l_shipmode, " +
				 "l_comment) " +
			 "values " +
				"(:l_orderkey, " +
				 ":l_partkey, " +
				 ":l_suppkey, " +
				 ":l_linenumber, " +
				 ":l_quantity, " +
				 ":l_extendedprice, " +
				 ":l_discount, " +
				 ":l_tax, " +
				 ":l_returnflag, " +
				 ":l_linestatus, " +
				 ":l_shipdate, " +
				 ":l_commitdate, " +
				 ":l_receiptdate, " +
				 ":l_shipinstruct, " +
				 ":l_shipmode, " +
				 ":l_comment)";

	/**
	 * Section 2.7, page 68 - Old Sales Refresh Function (RF2)
	 */
	private static String REFRESH_2_1_TEMPLATE =
			"delete from orders where o_orderkey = :o_orderkey";

	private static String REFRESH_2_2_TEMPLATE =
			"delete from lineitem where l_orderkey = :l_orderkey";

	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Specifies the type of this SQL statement
	 */
	public enum Type {
		QUERY,
		INSERT,
		DELETE,
		UPDATE
	};
	private final Type type;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs an instance of {@link TpchWorkload}
	 *
	 * @param query true if this is a QUERY, false if it is a REFRESH
	 */
	private TpchWorkload(Type type) {
		this.type = type;
	}

	/**
	 * Returns the SQL statement ready to be used as {@link PreparedStatement}
	 *
	 * @return the SQL statement ready to be used as {@link PreparedStatement}
	 */
	public String getSql() {
		switch (this) {
			case QUERY_1:
				return QUERY_1_TEMPLATE;
			case REFRESH_1_1:
				return REFRESH_1_1_TEMPLATE;
			case REFRESH_1_2:
				return REFRESH_1_2_TEMPLATE;
			case REFRESH_2_1:
				return REFRESH_2_1_TEMPLATE;
			case REFRESH_2_2:
				return REFRESH_2_2_TEMPLATE;
			default:
				throw new RuntimeException("unreachable");
		}
	}

	/**
	 * Returns the {@link Type} of this query
	 *
	 * @return {@link Type} of this query
	 */
	public final Type getType() {
		return type;
	}

	/**
	 * Returns true if this is a {@link Type#QUERY}, false otherwise
	 *
	 * @return true if this is a {@link Type#QUERY}, false otherwise
	 */
	public final boolean isQuery() {
		return this.getType() == Type.QUERY;
	}
}
