/**
 * AbstractMain.java
 */
package ch.ethz.asl.common.application;

import java.lang.management.*;
import java.util.*;
import java.util.concurrent.locks.*;

import org.slf4j.*;

/**
 * Abstract base reusable definition of Main
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 */
public abstract class AbstractMain extends TimerTask {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractMain.class);
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");

	private static final String MAIN_THREAD_SUFFIX = "-main-Thread";
	private static final double MINUTES_TO_MILLISECONDS = 60000.;
	private final ReentrantLock timeoutLock = new ReentrantLock();
	private final Condition exitCondition = timeoutLock.newCondition();
	private final Timer timer = new Timer();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void run() {
		timeoutLock.lock();
		try {
			exitCondition.signal();

			// make sure the timer is cancelled
			timer.cancel();
		}
		finally {
			timeoutLock.unlock();
		}
	}

	// ------------------------------------------------------------------------
	// protected
	// ------------------------------------------------------------------------
	/**
	 * Returns true if all application parameters are OK, false otherwise. If
	 * all parameters are OK it will setup a timer for the component to stop.
	 *
	 * @param <P>
	 * @param applicationName
	 * @param parameters
	 * @return true if all application parameters are OK, false otherwise
	 */
	protected static <P extends IParameter> boolean reusableMain(String applicationName,
			List<P> parameters) {
		Locale.setDefault(Locale.US);

		// change the Thread name
		Thread.currentThread().setName(applicationName + MAIN_THREAD_SUFFIX);

		// check that all required parameters are defined
		boolean paramsOk = true;
		for (P parameter : parameters) {
			if (System.getProperty(parameter.getParameter()) == null) {
				showHelp(applicationName, parameters);

				paramsOk = false;
				break;
			}
		}

		return paramsOk;
	}

	/**
	 * Prints application help to the standard output.
	 *
	 * @param <P>
	 * @param applicationName
	 * @param parameters
	 */
	protected static <P extends IParameter> void showHelp(String applicationName, List<P> parameters) {
		StringBuilder builder = new StringBuilder();
		builder.append("Usage: java -Xms512m -Xmx1024m ");
		for (P parameter : parameters) {
			builder.append("-D");
			builder.append(parameter.getParameter());
			builder.append('=');
			builder.append(parameter.getExample());
			builder.append(' ');
		}
		builder.append("-jar " + applicationName + ".jar ");
		System.out.println(builder.toString());
	}

	/**
	 * Prints all parameter values to the standard output.
	 *
	 * @param <P>
	 * @param applicationName
	 * @param parameters
	 */
	protected static <P extends IParameter> void printParameters(String applicationName,
			List<P> parameters) {
		StringBuilder builder = new StringBuilder();
		builder.append("****************************************************************");
		builder.append(LINE_SEPARATOR);
		builder.append(applicationName);
		builder.append(" parameters: ");
		builder.append(LINE_SEPARATOR);
		builder.append("****************************************************************");
		builder.append(LINE_SEPARATOR);

		// print the jvm parameters
		RuntimeMXBean RuntimemxBean = ManagementFactory.getRuntimeMXBean();
		List<String> jvmParameters = RuntimemxBean.getInputArguments();
		for (String parameter : jvmParameters) {
			if (parameter.startsWith("-D")) {
				continue;
			}
			builder.append('[');
			builder.append(parameter);
			builder.append(']');
			builder.append(LINE_SEPARATOR);
		}

		// print the application parameters
		for (P parameter : parameters) {
			builder.append(parameter.getParameter());
			builder.append("=[");
			builder.append(System.getProperty(parameter.getParameter()));
			builder.append(']');
			builder.append(LINE_SEPARATOR);
		}
		builder.append("****************************************************************");
		String output = builder.toString();
		System.out.println(output);
		LOGGER.info(LINE_SEPARATOR + output);
	}

	/**
	 * Setup timeout and wait for exit condition. Causes the calling thread to
	 * wait.
	 *
	 * @param timeout
	 *            Timeout (in minutes) to wait before shutting down the
	 *            component
	 */
	protected void setupTimeoutAndWait(long timeout) {
		// prevent this Thread from exiting
		long delay = Math.round(timeout * MINUTES_TO_MILLISECONDS);
		timer.schedule(this, delay);

		LOGGER.debug("thread is blocking for " + timeout + " minutes");
		timeoutLock.lock();

		try {
			boolean exit = false;
			do {
				try {
					exitCondition.await();
					exit = true;
				}
				catch (InterruptedException exception) {
					// wait forever!
				}
			}
			while (!exit);
		}
		finally {
			timeoutLock.unlock();

			// shutdown the component
			shutdownComponent();
		}
	}

	/**
	 * Shutdown this component
	 */
	abstract protected void shutdownComponent();
}
