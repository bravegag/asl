/**
 * DateTimeFileAppender.java
 */
package ch.ethz.asl.common.logging;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.FileAppender;

/**
 * This is a modified variant of {@link FileAppender} which inserts a timestamp
 * into the filename of the corresponding log file.  The timestamp format can
 * be specified by the use of '#{}' in the 'File' attribute, where the contents
 * contain a vaild {@link SimpleDateFormat} format string.  If replacement is
 * not desired, this may be inhibited by prepending a backslash ('\#{}')
 * 
 * Example: "hello-#{yyyyMMdd-HHmmss}.log"
 * 
 * @author <a href="mailto:zchothia@student.ethz.ch">Zaheer Chothia</a>
 * @since Oct 17, 2011
 */
public class DateTimeFileAppender extends FileAppender {
	// We rely on the fact that all the constructors and member functions don't
	// set {@link filename} directly, but rather delegate to {@link setFile}.
	//
	// This is based on the implementation of {@link FileAppender} from SVN (r910151):
	// http://svn.apache.org/viewvc/logging/log4j/trunk/src/main/java/org/apache/log4j/FileAppender.java

	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private static final Pattern TIMESTAMP_MARKER = Pattern.compile("(?<!\\\\)#\\{(.+?)\\}");
	private final Date NOW = new Date(); 

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * {@inheritDoc}
	 */
	public void setFile(String file) {
		// Trim spaces from both ends. The users probably does not want
		// trailing spaces in file names.
		String val = file.trim();
		fileName = formatFilenameTimestamp(val);
	}

	/**
	 * {@inheritDoc}
	 */
	public synchronized void setFile(String fileName, boolean append,
			boolean bufferedIO, int bufferSize) throws IOException {
		String fileNameWithTimestamp = formatFilenameTimestamp(fileName);
		super.setFile(fileNameWithTimestamp, append, bufferedIO, bufferSize);
	}

	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	private String formatFilenameTimestamp(String fileName) {
		Matcher matcher = TIMESTAMP_MARKER.matcher(fileName);
		StringBuffer stringBuffer = new StringBuffer();
		SimpleDateFormat dateFormat = new SimpleDateFormat();

		while (matcher.find()) {
			String dateFormatPattern = matcher.group(1);
			dateFormat.applyPattern(dateFormatPattern);
			String dateString = dateFormat.format(NOW);
			matcher.appendReplacement(stringBuffer, dateString);
		}

		matcher.appendTail(stringBuffer);
		return stringBuffer.toString();
	 }
}
