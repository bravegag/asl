#!/usr/bin/env python
# encoding: utf-8

from __future__ import with_statement

import os

SCRIPT_DIR, SCRIPT_NAME = os.path.split(os.path.abspath(__file__))

VENV_ACTIVATE = os.path.join(SCRIPT_DIR, 'venv', 'Scripts', 'activate_this.py')
if os.path.isfile(VENV_ACTIVATE):
    execfile(VENV_ACTIVATE, dict(__file__=VENV_ACTIVATE))
del VENV_ACTIVATE

ETHZ_IKR_HOSTS = set('ikr%02d.ethz.ch' % i for i in xrange(1, 32))
ETHZ_IKR_HOSTS.difference_update([
    # These hosts aren't working
    'ikr04.ethz.ch',
    'ikr05.ethz.ch',
    'ikr06.ethz.ch',
    'ikr08.ethz.ch',
    'ikr12.ethz.ch',
    'ikr18.ethz.ch',
    'ikr22.ethz.ch',
    # TEMP (03.11) -> killed with 200 clients!
    #'ikr24.ethz.ch',
    #'ikr26.ethz.ch',
    #'ikr30.ethz.ch',
])
ETHZ_IKR_HOSTS = sorted(ETHZ_IKR_HOSTS)

from fabric.api import *

env.user = 'zchothia'
#env.hosts = ETHZ_IKR_HOSTS
env.hosts = ['ikr%02d.ethz.ch' % i for i in []]  # modify as needed
env.key_filename = os.path.join(SCRIPT_DIR, 'sshkey', 'sshkey-zchothia-asl11-c2g2.openssh.private')

def setup():
    out = run('mktemp -d', shell=True)  # capture output and pass to future executions ...
    print 'mktemp', repr(out)
    tempdir = out.splitlines()[0]
    print 'tempdir', repr(tempdir)
    out = run('rm -rf %s' % tempdir)
    print 'rm', repr(out)
    import pdb; pdb.set_trace()

    #put('manage.py', '~/setup.sh')
    #with cd('~'):
    #    run('chmod u+x setup.sh')
    #    run('./setup.sh')
    #    run('rm setup.sh')

def uptime():
    run('uptime')

def ps():
    run('ps ux')

def killall():
    env.warn_only = True
    run('killall --user %s' % (env.user))

def clean_tmp():
    run('rm -rf $TMPDIR/*')

def delete_experiments():
    run('rm -rf $ASL_DIR/experiments')

def ls_experiments():
    run('[ -d $ASL_DIR/experiments ] && ls -la $ASL_DIR/experiments || echo none')

def ls_databases():
    run('[ -d $ASL_DIR/databases ] && ls -la $ASL_DIR/databases || echo none')

def copy_jrockit():
    run('rsync -av ~/local_disabled/jrockit-jdk1.6.0_29-R28.1.5-4.0.1 $ASL_DIR/tools')

if __name__ == "__main__":
    setup()
