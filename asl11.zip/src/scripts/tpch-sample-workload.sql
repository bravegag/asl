-- TPC-H Sample Workload
--
-- Modified for Advanced Systems Lab: 
--   We only support Query 1 rather than the full set of 22 queries:
--       RF1, 22 * Q1, RF2
--   Furthermore the 'group by' and 'order by' clauses have been dropped from Q1.
--   In addition, RF2 (delete) will remove the tuples inserted by RF1 (insert)
--
-- Query parameters generated from 'qgen' tool.
-- Refresh functions are based on workload from:
--   http://www.systems.ethz.ch/education/hs11/asl/milestone01_workload.tar.bz2

--------------------------------------------------------------------------------

--   Refresh function 1:
--     See section 2.6 (page 67) of TPC-H specification:
--       LOOP (SF * 1500) TIMES
--         INSERT a new row into the ORDERS table
--         LOOP RANDOM(1, 7) TIMES
--           INSERT a new row into the LINEITEM table
--         END LOOP
--       END LOOP

insert into orders values ('9', '10096', 'O', '70670.35', '1995-10-13', '3-MEDIUM', 'Clerk#000000052', '0', 'ts promise slyly. express packages above the carefully ironic account');
insert into lineitem values ('9', '11252', '775', '1', '27', '31407.75', '0.10', '0.00', 'N', 'O', '1995-11-28', '1995-12-06', '1995-12-06', 'TAKE BACK RETURN', 'AIR', 'ilent packages. final, regu');
insert into lineitem values ('9', '11407', '191', '2', '8', '10547.20', '0.06', '0.00', 'N', 'O', '1996-02-10', '1995-12-13', '1996-02-29', 'NONE', 'FOB', 'iously special deposits. fluffily pending');
insert into lineitem values ('9', '4674', '437', '3', '20', '31573.40', '0.02', '0.05', 'N', 'O', '1995-12-09', '1996-01-10', '1995-12-16', 'TAKE BACK RETURN', 'REG AIR', 'ully final deposits wa');
insert into orders values ('10', '1286', 'F', '148940.57', '1992-07-21', '1-URGENT', 'Clerk#000000904', '0', ' furiously according to the quickly ironic requests. ironic accounts ha');
insert into lineitem values ('10', '7954', '726', '1', '30', '55858.50', '0.09', '0.01', 'R', 'F', '1992-09-20', '1992-09-29', '1992-10-15', 'NONE', 'AIR', 'uses haggle caref');
insert into lineitem values ('10', '2478', '479', '2', '8', '11043.76', '0.01', '0.05', 'A', 'F', '1992-10-01', '1992-09-01', '1992-10-05', 'COLLECT COD', 'AIR', '. ironic, final theodolites run alongsi');
insert into lineitem values ('10', '19990', '529', '3', '43', '82129.57', '0.02', '0.07', 'R', 'F', '1992-09-14', '1992-09-28', '1992-09-30', 'COLLECT COD', 'TRUCK', 'iously ideas. de');
insert into orders values ('11', '10132', 'F', '180505.05', '1992-11-27', '4-NOT SPECIFIED', 'Clerk#000000283', '0', ' slyly ironic packages. quickly pending foxes haggle across');
insert into lineitem values ('11', '17786', '321', '1', '4', '6815.12', '0.00', '0.08', 'R', 'F', '1993-02-14', '1993-02-08', '1993-02-22', 'DELIVER IN PERSON', 'FOB', 'nusual, sp');
insert into lineitem values ('11', '7301', '559', '2', '15', '18124.50', '0.02', '0.02', 'A', 'F', '1993-01-11', '1993-01-30', '1993-01-14', 'NONE', 'MAIL', 'xes are idly carefully unu');
insert into lineitem values ('11', '1142', '143', '3', '10', '10431.40', '0.05', '0.04', 'A', 'F', '1993-01-08', '1993-01-30', '1993-01-24', 'TAKE BACK RETURN', 'TRUCK', 'theodolites mainta');
insert into lineitem values ('11', '10798', '319', '4', '30', '51263.70', '0.08', '0.07', 'R', 'F', '1992-12-04', '1992-12-31', '1992-12-18', 'COLLECT COD', 'MAIL', 'ests wake slyly');
insert into lineitem values ('11', '12635', '898', '5', '28', '43333.64', '0.02', '0.06', 'R', 'F', '1993-01-31', '1992-12-29', '1993-02-18', 'COLLECT COD', 'RAIL', 'r the silen');
insert into lineitem values ('11', '6790', '791', '6', '22', '37329.38', '0.03', '0.06', 'A', 'F', '1993-02-22', '1993-01-06', '1993-02-27', 'TAKE BACK RETURN', 'FOB', 'efully ironic accounts are a');
insert into lineitem values ('11', '10336', '597', '7', '9', '11216.97', '0.06', '0.03', 'R', 'F', '1993-03-25', '1993-02-06', '1993-04-12', 'COLLECT COD', 'REG AIR', 'ions wake reg');
insert into orders values ('12', '3590', 'F', '22342.09', '1992-07-07', '3-MEDIUM', 'Clerk#000000967', '0', ' even deposits. quickly');
insert into lineitem values ('12', '7075', '847', '1', '25', '24551.75', '0.09', '0.00', 'R', 'F', '1992-07-31', '1992-09-08', '1992-08-01', 'COLLECT COD', 'RAIL', 'nt package');
insert into orders values ('13', '1397', 'O', '275483.56', '1997-02-19', '5-LOW', 'Clerk#000000771', '0', ' cajole slyly. quickly quick deposits are fluffily. unusual p');
insert into lineitem values ('13', '4041', '296', '1', '29', '27406.16', '0.08', '0.04', 'N', 'O', '1997-06-06', '1997-04-22', '1997-06-24', 'DELIVER IN PERSON', 'FOB', 'gular, express requests mold according');
insert into lineitem values ('13', '5277', '533', '2', '41', '48473.07', '0.10', '0.07', 'N', 'O', '1997-03-27', '1997-04-07', '1997-04-01', 'TAKE BACK RETURN', 'RAIL', 'fter the blithely e');
insert into lineitem values ('13', '489', '990', '3', '47', '65305.56', '0.05', '0.02', 'N', 'O', '1997-04-09', '1997-05-20', '1997-04-20', 'NONE', 'MAIL', 'eep according to the regular asym');
insert into lineitem values ('13', '17982', '517', '4', '6', '11399.88', '0.00', '0.05', 'N', 'O', '1997-04-15', '1997-04-28', '1997-04-23', 'COLLECT COD', 'AIR', 'phs haggle in place of the carefully f');
insert into lineitem values ('13', '3372', '879', '5', '29', '36985.73', '0.09', '0.01', 'N', 'O', '1997-04-15', '1997-05-06', '1997-05-13', 'DELIVER IN PERSON', 'FOB', 'ding to the careful');
insert into lineitem values ('13', '19065', '873', '6', '15', '14760.90', '0.01', '0.02', 'N', 'O', '1997-03-30', '1997-03-22', '1997-04-12', 'DELIVER IN PERSON', 'REG AIR', 'carefully final excuses nag blith');
insert into lineitem values ('13', '3765', '525', '7', '47', '78431.72', '0.00', '0.00', 'N', 'O', '1997-04-24', '1997-05-17', '1997-05-18', 'NONE', 'REG AIR', 'above the carefu');
insert into orders values ('14', '8311', 'O', '256192.57', '1996-09-16', '3-MEDIUM', 'Clerk#000000447', '0', 'final accounts. special requests against the');
insert into lineitem values ('14', '11331', '593', '1', '5', '6211.65', '0.06', '0.03', 'N', 'O', '1996-10-19', '1996-11-04', '1996-11-11', 'NONE', 'REG AIR', 'equests wak');
insert into lineitem values ('14', '18510', '47', '2', '31', '44283.81', '0.05', '0.02', 'N', 'O', '1996-12-10', '1996-11-06', '1996-12-26', 'DELIVER IN PERSON', 'SHIP', 'uests. slyly even excuses use above ');
insert into lineitem values ('14', '15903', '434', '3', '43', '78212.70', '0.01', '0.01', 'N', 'O', '1996-10-03', '1996-11-12', '1996-10-19', 'COLLECT COD', 'AIR', 'y. blithely fin');
insert into lineitem values ('14', '18026', '831', '4', '28', '26432.56', '0.01', '0.01', 'N', 'O', '1996-11-06', '1996-10-17', '1996-11-26', 'NONE', 'FOB', ' requests serve after');
insert into lineitem values ('14', '7674', '675', '5', '43', '68011.81', '0.10', '0.08', 'N', 'O', '1996-11-05', '1996-11-26', '1996-11-13', 'COLLECT COD', 'SHIP', 'its along ');
insert into lineitem values ('14', '5191', '702', '6', '28', '30693.32', '0.01', '0.02', 'N', 'O', '1996-10-30', '1996-10-16', '1996-11-29', 'DELIVER IN PERSON', 'RAIL', 'ss enticingly evenly express ideas. quic');
insert into lineitem values ('14', '1043', '546', '7', '6', '5664.24', '0.07', '0.05', 'N', 'O', '1996-11-12', '1996-12-06', '1996-11-26', 'DELIVER IN PERSON', 'AIR', 'counts cajole among the furiously');
insert into orders values ('15', '9772', 'F', '262305.86', '1993-06-18', '1-URGENT', 'Clerk#000000936', '0', 'al ideas affix even ');
insert into lineitem values ('15', '727', '978', '1', '38', '61853.36', '0.03', '0.07', 'R', 'F', '1993-07-15', '1993-08-23', '1993-07-31', 'TAKE BACK RETURN', 'RAIL', 'y about the even, even depo');
insert into lineitem values ('15', '17715', '983', '2', '36', '58777.56', '0.01', '0.03', 'R', 'F', '1993-09-03', '1993-07-21', '1993-09-28', 'DELIVER IN PERSON', 'SHIP', 'instructions haggle carefully. pen');
insert into lineitem values ('15', '15966', '232', '3', '45', '84688.20', '0.08', '0.05', 'A', 'F', '1993-07-08', '1993-08-18', '1993-07-30', 'COLLECT COD', 'TRUCK', 'ole quickly blithely special accounts. ca');
insert into lineitem values ('15', '6955', '468', '4', '31', '57720.45', '0.07', '0.05', 'A', 'F', '1993-09-12', '1993-07-26', '1993-09-24', 'NONE', 'TRUCK', 'ore the accounts. slyly daring packages aff');
insert into orders values ('40', '1588', 'O', '38410.68', '1995-11-05', '3-MEDIUM', 'Clerk#000000406', '0', 'es sleep furiously pending accounts. idly special packages nag carefully. ');
insert into lineitem values ('40', '9722', '500', '1', '22', '35897.84', '0.00', '0.07', 'N', 'O', '1996-01-20', '1996-01-02', '1996-01-25', 'DELIVER IN PERSON', 'AIR', 'es. furiously regula');
insert into orders values ('41', '4304', 'F', '140590.01', '1992-05-23', '2-HIGH', 'Clerk#000000593', '0', 'kages wake quickly along th');
insert into lineitem values ('41', '8988', '989', '1', '9', '17072.82', '0.03', '0.08', 'R', 'F', '1992-06-10', '1992-08-04', '1992-07-10', 'COLLECT COD', 'MAIL', 'ccounts. carefully f');
insert into lineitem values ('41', '13176', '703', '2', '1', '1089.17', '0.08', '0.04', 'A', 'F', '1992-07-25', '1992-06-28', '1992-08-16', 'COLLECT COD', 'SHIP', 'uickly final requests a');
insert into lineitem values ('41', '17767', '569', '3', '24', '40434.24', '0.02', '0.07', 'A', 'F', '1992-06-29', '1992-07-23', '1992-07-02', 'NONE', 'SHIP', 'ly regular requests. ');
insert into lineitem values ('41', '6270', '783', '4', '14', '16467.78', '0.01', '0.03', 'A', 'F', '1992-09-09', '1992-08-01', '1992-09-21', 'DELIVER IN PERSON', 'FOB', 'ously about the slyly pend');
insert into lineitem values ('41', '8934', '193', '5', '32', '58973.76', '0.01', '0.07', 'R', 'F', '1992-08-20', '1992-07-09', '1992-08-23', 'TAKE BACK RETURN', 'SHIP', 'are carefully furiously regular reques');
insert into orders values ('42', '289', 'O', '154065.00', '1996-04-24', '1-URGENT', 'Clerk#000000374', '0', 'al packages. pending foxes wake carefully. fluffily final instructions to the');
insert into lineitem values ('42', '11580', '842', '1', '38', '56680.04', '0.03', '0.05', 'N', 'O', '1996-06-15', '1996-06-08', '1996-07-09', 'DELIVER IN PERSON', 'SHIP', 't among the final packag');
insert into lineitem values ('42', '4059', '314', '2', '44', '42374.20', '0.02', '0.00', 'N', 'O', '1996-07-05', '1996-07-08', '1996-07-24', 'DELIVER IN PERSON', 'FOB', ' blithely unusual braids. ');
insert into lineitem values ('42', '15494', '495', '3', '12', '16913.88', '0.04', '0.02', 'N', 'O', '1996-05-06', '1996-07-20', '1996-05-12', 'COLLECT COD', 'REG AIR', 'ove the carefully i');
insert into lineitem values ('42', '19044', '852', '4', '24', '23112.96', '0.03', '0.04', 'N', 'O', '1996-05-26', '1996-07-23', '1996-06-16', 'NONE', 'TRUCK', 'ncies. blithely unusual instructions along');
insert into lineitem values ('42', '3493', '747', '5', '10', '13964.90', '0.01', '0.08', 'N', 'O', '1996-07-22', '1996-06-11', '1996-07-31', 'TAKE BACK RETURN', 'MAIL', 'eans. slyly final platelets wak');
insert into orders values ('43', '2711', 'O', '18848.48', '1995-10-21', '4-NOT SPECIFIED', 'Clerk#000000920', '0', 'uches haggle fluffily furiously regular ');
insert into lineitem values ('43', '996', '997', '1', '10', '18969.90', '0.08', '0.08', 'N', 'O', '1996-02-10', '1995-12-17', '1996-03-05', 'NONE', 'AIR', 'its. regular id');
insert into orders values ('44', '481', 'O', '289262.94', '1997-01-25', '3-MEDIUM', 'Clerk#000000073', '0', 'kages wake slyly after the');
insert into lineitem values ('44', '3472', '473', '1', '47', '64647.09', '0.02', '0.08', 'N', 'O', '1997-04-21', '1997-04-16', '1997-04-28', 'NONE', 'REG AIR', 'ntegrate quickly tithes. qui');
insert into lineitem values ('44', '9993', '253', '2', '25', '47574.75', '0.07', '0.06', 'N', 'O', '1997-03-15', '1997-04-25', '1997-03-29', 'TAKE BACK RETURN', 'RAIL', ' quickly unusual requests haggle quickly');
insert into lineitem values ('44', '18998', '999', '3', '27', '51758.73', '0.04', '0.01', 'N', 'O', '1997-02-25', '1997-04-11', '1997-03-01', 'DELIVER IN PERSON', 'TRUCK', 'g to the ironic ideas was furio');
insert into lineitem values ('44', '5003', '259', '4', '43', '39044.00', '0.03', '0.04', 'N', 'O', '1997-02-10', '1997-04-08', '1997-03-06', 'DELIVER IN PERSON', 'MAIL', 'gular deposits enga');
insert into lineitem values ('44', '16974', '773', '5', '31', '58620.07', '0.10', '0.03', 'N', 'O', '1997-04-30', '1997-04-03', '1997-05-30', 'DELIVER IN PERSON', 'FOB', 'thily even ');
insert into lineitem values ('44', '15970', '501', '6', '16', '30175.52', '0.07', '0.07', 'N', 'O', '1997-03-04', '1997-04-22', '1997-03-31', 'NONE', 'TRUCK', 'ly even packages cajo');
insert into orders values ('45', '10774', 'F', '60111.16', '1994-06-26', '3-MEDIUM', 'Clerk#000000413', '0', 'ld deposits! regular packages boost despite th');
insert into lineitem values ('45', '18816', '353', '1', '33', '57248.73', '0.00', '0.05', 'R', 'F', '1994-10-10', '1994-08-22', '1994-10-17', 'COLLECT COD', 'RAIL', 'e ironic, express');
insert into orders values ('46', '12070', 'O', '259147.50', '1998-01-14', '5-LOW', 'Clerk#000000299', '0', 'ounts wake furiously regular packages. slyly ironic packages cajole sly');
insert into lineitem values ('46', '1910', '664', '1', '45', '81535.95', '0.01', '0.08', 'N', 'O', '1998-03-03', '1998-03-17', '1998-03-23', 'COLLECT COD', 'RAIL', ', ironic theodolites');
insert into lineitem values ('46', '9543', '544', '2', '17', '24693.18', '0.09', '0.02', 'N', 'O', '1998-03-18', '1998-03-03', '1998-03-24', 'NONE', 'AIR', 'fluffily blith');
insert into lineitem values ('46', '14403', '932', '3', '3', '3952.20', '0.08', '0.08', 'N', 'O', '1998-02-07', '1998-03-09', '1998-03-07', 'TAKE BACK RETURN', 'TRUCK', ' despite the silent');
insert into lineitem values ('46', '3859', '860', '4', '30', '52885.50', '0.10', '0.08', 'N', 'O', '1998-04-30', '1998-04-01', '1998-05-01', 'DELIVER IN PERSON', 'SHIP', ' deposits about the slyly final r');
insert into lineitem values ('46', '15363', '894', '5', '19', '24288.84', '0.07', '0.07', 'N', 'O', '1998-05-12', '1998-02-22', '1998-05-29', 'DELIVER IN PERSON', 'MAIL', ' special dependencies are furio');
insert into lineitem values ('46', '12756', '757', '6', '41', '68418.75', '0.05', '0.07', 'N', 'O', '1998-05-13', '1998-03-26', '1998-06-03', 'DELIVER IN PERSON', 'REG AIR', 'esides the blithe');
insert into orders values ('47', '3014', 'F', '19854.95', '1994-08-08', '3-MEDIUM', 'Clerk#000000015', '0', 'y express pinto beans. unusual platelets against the expres');
insert into lineitem values ('47', '11181', '704', '1', '19', '20751.42', '0.08', '0.04', 'A', 'F', '1994-10-30', '1994-10-01', '1994-11-07', 'DELIVER IN PERSON', 'TRUCK', 's. furiously final instructi');
insert into orders values ('72', '8902', 'O', '168707.75', '1997-11-04', '4-NOT SPECIFIED', 'Clerk#000000827', '0', 'er accounts. bold pinto bean');
insert into lineitem values ('72', '1882', '134', '1', '4', '7135.52', '0.06', '0.06', 'N', 'O', '1997-12-21', '1997-12-15', '1997-12-25', 'DELIVER IN PERSON', 'SHIP', 's nag quickly. blithely i');
insert into lineitem values ('72', '19362', '901', '2', '39', '49973.04', '0.06', '0.04', 'N', 'O', '1998-01-14', '1997-12-06', '1998-02-04', 'NONE', 'FOB', 'en ideas. bli');
insert into lineitem values ('72', '12366', '153', '3', '27', '34515.72', '0.03', '0.01', 'N', 'O', '1998-02-25', '1997-12-18', '1998-03-17', 'DELIVER IN PERSON', 'FOB', 'r pinto beans solve according to the care');
insert into lineitem values ('72', '6057', '826', '4', '17', '16371.85', '0.00', '0.08', 'N', 'O', '1998-02-01', '1998-01-18', '1998-03-02', 'DELIVER IN PERSON', 'SHIP', 'ar instructions sn');
insert into lineitem values ('72', '8231', '232', '5', '42', '47847.66', '0.08', '0.01', 'N', 'O', '1998-01-04', '1997-12-21', '1998-01-15', 'NONE', 'REG AIR', 'efully slyly bold dependencies. q');
insert into lineitem values ('72', '13784', '785', '6', '10', '16977.80', '0.04', '0.03', 'N', 'O', '1997-11-17', '1997-12-29', '1997-11-27', 'NONE', 'RAIL', 'ggle slyly regula');
insert into orders values ('73', '14645', 'F', '207652.92', '1993-09-15', '3-MEDIUM', 'Clerk#000000398', '0', 'e. carefully regular requests cajole quickly? bold, even deposits against the ');
insert into lineitem values ('73', '18118', '923', '1', '29', '30047.19', '0.01', '0.05', 'A', 'F', '1993-10-20', '1993-10-21', '1993-11-12', 'COLLECT COD', 'MAIL', 'nes. furiously even di');
insert into lineitem values ('73', '2963', '216', '2', '29', '54112.84', '0.05', '0.05', 'A', 'F', '1993-10-14', '1993-10-22', '1993-10-18', 'DELIVER IN PERSON', 'FOB', '. packages use blith');
insert into lineitem values ('73', '12171', '172', '3', '15', '16247.55', '0.03', '0.01', 'R', 'F', '1993-12-02', '1993-11-25', '1993-12-24', 'NONE', 'TRUCK', 'kages along');
insert into lineitem values ('73', '14436', '701', '4', '41', '55367.63', '0.08', '0.06', 'R', 'F', '1993-11-18', '1993-10-16', '1993-12-04', 'NONE', 'TRUCK', ' haggle blithely after t');
insert into lineitem values ('73', '19620', '621', '5', '17', '26173.54', '0.05', '0.05', 'R', 'F', '1993-12-14', '1993-11-07', '1993-12-31', 'DELIVER IN PERSON', 'AIR', 'tions. furiously regular packages sleep');
insert into lineitem values ('73', '2067', '320', '6', '27', '26164.62', '0.01', '0.02', 'R', 'F', '1993-12-06', '1993-10-24', '1993-12-25', 'DELIVER IN PERSON', 'TRUCK', 'ly regular pinto be');
insert into orders values ('74', '2986', 'F', '37989.59', '1992-09-22', '4-NOT SPECIFIED', 'Clerk#000000066', '0', 'eposits haggle unusual requests. final, furious hockey players ab');
insert into lineitem values ('74', '12558', '559', '1', '26', '38234.30', '0.08', '0.08', 'A', 'F', '1992-10-11', '1992-10-25', '1992-11-05', 'TAKE BACK RETURN', 'MAIL', 'ges dazzle blithe');
insert into orders values ('75', '1924', 'F', '5722.07', '1993-06-23', '1-URGENT', 'Clerk#000000589', '0', 'fully express packages. carefully bold accounts across the f');
insert into lineitem values ('75', '7023', '24', '1', '1', '930.02', '0.08', '0.02', 'R', 'F', '1993-07-10', '1993-07-27', '1993-07-12', 'NONE', 'SHIP', 'eposits are bold ');
insert into lineitem values ('75', '3315', '316', '2', '4', '4873.24', '0.07', '0.07', 'R', 'F', '1993-10-08', '1993-08-01', '1993-10-17', 'NONE', 'REG AIR', 'atelets. f');
insert into orders values ('76', '8314', 'O', '144457.75', '1997-04-24', '1-URGENT', 'Clerk#000000145', '0', 'y final accounts eat above the final ideas? express, final theodolites are c');
insert into lineitem values ('76', '9255', '515', '1', '38', '44241.50', '0.05', '0.03', 'N', 'O', '1997-08-16', '1997-07-15', '1997-09-06', 'COLLECT COD', 'AIR', 'ally regular pearls haggle. carefully eve');
insert into lineitem values ('76', '14250', '779', '2', '33', '38420.25', '0.01', '0.07', 'N', 'O', '1997-05-25', '1997-07-06', '1997-05-31', 'DELIVER IN PERSON', 'AIR', 'd the slyly express pinto beans w');
insert into lineitem values ('76', '15807', '808', '3', '5', '8614.00', '0.01', '0.04', 'N', 'O', '1997-05-21', '1997-07-08', '1997-05-22', 'COLLECT COD', 'MAIL', 'r dependencies about the slyly unusual excu');
insert into lineitem values ('76', '5600', '601', '4', '35', '52696.00', '0.04', '0.02', 'N', 'O', '1997-06-20', '1997-07-16', '1997-07-16', 'COLLECT COD', 'TRUCK', 'es sleep quic');
insert into orders values ('77', '4705', 'F', '168383.61', '1993-01-09', '4-NOT SPECIFIED', 'Clerk#000000156', '0', 'blithely blithely regular');
insert into lineitem values ('77', '7848', '849', '1', '22', '38628.48', '0.03', '0.06', 'R', 'F', '1993-02-15', '1993-03-23', '1993-02-17', 'TAKE BACK RETURN', 'AIR', 'ly against the furiously ironic reque');
insert into lineitem values ('77', '19523', '793', '2', '31', '44718.12', '0.05', '0.02', 'A', 'F', '1993-01-31', '1993-03-11', '1993-02-04', 'NONE', 'MAIL', 'lithely even gifts. slowly u');
insert into lineitem values ('77', '19260', '68', '3', '46', '54245.96', '0.07', '0.02', 'A', 'F', '1993-03-31', '1993-02-26', '1993-04-11', 'DELIVER IN PERSON', 'RAIL', 'lly special deposits above the final reque');
insert into lineitem values ('77', '13012', '802', '4', '37', '34225.37', '0.02', '0.01', 'A', 'F', '1993-04-13', '1993-02-28', '1993-04-25', 'NONE', 'AIR', ' requests. final excu');
insert into orders values ('78', '12361', 'F', '81014.98', '1994-03-16', '4-NOT SPECIFIED', 'Clerk#000000545', '0', ' must have to sleep after the slyly silent foxes. theodolites nag ');
insert into lineitem values ('78', '5938', '194', '1', '42', '77445.06', '0.04', '0.00', 'A', 'F', '1994-06-21', '1994-05-20', '1994-06-25', 'COLLECT COD', 'MAIL', 's. furiously final ideas snooz');
insert into lineitem values ('78', '10043', '304', '2', '2', '1906.08', '0.04', '0.03', 'R', 'F', '1994-06-10', '1994-05-10', '1994-07-02', 'DELIVER IN PERSON', 'AIR', 'w pinto beans. unusual ');
insert into lineitem values ('78', '19188', '189', '3', '4', '4428.72', '0.00', '0.08', 'A', 'F', '1994-06-04', '1994-05-28', '1994-06-21', 'DELIVER IN PERSON', 'RAIL', 'jole slyly abo');
insert into orders values ('79', '2332', 'F', '139370.76', '1992-07-27', '4-NOT SPECIFIED', 'Clerk#000000468', '0', 'sly. slyly even requests are pending a');
insert into lineitem values ('79', '3893', '653', '1', '6', '10781.34', '0.03', '0.00', 'A', 'F', '1992-09-17', '1992-09-05', '1992-10-15', 'TAKE BACK RETURN', 'TRUCK', ' slyly regul');
insert into lineitem values ('79', '15896', '427', '2', '37', '67039.93', '0.06', '0.07', 'R', 'F', '1992-09-19', '1992-08-29', '1992-10-16', 'TAKE BACK RETURN', 'FOB', 'elets. regular depos');
insert into lineitem values ('79', '1727', '481', '3', '1', '1628.72', '0.03', '0.02', 'A', 'F', '1992-09-20', '1992-10-20', '1992-10-13', 'NONE', 'TRUCK', 'd instructions mig');
insert into lineitem values ('79', '9296', '556', '4', '39', '47006.31', '0.10', '0.05', 'R', 'F', '1992-11-06', '1992-09-18', '1992-11-17', 'NONE', 'FOB', 'ously express pinto beans. packages along t');
insert into lineitem values ('79', '5664', '175', '5', '10', '15696.60', '0.08', '0.07', 'A', 'F', '1992-08-27', '1992-08-28', '1992-09-18', 'NONE', 'RAIL', 'ests. ironic deposits aff');
insert into orders values ('104', '2941', 'F', '27291.67', '1993-08-05', '5-LOW', 'Clerk#000000900', '0', 'gular theodolites wake quickly according to the fluffily');
insert into lineitem values ('104', '6103', '104', '1', '25', '25227.50', '0.05', '0.01', 'A', 'F', '1993-09-29', '1993-10-10', '1993-10-12', 'NONE', 'REG AIR', 'alongside of the deposits. slyly even no');
insert into lineitem values ('104', '17673', '475', '2', '2', '3181.34', '0.03', '0.00', 'R', 'F', '1993-11-01', '1993-09-05', '1993-11-03', 'COLLECT COD', 'TRUCK', 'otes according to the even theodol');
insert into orders values ('105', '4318', 'O', '287439.15', '1997-02-03', '2-HIGH', 'Clerk#000000133', '0', ' the furiously regular dependencies. finally sile');
insert into lineitem values ('105', '716', '217', '1', '29', '46884.59', '0.06', '0.08', 'N', 'O', '1997-03-10', '1997-04-24', '1997-03-25', 'COLLECT COD', 'RAIL', 'sits cajole against the bl');
insert into lineitem values ('105', '12549', '336', '2', '35', '51153.90', '0.08', '0.08', 'N', 'O', '1997-04-23', '1997-04-05', '1997-05-21', 'NONE', 'TRUCK', 'al frets abou');
insert into lineitem values ('105', '16082', '349', '3', '43', '42917.44', '0.00', '0.02', 'N', 'O', '1997-05-10', '1997-03-10', '1997-05-23', 'TAKE BACK RETURN', 'MAIL', 'onic dependencies. fu');
insert into lineitem values ('105', '8619', '394', '4', '3', '4582.83', '0.03', '0.04', 'N', 'O', '1997-03-21', '1997-03-21', '1997-04-09', 'DELIVER IN PERSON', 'TRUCK', ' regular ideas acros');
insert into lineitem values ('105', '11144', '667', '5', '4', '4220.56', '0.03', '0.01', 'N', 'O', '1997-04-04', '1997-03-23', '1997-04-12', 'DELIVER IN PERSON', 'SHIP', 'es haggle blit');
insert into lineitem values ('105', '16632', '431', '6', '44', '68139.72', '0.01', '0.04', 'N', 'O', '1997-05-01', '1997-04-21', '1997-05-10', 'TAKE BACK RETURN', 'MAIL', 'ular packages wake blithely around the s');
insert into lineitem values ('105', '10759', '540', '7', '39', '65120.25', '0.03', '0.05', 'N', 'O', '1997-06-02', '1997-04-02', '1997-06-22', 'COLLECT COD', 'AIR', 'oost carefully. ironic deposits detect ');
insert into orders values ('106', '1714', 'O', '210919.43', '1998-03-31', '5-LOW', 'Clerk#000000217', '0', 'nto beans sleep quickly accounts. express accounts with the slyly regula');
insert into lineitem values ('106', '4211', '466', '1', '41', '45723.61', '0.02', '0.04', 'N', 'O', '1998-05-03', '1998-05-11', '1998-05-29', 'COLLECT COD', 'MAIL', 'he final requests. reg');
insert into lineitem values ('106', '17935', '737', '2', '9', '16676.37', '0.08', '0.02', 'N', 'O', '1998-07-28', '1998-05-05', '1998-08-20', 'COLLECT COD', 'RAIL', ' unusual, pending pinto beans acros');
insert into lineitem values ('106', '12441', '442', '3', '16', '21655.04', '0.04', '0.06', 'N', 'O', '1998-06-10', '1998-05-22', '1998-06-19', 'DELIVER IN PERSON', 'SHIP', 'unusual, ironic plate');
insert into lineitem values ('106', '14918', '919', '4', '21', '38491.11', '0.06', '0.05', 'N', 'O', '1998-06-03', '1998-06-08', '1998-06-13', 'NONE', 'REG AIR', 'iously final theodolites. e');
insert into lineitem values ('106', '6810', '579', '5', '26', '44637.06', '0.05', '0.00', 'N', 'O', '1998-07-21', '1998-05-31', '1998-08-12', 'TAKE BACK RETURN', 'SHIP', 'ay furiously; blithely express i');
insert into lineitem values ('106', '4940', '941', '6', '27', '49813.38', '0.09', '0.02', 'N', 'O', '1998-05-14', '1998-05-20', '1998-05-15', 'NONE', 'REG AIR', 'furiously after the silent packages');
insert into orders values ('107', '6469', 'F', '248112.92', '1994-11-03', '3-MEDIUM', 'Clerk#000000797', '0', 'ular requests boost. carefully even platelets ha');
insert into lineitem values ('107', '14979', '244', '1', '48', '90910.56', '0.10', '0.00', 'R', 'F', '1995-02-11', '1994-12-13', '1995-02-21', 'NONE', 'MAIL', 'luffily final accou');
insert into lineitem values ('107', '5106', '872', '2', '10', '10111.00', '0.03', '0.04', 'R', 'F', '1995-02-12', '1995-01-16', '1995-02-13', 'COLLECT COD', 'FOB', 'xpress theodolites. furiously regular foxes');
insert into lineitem values ('107', '10201', '202', '3', '32', '35558.40', '0.05', '0.03', 'A', 'F', '1995-03-03', '1994-12-18', '1995-03-16', 'TAKE BACK RETURN', 'TRUCK', 's. blithely silent ideas ');
insert into lineitem values ('107', '1378', '379', '4', '7', '8955.59', '0.08', '0.02', 'A', 'F', '1995-02-16', '1995-01-31', '1995-02-23', 'DELIVER IN PERSON', 'RAIL', 'en packages mold. furiously final accounts');
insert into lineitem values ('107', '14775', '776', '5', '23', '38864.71', '0.10', '0.08', 'R', 'F', '1995-01-03', '1995-01-20', '1995-01-27', 'NONE', 'FOB', 'uriously express inst');
insert into lineitem values ('107', '11167', '951', '6', '49', '52829.84', '0.09', '0.01', 'R', 'F', '1994-12-03', '1994-12-09', '1994-12-15', 'COLLECT COD', 'FOB', 'excuses sl');
insert into lineitem values ('107', '15756', '552', '7', '15', '25076.25', '0.01', '0.07', 'A', 'F', '1995-02-06', '1995-01-01', '1995-02-25', 'DELIVER IN PERSON', 'AIR', 'quests up the furiously even ideas haggle f');
insert into orders values ('108', '13663', 'F', '55524.82', '1994-11-01', '3-MEDIUM', 'Clerk#000000909', '0', 'e quickly dolphins. carefully special package');
insert into lineitem values ('108', '616', '617', '1', '8', '12132.88', '0.03', '0.08', 'R', 'F', '1995-02-10', '1995-01-27', '1995-02-13', 'COLLECT COD', 'RAIL', 'into beans? final deposits integ');
insert into lineitem values ('108', '1219', '722', '2', '40', '44808.40', '0.09', '0.05', 'R', 'F', '1994-12-10', '1995-01-29', '1994-12-17', 'TAKE BACK RETURN', 'MAIL', 'ily alongside of the ');
insert into orders values ('109', '6997', 'P', '277834.41', '1995-04-08', '4-NOT SPECIFIED', 'Clerk#000000153', '0', 'furiously ironic packages about t');
insert into lineitem values ('109', '16857', '656', '1', '24', '42572.40', '0.01', '0.01', 'A', 'F', '1995-05-05', '1995-06-08', '1995-05-21', 'COLLECT COD', 'REG AIR', 'sleep along the slyly regular package');
insert into lineitem values ('109', '20000', '808', '2', '10', '9200.00', '0.06', '0.07', 'N', 'O', '1995-07-24', '1995-06-18', '1995-08-23', 'DELIVER IN PERSON', 'FOB', 'g furiously.');
insert into lineitem values ('109', '3714', '968', '3', '41', '66326.11', '0.07', '0.00', 'N', 'O', '1995-07-14', '1995-07-05', '1995-07-27', 'TAKE BACK RETURN', 'AIR', 'l accounts nag carefully across the depo');
insert into lineitem values ('109', '4602', '603', '4', '45', '67797.00', '0.10', '0.04', 'A', 'F', '1995-06-05', '1995-05-12', '1995-06-13', 'DELIVER IN PERSON', 'FOB', 'eans wake quickly final packag');
insert into lineitem values ('109', '15101', '632', '5', '30', '30483.00', '0.06', '0.00', 'A', 'F', '1995-06-11', '1995-06-26', '1995-06-16', 'DELIVER IN PERSON', 'FOB', 'ts above t');
insert into lineitem values ('109', '10730', '731', '6', '38', '62347.74', '0.10', '0.01', 'N', 'O', '1995-07-23', '1995-06-26', '1995-08-09', 'NONE', 'AIR', 'x-ray quickly. blithely final depos');
insert into lineitem values ('109', '10069', '590', '7', '15', '14685.90', '0.02', '0.08', 'A', 'F', '1995-04-14', '1995-05-29', '1995-04-22', 'TAKE BACK RETURN', 'SHIP', 'ven platelets along t');
insert into orders values ('110', '12376', 'F', '83797.35', '1994-01-10', '3-MEDIUM', 'Clerk#000000032', '0', 'e the ironically special pinto beans. carefully unusual instructions ');
insert into lineitem values ('110', '17175', '176', '1', '50', '54608.50', '0.05', '0.05', 'R', 'F', '1994-03-26', '1994-04-08', '1994-04-04', 'DELIVER IN PERSON', 'REG AIR', 'ins: furiously close req');
insert into lineitem values ('110', '18272', '541', '2', '26', '30947.02', '0.08', '0.03', 'R', 'F', '1994-01-19', '1994-03-10', '1994-01-26', 'DELIVER IN PERSON', 'AIR', 'l packages x-ray quickly ');
insert into orders values ('111', '1222', 'O', '141283.44', '1996-05-08', '2-HIGH', 'Clerk#000000385', '0', 'er the regular ideas wake quickly about the slyly even request');
insert into lineitem values ('111', '7877', '649', '1', '50', '89243.50', '0.08', '0.06', 'N', 'O', '1996-08-21', '1996-07-18', '1996-08-25', 'TAKE BACK RETURN', 'MAIL', 'idly ironic acc');
insert into lineitem values ('111', '14056', '585', '2', '3', '2910.15', '0.06', '0.03', 'N', 'O', '1996-06-12', '1996-07-21', '1996-06-13', 'COLLECT COD', 'TRUCK', 'yers. quic');
insert into lineitem values ('111', '4200', '455', '3', '14', '15458.80', '0.06', '0.00', 'N', 'O', '1996-07-04', '1996-06-18', '1996-07-17', 'DELIVER IN PERSON', 'FOB', 'ly regular dolphin');
insert into lineitem values ('111', '12710', '235', '4', '24', '38945.04', '0.08', '0.03', 'N', 'O', '1996-08-24', '1996-07-24', '1996-09-10', 'DELIVER IN PERSON', 'REG AIR', 'osits hinder slyly regul');
insert into orders values ('136', '1934', 'O', '126890.64', '1995-12-21', '3-MEDIUM', 'Clerk#000000184', '0', ' the deposits are aroun');
insert into lineitem values ('136', '18631', '900', '1', '34', '52687.42', '0.04', '0.08', 'N', 'O', '1996-04-18', '1996-02-15', '1996-04-26', 'TAKE BACK RETURN', 'REG AIR', 'oxes haggle silent, express packages. unusu');
insert into lineitem values ('136', '14988', '517', '2', '39', '74216.22', '0.09', '0.07', 'N', 'O', '1996-03-27', '1996-02-03', '1996-04-25', 'DELIVER IN PERSON', 'RAIL', 'about the f');
insert into orders values ('137', '5096', 'O', '101500.11', '1997-01-08', '2-HIGH', 'Clerk#000000854', '0', 'ironic, regular dependencies.');
insert into lineitem values ('137', '17384', '919', '1', '33', '42945.54', '0.09', '0.07', 'N', 'O', '1997-02-13', '1997-03-16', '1997-02-21', 'NONE', 'REG AIR', ' deposits. sometimes regular pinto beans ');
insert into lineitem values ('137', '8483', '258', '2', '43', '59833.64', '0.05', '0.05', 'N', 'O', '1997-04-30', '1997-03-27', '1997-05-27', 'DELIVER IN PERSON', 'AIR', 's. blithely express ');
insert into orders values ('138', '5002', 'F', '150907.95', '1994-10-19', '4-NOT SPECIFIED', 'Clerk#000000806', '0', 'the fluffily blithe deposits. carefully even accounts are slyly spe');
insert into lineitem values ('138', '4449', '212', '1', '38', '51430.72', '0.07', '0.08', 'A', 'F', '1995-01-07', '1995-01-14', '1995-01-14', 'NONE', 'AIR', 'ar pinto beans according to the f');
insert into lineitem values ('138', '4155', '156', '2', '34', '36011.10', '0.09', '0.04', 'R', 'F', '1994-11-10', '1994-12-08', '1994-12-10', 'NONE', 'MAIL', 'slyly express requests solve blithely. car');
insert into lineitem values ('138', '11447', '970', '3', '15', '20376.60', '0.07', '0.00', 'R', 'F', '1995-02-17', '1994-11-30', '1995-02-18', 'DELIVER IN PERSON', 'AIR', 'eodolites sl');
insert into lineitem values ('138', '13835', '625', '4', '26', '45469.58', '0.05', '0.07', 'R', 'F', '1994-11-07', '1994-12-26', '1994-11-29', 'DELIVER IN PERSON', 'SHIP', 'kages are slyly a');
insert into orders values ('139', '10153', 'F', '335594.58', '1992-04-20', '5-LOW', 'Clerk#000000627', '0', 's. slyly regular packages b');
insert into lineitem values ('139', '2198', '199', '1', '7', '7701.33', '0.04', '0.07', 'A', 'F', '1992-06-21', '1992-06-15', '1992-06-30', 'COLLECT COD', 'SHIP', 'es x-ray furiously across ');
insert into lineitem values ('139', '13553', '80', '2', '31', '45463.05', '0.10', '0.04', 'A', 'F', '1992-04-21', '1992-07-13', '1992-04-28', 'COLLECT COD', 'TRUCK', 'ally blithe packages? ironic accou');
insert into lineitem values ('139', '14800', '329', '3', '44', '75451.20', '0.05', '0.08', 'R', 'F', '1992-07-05', '1992-05-30', '1992-07-29', 'NONE', 'RAIL', '. carefully silent acc');
insert into lineitem values ('139', '16374', '173', '4', '49', '63228.13', '0.00', '0.01', 'A', 'F', '1992-05-25', '1992-07-19', '1992-05-28', 'TAKE BACK RETURN', 'RAIL', 'refully. final excuses wak');
insert into lineitem values ('139', '3786', '40', '5', '40', '67591.20', '0.00', '0.01', 'R', 'F', '1992-06-16', '1992-06-13', '1992-07-16', 'DELIVER IN PERSON', 'FOB', 'kages wake. blithely express de');
insert into lineitem values ('139', '17771', '573', '6', '5', '8443.85', '0.00', '0.04', 'R', 'F', '1992-06-10', '1992-07-17', '1992-06-17', 'NONE', 'MAIL', 'y even dependencies. rut');
insert into lineitem values ('139', '2887', '888', '7', '37', '66225.56', '0.03', '0.04', 'R', 'F', '1992-05-24', '1992-06-05', '1992-06-23', 'DELIVER IN PERSON', 'FOB', ' theodolites. blithely');
insert into orders values ('140', '13165', 'O', '143368.70', '1998-01-08', '5-LOW', 'Clerk#000000487', '0', 'nally. carefully regular excuses haggle furiously. f');
insert into lineitem values ('140', '9078', '338', '1', '34', '33560.38', '0.05', '0.04', 'N', 'O', '1998-04-12', '1998-02-10', '1998-05-12', 'DELIVER IN PERSON', 'REG AIR', '. even instructions are. carefully reg');
insert into lineitem values ('140', '19651', '459', '2', '43', '67537.95', '0.02', '0.04', 'N', 'O', '1998-02-19', '1998-03-01', '1998-03-07', 'NONE', 'REG AIR', 's boost carefully flu');
insert into lineitem values ('140', '10409', '670', '3', '32', '42220.80', '0.02', '0.00', 'N', 'O', '1998-02-04', '1998-02-22', '1998-02-26', 'COLLECT COD', 'RAIL', 'tect carefully bold, ');
insert into orders values ('141', '2989', 'F', '185293.45', '1994-04-22', '4-NOT SPECIFIED', 'Clerk#000000598', '0', ' regular ideas. idle requests boost. ironic pinto b');
insert into lineitem values ('141', '15208', '209', '1', '6', '6739.20', '0.07', '0.03', 'R', 'F', '1994-08-12', '1994-05-26', '1994-08-16', 'NONE', 'TRUCK', 'unts cajole b');
insert into lineitem values ('141', '11856', '118', '2', '47', '83088.95', '0.07', '0.03', 'R', 'F', '1994-05-26', '1994-06-19', '1994-06-17', 'NONE', 'RAIL', 'pending accounts cajole ca');
insert into lineitem values ('141', '17866', '401', '3', '4', '7135.44', '0.04', '0.03', 'A', 'F', '1994-05-17', '1994-07-11', '1994-06-09', 'COLLECT COD', 'TRUCK', 'gside of the carefully i');
insert into lineitem values ('141', '1362', '363', '4', '31', '39164.16', '0.10', '0.07', 'R', 'F', '1994-08-08', '1994-06-01', '1994-08-25', 'DELIVER IN PERSON', 'RAIL', ' haggle along');
insert into lineitem values ('141', '1573', '825', '5', '21', '30965.97', '0.03', '0.08', 'A', 'F', '1994-08-15', '1994-06-29', '1994-09-06', 'NONE', 'REG AIR', 'horses. carefull');
insert into lineitem values ('141', '3212', '719', '6', '20', '22304.20', '0.05', '0.04', 'A', 'F', '1994-08-21', '1994-05-27', '1994-09-15', 'NONE', 'SHIP', 's. blithely regular excuses pl');
insert into orders values ('142', '661', 'F', '132197.96', '1993-10-03', '1-URGENT', 'Clerk#000000294', '0', 's. blithely unusual dolphins use. bli');
insert into lineitem values ('142', '7676', '448', '1', '27', '42759.09', '0.00', '0.02', 'A', 'F', '1993-10-20', '1993-12-24', '1993-11-09', 'DELIVER IN PERSON', 'TRUCK', 'carefully even packages. blithe');
insert into lineitem values ('142', '15772', '568', '2', '17', '28692.09', '0.05', '0.07', 'A', 'F', '1993-10-21', '1994-01-01', '1993-11-05', 'NONE', 'MAIL', 'ithely after the slyl');
insert into lineitem values ('142', '19689', '497', '3', '38', '61129.84', '0.10', '0.08', 'R', 'F', '1994-01-18', '1993-12-29', '1994-02-11', 'NONE', 'MAIL', 'fluffily. furiously even gro');
insert into orders values ('143', '13622', 'O', '36318.65', '1997-03-18', '4-NOT SPECIFIED', 'Clerk#000000387', '0', 'c requests cajole blithely express theodolites. bold ideas are carefull');
insert into lineitem values ('143', '4686', '941', '1', '2', '3181.36', '0.05', '0.02', 'N', 'O', '1997-07-15', '1997-06-13', '1997-07-22', 'DELIVER IN PERSON', 'MAIL', ' the quickly fluffy ideas engage blithel');
insert into lineitem values ('143', '5225', '226', '2', '31', '35036.82', '0.07', '0.02', 'N', 'O', '1997-03-28', '1997-06-12', '1997-04-27', 'COLLECT COD', 'AIR', 'ts wake until the unusual requests. slyl');
insert into orders values ('168', '5539', 'F', '238394.33', '1993-11-16', '1-URGENT', 'Clerk#000000417', '0', ' regular foxes alongside of the slyly express ideas nag furiously slyly final');
insert into lineitem values ('168', '9661', '662', '1', '46', '72250.36', '0.07', '0.04', 'A', 'F', '1994-02-21', '1994-02-04', '1994-03-19', 'NONE', 'FOB', 's are instructions. quickl');
insert into lineitem values ('168', '3077', '584', '2', '18', '17641.26', '0.04', '0.06', 'A', 'F', '1994-01-06', '1994-01-21', '1994-01-24', 'TAKE BACK RETURN', 'AIR', 'accounts. fluff');
insert into lineitem values ('168', '13227', '228', '3', '45', '51309.90', '0.00', '0.03', 'A', 'F', '1994-02-13', '1994-02-12', '1994-03-02', 'DELIVER IN PERSON', 'SHIP', 'r the final, daring depos');
insert into lineitem values ('168', '18360', '897', '4', '13', '16618.68', '0.06', '0.00', 'R', 'F', '1994-02-01', '1994-01-31', '1994-02-15', 'NONE', 'FOB', 'refully final fox');
insert into lineitem values ('168', '13531', '795', '5', '38', '54892.14', '0.06', '0.06', 'R', 'F', '1994-01-12', '1994-01-07', '1994-01-27', 'TAKE BACK RETURN', 'MAIL', 'boldly ironic theodolites. blithely ');
insert into lineitem values ('168', '19086', '625', '6', '27', '27137.16', '0.10', '0.00', 'R', 'F', '1994-01-16', '1994-01-30', '1994-01-30', 'TAKE BACK RETURN', 'FOB', 'ithely blithely pending requests. p');
insert into lineitem values ('168', '9639', '899', '7', '2', '3097.26', '0.04', '0.00', 'R', 'F', '1993-11-25', '1993-12-23', '1993-12-23', 'COLLECT COD', 'SHIP', 'c excuses wake above t');
insert into orders values ('169', '13705', 'O', '256986.42', '1996-11-24', '1-URGENT', 'Clerk#000000692', '0', 'e bold accounts. even, silent deposits wake pendin');
insert into lineitem values ('169', '18679', '680', '1', '31', '49527.77', '0.04', '0.01', 'N', 'O', '1997-02-04', '1997-02-22', '1997-02-06', 'TAKE BACK RETURN', 'REG AIR', 'iously even accounts poach. ');
insert into lineitem values ('169', '16981', '982', '2', '13', '24673.74', '0.09', '0.07', 'N', 'O', '1996-12-13', '1997-02-11', '1997-01-03', 'DELIVER IN PERSON', 'REG AIR', 'posits affix even requests. slyly expr');
insert into lineitem values ('169', '2989', '242', '3', '5', '9459.90', '0.03', '0.08', 'N', 'O', '1997-01-02', '1997-01-30', '1997-01-28', 'DELIVER IN PERSON', 'TRUCK', 'lites are dependencies. packages ar');
insert into lineitem values ('169', '14966', '231', '4', '30', '56428.80', '0.09', '0.01', 'N', 'O', '1996-12-13', '1997-01-10', '1996-12-30', 'DELIVER IN PERSON', 'RAIL', 'ages use blithely carefully unusual excus');
insert into lineitem values ('169', '7337', '852', '5', '37', '46040.21', '0.07', '0.08', 'N', 'O', '1996-12-07', '1997-02-05', '1996-12-14', 'NONE', 'TRUCK', 'the fluffily special packages. de');
insert into lineitem values ('169', '8615', '390', '6', '29', '44184.69', '0.04', '0.07', 'N', 'O', '1997-01-20', '1997-01-10', '1997-02-01', 'TAKE BACK RETURN', 'REG AIR', 'ages wake carefully');
insert into lineitem values ('169', '8176', '951', '7', '32', '34693.44', '0.10', '0.01', 'N', 'O', '1997-03-14', '1997-01-31', '1997-03-28', 'NONE', 'MAIL', 'al requests alongside of the regular pint');
insert into orders values ('170', '12742', 'F', '359529.71', '1992-07-02', '4-NOT SPECIFIED', 'Clerk#000000969', '0', 'ly ironic patterns sleep. slyly regul');
insert into lineitem values ('170', '5681', '682', '1', '37', '58707.16', '0.10', '0.04', 'A', 'F', '1992-10-28', '1992-08-08', '1992-11-26', 'DELIVER IN PERSON', 'RAIL', ' theodolites. accoun');
insert into lineitem values ('170', '12131', '132', '2', '17', '17733.21', '0.09', '0.02', 'R', 'F', '1992-07-23', '1992-09-14', '1992-08-12', 'TAKE BACK RETURN', 'FOB', 'l requests mold ');
insert into lineitem values ('170', '12017', '18', '3', '41', '38089.41', '0.09', '0.03', 'R', 'F', '1992-07-20', '1992-09-01', '1992-07-22', 'TAKE BACK RETURN', 'REG AIR', ' final pinto be');
insert into lineitem values ('170', '3229', '736', '4', '30', '33966.60', '0.05', '0.06', 'R', 'F', '1992-09-30', '1992-08-23', '1992-10-08', 'COLLECT COD', 'MAIL', 'n deposits. requ');
insert into lineitem values ('170', '16895', '428', '5', '35', '63416.15', '0.05', '0.04', 'R', 'F', '1992-09-01', '1992-09-29', '1992-09-07', 'DELIVER IN PERSON', 'REG AIR', ' ideas nag quickly. slyly ironic deposits ');
insert into lineitem values ('170', '8991', '508', '6', '48', '91199.52', '0.03', '0.06', 'R', 'F', '1992-09-14', '1992-08-29', '1992-09-16', 'NONE', 'FOB', 'slyly stealthy pinto beans are above the ');
insert into lineitem values ('170', '18535', '804', '7', '41', '59594.73', '0.04', '0.08', 'A', 'F', '1992-10-22', '1992-08-23', '1992-11-02', 'NONE', 'RAIL', 'thless packages across t');
insert into orders values ('171', '11962', 'O', '202049.48', '1995-12-10', '3-MEDIUM', 'Clerk#000000909', '0', ' theodolites boost against the ironic theodolites. ');
insert into lineitem values ('171', '3434', '194', '1', '4', '5349.72', '0.09', '0.03', 'N', 'O', '1996-01-17', '1996-01-14', '1996-02-11', 'TAKE BACK RETURN', 'SHIP', 'ep carefully blith');
insert into lineitem values ('171', '2699', '700', '2', '41', '65669.29', '0.02', '0.06', 'N', 'O', '1996-03-08', '1996-02-29', '1996-03-31', 'NONE', 'TRUCK', 'nly even acc');
insert into lineitem values ('171', '19984', '254', '3', '28', '53311.44', '0.06', '0.04', 'N', 'O', '1996-03-29', '1996-01-22', '1996-04-11', 'DELIVER IN PERSON', 'AIR', 'onic, ironic packages haggle carefully ag');
insert into lineitem values ('171', '7190', '705', '4', '9', '9874.71', '0.05', '0.06', 'N', 'O', '1996-03-16', '1996-01-19', '1996-04-13', 'TAKE BACK RETURN', 'SHIP', 's use furiously ');
insert into lineitem values ('171', '8935', '936', '5', '31', '57161.83', '0.06', '0.02', 'N', 'O', '1995-12-24', '1996-02-20', '1996-01-18', 'TAKE BACK RETURN', 'REG AIR', 'kly. unusu');
insert into lineitem values ('171', '5240', '241', '6', '11', '12597.64', '0.07', '0.02', 'N', 'O', '1996-01-16', '1996-01-31', '1996-02-14', 'COLLECT COD', 'FOB', 'the carefully iron');
insert into orders values ('172', '7456', 'O', '9596.28', '1995-05-22', '1-URGENT', 'Clerk#000000420', '0', 'the ironic packages affix packages. ');
insert into lineitem values ('172', '12916', '441', '1', '5', '9144.55', '0.01', '0.06', 'N', 'O', '1995-06-24', '1995-06-25', '1995-07-22', 'DELIVER IN PERSON', 'RAIL', 'counts. pending deposits do');
insert into orders values ('173', '13933', 'F', '282875.87', '1992-12-08', '3-MEDIUM', 'Clerk#000000002', '0', 'latelets. quickly express idea');
insert into lineitem values ('173', '16045', '312', '1', '45', '43246.80', '0.03', '0.06', 'A', 'F', '1993-02-17', '1993-02-08', '1993-03-16', 'COLLECT COD', 'AIR', ' special accou');
insert into lineitem values ('173', '13062', '326', '2', '42', '40952.52', '0.03', '0.02', 'A', 'F', '1993-04-02', '1993-02-13', '1993-04-18', 'DELIVER IN PERSON', 'REG AIR', 'etimes. theodolites cajole carefull');
insert into lineitem values ('173', '8829', '88', '3', '25', '43445.50', '0.07', '0.02', 'A', 'F', '1993-03-13', '1993-03-06', '1993-04-10', 'NONE', 'REG AIR', ' carefully ruthless id');
insert into lineitem values ('173', '19672', '942', '4', '18', '28650.06', '0.07', '0.08', 'A', 'F', '1993-01-20', '1993-01-18', '1993-02-18', 'DELIVER IN PERSON', 'TRUCK', 'multipliers cajole fluffily across the f');
insert into lineitem values ('173', '3631', '885', '5', '4', '6138.52', '0.07', '0.04', 'R', 'F', '1992-12-24', '1993-01-23', '1992-12-25', 'COLLECT COD', 'AIR', 'ffix about the silent pinto bea');
insert into lineitem values ('173', '1885', '388', '6', '47', '83983.36', '0.05', '0.00', 'R', 'F', '1993-02-24', '1993-02-24', '1993-03-26', 'COLLECT COD', 'FOB', 'nal gifts. blithely special platelets bo');
insert into lineitem values ('173', '17395', '663', '7', '31', '40684.09', '0.04', '0.08', 'R', 'F', '1993-02-18', '1993-01-30', '1993-03-02', 'NONE', 'RAIL', 'even, even packages. regu');
insert into orders values ('174', '3547', 'O', '175170.27', '1996-09-27', '2-HIGH', 'Clerk#000000378', '0', 'efully pending dolphins sleep slowly blithely ');
insert into lineitem values ('174', '15588', '384', '1', '21', '31575.18', '0.10', '0.02', 'N', 'O', '1996-09-30', '1996-12-16', '1996-10-30', 'COLLECT COD', 'TRUCK', ' deposits boost quickl');
insert into lineitem values ('174', '19969', '508', '2', '40', '75558.40', '0.08', '0.06', 'N', 'O', '1997-01-10', '1996-11-27', '1997-02-08', 'NONE', 'RAIL', 'usual packages are among the bold, unu');
insert into lineitem values ('174', '15651', '182', '3', '18', '28199.70', '0.04', '0.04', 'N', 'O', '1997-01-15', '1996-11-21', '1997-02-11', 'NONE', 'TRUCK', 'packages. carefully final accou');
insert into lineitem values ('174', '5470', '471', '4', '31', '42639.57', '0.00', '0.04', 'N', 'O', '1996-12-09', '1996-11-21', '1997-01-05', 'COLLECT COD', 'TRUCK', 'sits haggle fluffily specia');
insert into orders values ('175', '4276', 'F', '135001.66', '1992-07-05', '5-LOW', 'Clerk#000000562', '0', 'blithely ironic requests s');
insert into lineitem values ('175', '9364', '142', '1', '24', '30560.64', '0.03', '0.03', 'R', 'F', '1992-08-04', '1992-08-19', '1992-08-29', 'DELIVER IN PERSON', 'REG AIR', 'inal accounts. regular pinto ');
insert into lineitem values ('175', '17035', '837', '2', '38', '36177.14', '0.00', '0.02', 'A', 'F', '1992-10-14', '1992-08-29', '1992-11-02', 'DELIVER IN PERSON', 'FOB', 'le slyly across the carefully ir');
insert into lineitem values ('175', '18205', '742', '3', '43', '48297.60', '0.01', '0.08', 'R', 'F', '1992-10-04', '1992-09-07', '1992-10-23', 'TAKE BACK RETURN', 'AIR', 'jole finally. silent reques');
insert into lineitem values ('175', '16019', '552', '4', '18', '16830.18', '0.09', '0.04', 'A', 'F', '1992-09-27', '1992-09-27', '1992-10-16', 'COLLECT COD', 'AIR', 'e furiously final a');
insert into orders values ('200', '1933', 'F', '56324.74', '1992-10-15', '5-LOW', 'Clerk#000000727', '0', 'er the dinos sleep blithely alongside o');
insert into lineitem values ('200', '19793', '63', '1', '34', '58234.86', '0.07', '0.04', 'A', 'F', '1992-12-24', '1992-11-21', '1993-01-01', 'COLLECT COD', 'SHIP', 'lithely silent excuses');
insert into orders values ('201', '8606', 'F', '32535.19', '1992-08-02', '3-MEDIUM', 'Clerk#000000646', '0', 'ost according to the ironic, final packages;');
insert into lineitem values ('201', '1150', '904', '1', '1', '1051.15', '0.04', '0.06', 'R', 'F', '1992-08-26', '1992-09-09', '1992-08-30', 'NONE', 'RAIL', 'ial waters. fluffily even accou');
insert into lineitem values ('201', '3230', '484', '2', '10', '11332.30', '0.05', '0.05', 'A', 'F', '1992-10-29', '1992-09-26', '1992-11-09', 'COLLECT COD', 'SHIP', 'lites around the slyly ');
insert into lineitem values ('201', '379', '130', '3', '17', '21749.29', '0.10', '0.03', 'A', 'F', '1992-08-15', '1992-10-28', '1992-09-01', 'COLLECT COD', 'FOB', 'ess foxes affix blithely unusual ide');
insert into orders values ('202', '9311', 'O', '70229.10', '1997-03-22', '2-HIGH', 'Clerk#000000913', '0', 'ckages could have to thrash alongside of the blithely express fo');
insert into lineitem values ('202', '160', '661', '1', '13', '13782.08', '0.02', '0.08', 'N', 'O', '1997-06-03', '1997-06-02', '1997-06-09', 'TAKE BACK RETURN', 'RAIL', 's are above the regular');
insert into lineitem values ('202', '7383', '641', '2', '25', '32259.50', '0.00', '0.02', 'N', 'O', '1997-04-09', '1997-06-16', '1997-04-22', 'TAKE BACK RETURN', 'SHIP', 'e according to the idly unusual accounts. ');
insert into lineitem values ('202', '3250', '504', '3', '20', '23065.00', '0.07', '0.06', 'N', 'O', '1997-06-23', '1997-05-07', '1997-06-25', 'DELIVER IN PERSON', 'REG AIR', 'ly express pinto beans about the bol');
insert into orders values ('203', '13043', 'F', '318560.83', '1994-05-30', '2-HIGH', 'Clerk#000000517', '0', ' sleep quickly on the slyly ironic dependencies. accounts a');
insert into lineitem values ('203', '4852', '615', '1', '32', '56219.20', '0.07', '0.05', 'R', 'F', '1994-09-03', '1994-07-12', '1994-10-02', 'NONE', 'SHIP', 'the regular dep');
insert into lineitem values ('203', '17278', '279', '2', '28', '33467.56', '0.07', '0.02', 'R', 'F', '1994-06-01', '1994-07-24', '1994-06-15', 'DELIVER IN PERSON', 'TRUCK', ' slyly bold deposits; ');
insert into lineitem values ('203', '8659', '918', '3', '23', '36055.95', '0.08', '0.07', 'R', 'F', '1994-06-16', '1994-08-25', '1994-07-08', 'DELIVER IN PERSON', 'REG AIR', 'es was slyly furious');
insert into lineitem values ('203', '5715', '971', '4', '13', '21069.23', '0.10', '0.00', 'A', 'F', '1994-08-15', '1994-06-30', '1994-08-22', 'DELIVER IN PERSON', 'SHIP', ' final request');
insert into lineitem values ('203', '6929', '186', '5', '32', '58749.44', '0.09', '0.04', 'R', 'F', '1994-08-12', '1994-07-12', '1994-08-16', 'DELIVER IN PERSON', 'SHIP', 'efully final orbits haggle ');
insert into lineitem values ('203', '14914', '443', '6', '32', '58525.12', '0.03', '0.03', 'R', 'F', '1994-09-12', '1994-07-08', '1994-10-12', 'NONE', 'SHIP', 'ss accounts are! fluffily');
insert into lineitem values ('203', '14727', '728', '7', '39', '64027.08', '0.01', '0.00', 'R', 'F', '1994-07-02', '1994-07-09', '1994-07-28', 'TAKE BACK RETURN', 'AIR', 'near the slyly even deposits. ca');
insert into orders values ('204', '3409', 'O', '54919.44', '1996-02-29', '1-URGENT', 'Clerk#000000569', '0', 'ts. slyly special instructions are. carefully even re');
insert into lineitem values ('204', '12973', '760', '1', '32', '60351.04', '0.09', '0.00', 'N', 'O', '1996-05-26', '1996-04-23', '1996-06-19', 'DELIVER IN PERSON', 'REG AIR', 'y fluffily ironic asymptotes. ');
insert into orders values ('205', '7031', 'F', '131082.59', '1993-07-02', '4-NOT SPECIFIED', 'Clerk#000000047', '0', 'al requests cajole furiously. carefully express ide');
insert into lineitem values ('205', '1824', '825', '1', '8', '13806.56', '0.09', '0.05', 'A', 'F', '1993-10-12', '1993-09-06', '1993-10-30', 'DELIVER IN PERSON', 'FOB', 'eep furiously even requests. quick');
insert into lineitem values ('205', '8552', '69', '2', '41', '59882.55', '0.04', '0.00', 'A', 'F', '1993-08-01', '1993-08-03', '1993-08-03', 'NONE', 'TRUCK', 'sts about t');
insert into lineitem values ('205', '2112', '113', '3', '2', '2028.22', '0.03', '0.07', 'A', 'F', '1993-08-21', '1993-09-17', '1993-08-29', 'NONE', 'TRUCK', 'st furiously furiously unusual packa');
insert into lineitem values ('205', '2161', '162', '4', '38', '40400.08', '0.01', '0.07', 'R', 'F', '1993-10-21', '1993-09-08', '1993-11-17', 'TAKE BACK RETURN', 'REG AIR', ' the blithely');
insert into lineitem values ('205', '11419', '203', '5', '11', '14634.51', '0.01', '0.07', 'A', 'F', '1993-09-11', '1993-08-18', '1993-09-13', 'NONE', 'TRUCK', 'sleep furiously. regular, regular pack');
insert into orders values ('206', '3262', 'F', '118737.17', '1994-03-04', '2-HIGH', 'Clerk#000000725', '0', 'sits. furiously unusual deposits sleep slyly. even epitaphs wake blithe');
insert into lineitem values ('206', '18326', '595', '1', '30', '37329.60', '0.05', '0.01', 'A', 'F', '1994-04-03', '1994-04-20', '1994-04-16', 'COLLECT COD', 'MAIL', 'sual pinto beans');
insert into lineitem values ('206', '13879', '406', '2', '10', '17928.70', '0.02', '0.04', 'R', 'F', '1994-05-04', '1994-04-21', '1994-05-24', 'DELIVER IN PERSON', 'AIR', ' according to the q');
insert into lineitem values ('206', '14868', '133', '3', '37', '65965.82', '0.02', '0.00', 'R', 'F', '1994-06-21', '1994-04-05', '1994-07-19', 'DELIVER IN PERSON', 'SHIP', '. furiousl');
insert into orders values ('207', '8591', 'F', '10967.06', '1994-06-07', '2-HIGH', 'Clerk#000000079', '0', 'y. ironic accounts cajole sometimes-- slyly ironic requests b');
insert into lineitem values ('207', '6274', '43', '1', '10', '11802.70', '0.08', '0.01', 'R', 'F', '1994-10-01', '1994-08-07', '1994-10-31', 'COLLECT COD', 'REG AIR', ' deposits are bl');
insert into orders values ('232', '9287', 'O', '224895.53', '1997-11-07', '4-NOT SPECIFIED', 'Clerk#000000540', '0', 's are quickly above the bold, ironic packages-- b');
insert into lineitem values ('232', '17200', '2', '1', '38', '42453.60', '0.10', '0.06', 'N', 'O', '1998-02-06', '1997-12-13', '1998-03-02', 'COLLECT COD', 'MAIL', 'furiously. carefully final dol');
insert into lineitem values ('232', '18634', '635', '2', '18', '27947.34', '0.08', '0.08', 'N', 'O', '1997-12-10', '1998-01-20', '1998-01-03', 'NONE', 'AIR', 'e blithely. ironic, ');
insert into lineitem values ('232', '16248', '249', '3', '9', '10478.16', '0.02', '0.04', 'N', 'O', '1998-02-16', '1998-01-03', '1998-03-13', 'COLLECT COD', 'TRUCK', 'dencies. final, unusual d');
insert into lineitem values ('232', '4244', '753', '4', '19', '21816.56', '0.03', '0.03', 'N', 'O', '1997-11-13', '1997-12-10', '1997-12-05', 'DELIVER IN PERSON', 'MAIL', 'carefully furiously quiet deposits. furiou');
insert into lineitem values ('232', '5586', '352', '5', '38', '56680.04', '0.05', '0.08', 'N', 'O', '1998-02-13', '1998-01-20', '1998-02-15', 'TAKE BACK RETURN', 'SHIP', 'n deposits. slyly regular fra');
insert into lineitem values ('232', '16615', '148', '6', '13', '19910.93', '0.02', '0.07', 'N', 'O', '1997-11-26', '1998-01-28', '1997-11-28', 'COLLECT COD', 'FOB', 'thely. furiously regular depo');
insert into lineitem values ('232', '1852', '104', '7', '25', '43846.25', '0.02', '0.05', 'N', 'O', '1998-01-28', '1997-12-24', '1998-02-10', 'NONE', 'RAIL', ': regular ideas');
insert into orders values ('233', '11332', 'O', '30351.68', '1996-09-26', '3-MEDIUM', 'Clerk#000000865', '0', 'ts grow slyly final,');
insert into lineitem values ('233', '19376', '915', '1', '20', '25907.40', '0.03', '0.03', 'N', 'O', '1996-10-13', '1996-11-25', '1996-10-30', 'DELIVER IN PERSON', 'SHIP', 'yly regular theodolites boost about the f');
insert into lineitem values ('233', '9709', '710', '2', '3', '4856.10', '0.08', '0.00', 'N', 'O', '1996-11-19', '1996-12-24', '1996-12-03', 'DELIVER IN PERSON', 'REG AIR', 'sly ironic requests. slyly ruthless packag');
insert into orders values ('234', '85', 'O', '234104.58', '1996-06-26', '5-LOW', 'Clerk#000000573', '0', 'packages cajole at the quickly ironic pinto beans. bol');
insert into lineitem values ('234', '19876', '415', '1', '46', '82610.02', '0.02', '0.07', 'N', 'O', '1996-06-30', '1996-09-09', '1996-07-17', 'DELIVER IN PERSON', 'FOB', 'into beans n');
insert into lineitem values ('234', '10730', '511', '2', '2', '3281.46', '0.10', '0.06', 'N', 'O', '1996-08-06', '1996-08-19', '1996-08-12', 'COLLECT COD', 'AIR', 'unts grow furiously blithely ');
insert into lineitem values ('234', '4411', '666', '3', '10', '13154.10', '0.05', '0.06', 'N', 'O', '1996-08-18', '1996-07-29', '1996-09-07', 'NONE', 'TRUCK', 'across the ');
insert into lineitem values ('234', '13770', '34', '4', '21', '35359.17', '0.03', '0.03', 'N', 'O', '1996-07-22', '1996-08-03', '1996-07-25', 'DELIVER IN PERSON', 'REG AIR', ' quickly unusual packages cajole quic');
insert into lineitem values ('234', '1409', '912', '5', '30', '39312.00', '0.07', '0.08', 'N', 'O', '1996-08-03', '1996-08-08', '1996-08-11', 'COLLECT COD', 'AIR', 'ffy accounts sleep quickly d');
insert into lineitem values ('234', '15536', '67', '6', '37', '53706.61', '0.06', '0.05', 'N', 'O', '1996-09-09', '1996-09-10', '1996-10-08', 'TAKE BACK RETURN', 'TRUCK', 'uctions integ');
insert into lineitem values ('234', '883', '134', '7', '2', '3567.76', '0.08', '0.00', 'N', 'O', '1996-06-29', '1996-08-11', '1996-07-24', 'NONE', 'AIR', 'nic, bold requests. asymptotes across the');
insert into orders values ('235', '12820', 'F', '113367.62', '1992-12-02', '1-URGENT', 'Clerk#000000055', '0', 'yly furiously regular the');
insert into lineitem values ('235', '9859', '378', '1', '40', '70754.00', '0.00', '0.04', 'R', 'F', '1993-03-22', '1993-01-06', '1993-04-10', 'TAKE BACK RETURN', 'AIR', 'eposits sleep carefully');
insert into lineitem values ('235', '10166', '947', '2', '12', '12913.92', '0.06', '0.03', 'R', 'F', '1993-01-20', '1993-02-04', '1993-02-09', 'DELIVER IN PERSON', 'TRUCK', 'according to the instructions ');
insert into lineitem values ('235', '9604', '605', '3', '19', '28758.40', '0.07', '0.02', 'R', 'F', '1993-02-08', '1993-03-02', '1993-02-10', 'COLLECT COD', 'FOB', ' are furio');
insert into orders values ('236', '4639', 'F', '231817.40', '1992-03-01', '1-URGENT', 'Clerk#000000794', '0', 'ironic accounts impress');
insert into lineitem values ('236', '19676', '484', '1', '22', '35104.74', '0.10', '0.04', 'A', 'F', '1992-03-07', '1992-04-13', '1992-03-31', 'DELIVER IN PERSON', 'SHIP', 'as nag fluffily foxes. ironic pinto ');
insert into lineitem values ('236', '8971', '746', '2', '18', '33839.46', '0.07', '0.04', 'A', 'F', '1992-03-05', '1992-04-30', '1992-03-09', 'DELIVER IN PERSON', 'REG AIR', 'against the quick');
insert into lineitem values ('236', '11417', '940', '3', '30', '39852.30', '0.06', '0.08', 'R', 'F', '1992-05-03', '1992-04-09', '1992-05-29', 'DELIVER IN PERSON', 'SHIP', 'sleep blith');
insert into lineitem values ('236', '19549', '88', '4', '49', '71958.46', '0.04', '0.04', 'A', 'F', '1992-04-04', '1992-03-31', '1992-04-22', 'NONE', 'TRUCK', 'fily after ');
insert into lineitem values ('236', '7944', '716', '5', '32', '59262.08', '0.09', '0.00', 'R', 'F', '1992-03-12', '1992-05-28', '1992-03-14', 'NONE', 'RAIL', 'ven pinto beans. dependencies sleep furiou');
insert into orders values ('237', '8765', 'O', '335385.93', '1995-09-09', '3-MEDIUM', 'Clerk#000000985', '0', 'r platelets boost. deposits haggle-- blithely bold deposits print ');
insert into lineitem values ('237', '6858', '859', '1', '19', '33532.15', '0.04', '0.04', 'N', 'O', '1995-11-29', '1995-12-05', '1995-12-10', 'COLLECT COD', 'REG AIR', 'ents nag: requests are slyly final, even ');
insert into lineitem values ('237', '8943', '202', '2', '44', '81485.36', '0.06', '0.00', 'N', 'O', '1995-11-07', '1995-10-25', '1995-11-26', 'COLLECT COD', 'RAIL', ' the pending, bold i');
insert into lineitem values ('237', '19614', '884', '3', '24', '36806.64', '0.04', '0.01', 'N', 'O', '1995-10-12', '1995-11-30', '1995-11-05', 'DELIVER IN PERSON', 'RAIL', ' final accounts boost');
insert into lineitem values ('237', '9728', '988', '4', '49', '80248.28', '0.01', '0.04', 'N', 'O', '1995-12-18', '1995-11-10', '1996-01-15', 'TAKE BACK RETURN', 'REG AIR', 'es. slyly ironic requests ');
insert into lineitem values ('237', '13159', '423', '5', '36', '38597.40', '0.08', '0.03', 'N', 'O', '1995-09-27', '1995-12-05', '1995-10-02', 'NONE', 'REG AIR', 'xpress deposits. carefully final excuses al');
insert into lineitem values ('237', '8500', '501', '6', '50', '70425.00', '0.00', '0.00', 'N', 'O', '1995-11-08', '1995-11-15', '1995-11-09', 'COLLECT COD', 'FOB', 'ieve against the final, quiet theodolites. ');
insert into orders values ('238', '3706', 'F', '248986.42', '1993-07-23', '3-MEDIUM', 'Clerk#000000165', '0', 'rhorses boost slyly pending instructions. quickly regular deposits');
insert into lineitem values ('238', '8198', '973', '1', '48', '53097.12', '0.08', '0.08', 'R', 'F', '1993-10-22', '1993-09-18', '1993-11-07', 'COLLECT COD', 'MAIL', 's. even, bold foxes doubt blithe');
insert into lineitem values ('238', '3531', '38', '2', '47', '67422.91', '0.10', '0.01', 'A', 'F', '1993-09-13', '1993-08-28', '1993-09-20', 'NONE', 'AIR', 'al, special deposits ');
insert into lineitem values ('238', '15527', '58', '3', '8', '11540.16', '0.09', '0.03', 'R', 'F', '1993-10-29', '1993-08-22', '1993-10-30', 'DELIVER IN PERSON', 'MAIL', 'sts alongsi');
insert into lineitem values ('238', '1816', '319', '4', '32', '54969.92', '0.05', '0.01', 'A', 'F', '1993-11-05', '1993-09-19', '1993-11-18', 'NONE', 'TRUCK', 'arefully thin deposits sleep slyly ');
insert into lineitem values ('238', '9640', '900', '5', '28', '43389.92', '0.05', '0.06', 'A', 'F', '1993-10-23', '1993-08-31', '1993-10-25', 'COLLECT COD', 'RAIL', 'iously ironic reques');
insert into lineitem values ('238', '8972', '489', '6', '16', '30095.52', '0.08', '0.00', 'A', 'F', '1993-11-18', '1993-09-05', '1993-11-22', 'TAKE BACK RETURN', 'REG AIR', 'as are slyly carefully regular ');
insert into orders values ('239', '14818', 'F', '198959.21', '1992-04-01', '3-MEDIUM', 'Clerk#000000620', '0', 'ly final instructions along the ironic accounts breach ideas! blithely brave ');
insert into lineitem values ('239', '9324', '325', '1', '26', '32066.32', '0.05', '0.00', 'A', 'F', '1992-07-16', '1992-05-12', '1992-08-07', 'NONE', 'AIR', 'lphins are slyly across the platelets. r');
insert into lineitem values ('239', '7409', '410', '2', '46', '60554.40', '0.05', '0.08', 'A', 'F', '1992-04-28', '1992-06-24', '1992-05-02', 'TAKE BACK RETURN', 'FOB', 'across the regular ideas affix quickly fluf');
insert into lineitem values ('239', '8220', '479', '3', '14', '15795.08', '0.03', '0.05', 'R', 'F', '1992-04-18', '1992-06-14', '1992-04-23', 'TAKE BACK RETURN', 'AIR', 'ackages sleep around the slyly');
insert into lineitem values ('239', '13083', '610', '4', '22', '21913.76', '0.10', '0.00', 'A', 'F', '1992-04-23', '1992-05-12', '1992-05-14', 'NONE', 'AIR', 'ing, even requests breach about t');
insert into lineitem values ('239', '14669', '670', '5', '48', '76015.68', '0.09', '0.02', 'R', 'F', '1992-04-09', '1992-05-29', '1992-05-08', 'TAKE BACK RETURN', 'MAIL', 'totes! ironic, final');
insert into orders values ('264', '6877', 'F', '125647.27', '1992-07-30', '5-LOW', 'Clerk#000000595', '0', 'ular requests thrash boldly across the furiously special deposits! carefu');
insert into lineitem values ('264', '9257', '35', '1', '25', '29156.25', '0.03', '0.03', 'A', 'F', '1992-10-16', '1992-10-16', '1992-11-14', 'NONE', 'AIR', 'nto beans. quickly special theo');
insert into lineitem values ('264', '11471', '733', '2', '36', '49768.92', '0.09', '0.05', 'A', 'F', '1992-10-12', '1992-10-26', '1992-10-31', 'DELIVER IN PERSON', 'TRUCK', 'uffily. slyly regular ');
insert into lineitem values ('264', '589', '340', '3', '32', '47666.56', '0.04', '0.07', 'R', 'F', '1992-09-13', '1992-09-08', '1992-10-11', 'DELIVER IN PERSON', 'MAIL', 'kages. slyly regu');
insert into orders values ('265', '11132', 'O', '10577.89', '1996-07-25', '3-MEDIUM', 'Clerk#000000670', '0', 's. fluffily regular packages nag carefully special accounts. pinto');
insert into lineitem values ('265', '1693', '945', '1', '7', '11162.83', '0.08', '0.03', 'N', 'O', '1996-11-07', '1996-08-30', '1996-11-24', 'NONE', 'MAIL', 's deposits above the slyly final excu');
insert into orders values ('266', '8569', 'F', '41113.60', '1994-07-29', '5-LOW', 'Clerk#000000371', '0', 'lar realms. unusual foxes use a');
insert into lineitem values ('266', '3290', '50', '1', '35', '41765.15', '0.08', '0.07', 'A', 'F', '1994-08-13', '1994-09-22', '1994-08-22', 'COLLECT COD', 'AIR', ' furiously slyly unusual foxes. furiou');
insert into orders values ('267', '6427', 'F', '288305.62', '1995-02-13', '4-NOT SPECIFIED', 'Clerk#000000333', '0', 'ironic Tiresias haggle slyly final deposits. d');
insert into lineitem values ('267', '15340', '341', '1', '34', '42681.56', '0.09', '0.03', 'R', 'F', '1995-04-20', '1995-04-04', '1995-05-14', 'COLLECT COD', 'MAIL', 'anently even reques');
insert into lineitem values ('267', '15826', '357', '2', '30', '52254.60', '0.08', '0.02', 'R', 'F', '1995-04-10', '1995-03-25', '1995-05-06', 'NONE', 'MAIL', 'r packages wake furiousl');
insert into lineitem values ('267', '5065', '66', '3', '36', '34922.16', '0.04', '0.00', 'A', 'F', '1995-05-31', '1995-03-17', '1995-06-09', 'DELIVER IN PERSON', 'RAIL', 'gouts-- quickly sp');
insert into lineitem values ('267', '569', '320', '4', '38', '55843.28', '0.07', '0.07', 'R', 'F', '1995-04-10', '1995-03-23', '1995-04-21', 'DELIVER IN PERSON', 'REG AIR', 'ilent, ruthless ide');
insert into lineitem values ('267', '9239', '758', '5', '50', '57411.50', '0.05', '0.02', 'A', 'F', '1995-03-17', '1995-05-05', '1995-04-09', 'TAKE BACK RETURN', 'FOB', 'cial requests ar');
insert into lineitem values ('267', '3289', '543', '6', '45', '53652.60', '0.05', '0.07', 'R', 'F', '1995-05-16', '1995-05-06', '1995-05-18', 'COLLECT COD', 'TRUCK', 'ing foxes. furiously iro');
insert into orders values ('268', '10162', 'O', '106040.13', '1997-03-12', '2-HIGH', 'Clerk#000000928', '0', 'to the carefully regular accounts haggle qui');
insert into lineitem values ('268', '825', '326', '1', '35', '60403.70', '0.10', '0.05', 'N', 'O', '1997-05-24', '1997-04-12', '1997-06-21', 'NONE', 'REG AIR', 'ing deposits wake dog');
insert into lineitem values ('268', '19095', '365', '2', '47', '47662.23', '0.04', '0.07', 'N', 'O', '1997-07-01', '1997-04-17', '1997-07-20', 'COLLECT COD', 'TRUCK', 'ndencies. furiously final tithe');
insert into orders values ('269', '3952', 'F', '123617.55', '1995-03-01', '4-NOT SPECIFIED', 'Clerk#000000343', '0', ' excuses nag blithely slyly unusual dep');
insert into lineitem values ('269', '4221', '730', '1', '26', '29255.72', '0.04', '0.01', 'R', 'F', '1995-04-04', '1995-05-18', '1995-05-04', 'NONE', 'TRUCK', 'ithely final ideas. blithely eve');
insert into lineitem values ('269', '2317', '318', '2', '14', '17070.34', '0.02', '0.05', 'R', 'F', '1995-04-14', '1995-04-14', '1995-04-16', 'DELIVER IN PERSON', 'RAIL', 'kages cajole accord');
insert into lineitem values ('269', '5931', '442', '3', '34', '62455.62', '0.08', '0.03', 'A', 'F', '1995-04-01', '1995-04-09', '1995-04-18', 'TAKE BACK RETURN', 'AIR', 'al pinto beans nag instructions. car');
insert into lineitem values ('269', '10480', '741', '4', '4', '5561.92', '0.04', '0.00', 'R', 'F', '1995-05-29', '1995-05-16', '1995-06-12', 'COLLECT COD', 'FOB', 'counts: warhorses use carefully.');
insert into lineitem values ('269', '6922', '691', '5', '7', '12802.44', '0.03', '0.06', 'A', 'F', '1995-04-02', '1995-05-10', '1995-04-03', 'NONE', 'AIR', 'ts. slyly final ');
insert into orders values ('270', '1133', 'O', '219758.02', '1997-03-03', '3-MEDIUM', 'Clerk#000000323', '0', 'ackages wake furiously. blithely bold deposits are carefully. deposits ar');
insert into lineitem values ('270', '17211', '13', '1', '23', '25948.83', '0.04', '0.05', 'N', 'O', '1997-04-22', '1997-05-01', '1997-05-09', 'DELIVER IN PERSON', 'FOB', 'ly fluffily ironic packages. fluffily re');
insert into lineitem values ('270', '11816', '339', '2', '49', '84662.69', '0.08', '0.03', 'N', 'O', '1997-04-17', '1997-05-25', '1997-04-27', 'DELIVER IN PERSON', 'MAIL', 'hless packages nag slyly. furiously ');
insert into lineitem values ('270', '7054', '826', '3', '49', '47091.45', '0.06', '0.05', 'N', 'O', '1997-06-29', '1997-05-10', '1997-07-10', 'TAKE BACK RETURN', 'TRUCK', ' after the reque');
insert into lineitem values ('270', '13926', '190', '4', '18', '33118.56', '0.08', '0.00', 'N', 'O', '1997-03-19', '1997-05-04', '1997-04-13', 'DELIVER IN PERSON', 'FOB', 's. regular, express requests ');
insert into lineitem values ('270', '4878', '133', '5', '6', '10697.22', '0.01', '0.03', 'N', 'O', '1997-05-05', '1997-04-24', '1997-05-16', 'COLLECT COD', 'RAIL', 'the furiously express instructions. quickly');
insert into lineitem values ('270', '700', '201', '6', '16', '25611.20', '0.06', '0.06', 'N', 'O', '1997-03-10', '1997-04-08', '1997-03-17', 'NONE', 'REG AIR', 'express foxes are re');
insert into orders values ('271', '7907', 'O', '335121.22', '1996-02-20', '1-URGENT', 'Clerk#000000240', '0', 's. boldly bold attainments detect regular foxes. deposits boost');
insert into lineitem values ('271', '3585', '586', '1', '32', '47634.56', '0.07', '0.07', 'N', 'O', '1996-02-29', '1996-03-29', '1996-03-10', 'NONE', 'FOB', 'ainst the carefully regu');
insert into lineitem values ('271', '1741', '244', '2', '26', '42711.24', '0.01', '0.01', 'N', 'O', '1996-03-29', '1996-03-21', '1996-04-24', 'TAKE BACK RETURN', 'REG AIR', 'ackages. evenly u');
insert into lineitem values ('271', '10736', '517', '3', '45', '74102.85', '0.10', '0.03', 'N', 'O', '1996-03-11', '1996-04-25', '1996-04-03', 'NONE', 'MAIL', 'eep according to');
insert into lineitem values ('271', '8552', '327', '4', '44', '64264.20', '0.01', '0.05', 'N', 'O', '1996-04-16', '1996-04-14', '1996-04-29', 'NONE', 'TRUCK', 'tions. blithely thin ideas boost around the');
insert into lineitem values ('271', '17671', '939', '5', '41', '65135.47', '0.10', '0.07', 'N', 'O', '1996-04-03', '1996-04-29', '1996-05-03', 'NONE', 'RAIL', 'ckages. instructions instea');
insert into lineitem values ('271', '7620', '135', '6', '2', '3055.24', '0.06', '0.01', 'N', 'O', '1996-05-10', '1996-04-23', '1996-05-13', 'COLLECT COD', 'MAIL', 'ly unusual theo');
insert into lineitem values ('271', '959', '710', '7', '23', '42778.85', '0.05', '0.08', 'N', 'O', '1996-03-02', '1996-04-02', '1996-03-19', 'COLLECT COD', 'REG AIR', ' above the carefully final ');
insert into orders values ('296', '3100', 'O', '161680.45', '1995-12-16', '3-MEDIUM', 'Clerk#000000830', '0', 'posits cajole special, bold asymptotes? doggedly ironic ideas after the ');
insert into lineitem values ('296', '12229', '492', '1', '14', '15977.08', '0.04', '0.03', 'N', 'O', '1996-02-12', '1996-03-02', '1996-03-04', 'DELIVER IN PERSON', 'TRUCK', 'y ironic forges. carefully ironic ide');
insert into lineitem values ('296', '10859', '120', '2', '39', '69024.15', '0.02', '0.03', 'N', 'O', '1996-01-22', '1996-02-07', '1996-02-20', 'TAKE BACK RETURN', 'AIR', 'ven accounts. furiously unusual');
insert into lineitem values ('296', '884', '385', '3', '46', '82104.48', '0.09', '0.02', 'N', 'O', '1996-01-07', '1996-03-12', '1996-01-12', 'DELIVER IN PERSON', 'FOB', 'ss the closely regular pa');
insert into orders values ('297', '4105', 'F', '5429.56', '1992-10-27', '4-NOT SPECIFIED', 'Clerk#000000275', '0', 'as are carefully. carefully final packages thra');
insert into lineitem values ('297', '7851', '366', '1', '3', '5276.55', '0.02', '0.05', 'R', 'F', '1992-10-30', '1992-12-21', '1992-11-22', 'TAKE BACK RETURN', 'TRUCK', 'furiously according to the fur');
insert into orders values ('298', '10328', 'O', '252713.55', '1996-04-25', '5-LOW', 'Clerk#000000546', '0', 'counts wake quickly. quickly regula');
insert into lineitem values ('298', '11552', '553', '1', '47', '68786.85', '0.03', '0.01', 'N', 'O', '1996-04-29', '1996-07-14', '1996-05-16', 'NONE', 'AIR', 'o beans. slyly final dolphins are blithel');
insert into lineitem values ('298', '11060', '844', '2', '22', '21363.32', '0.02', '0.03', 'N', 'O', '1996-06-30', '1996-06-28', '1996-07-28', 'TAKE BACK RETURN', 'REG AIR', 'o the unusual p');
insert into lineitem values ('298', '10915', '696', '3', '20', '36518.20', '0.04', '0.00', 'N', 'O', '1996-08-08', '1996-07-22', '1996-08-15', 'TAKE BACK RETURN', 'REG AIR', 'ests sleep');
insert into lineitem values ('298', '17092', '627', '4', '18', '18163.62', '0.05', '0.01', 'N', 'O', '1996-07-23', '1996-06-16', '1996-07-26', 'COLLECT COD', 'TRUCK', 'equests? blith');
insert into lineitem values ('298', '1411', '663', '5', '23', '30185.43', '0.01', '0.00', 'N', 'O', '1996-06-13', '1996-07-17', '1996-06-15', 'TAKE BACK RETURN', 'SHIP', 'ial, regular dependencies affix. silently');
insert into lineitem values ('298', '18897', '434', '6', '14', '25422.46', '0.06', '0.05', 'N', 'O', '1996-06-30', '1996-06-26', '1996-07-28', 'NONE', 'MAIL', 's haggle blithely across the fluf');
insert into lineitem values ('298', '15919', '185', '7', '32', '58717.12', '0.06', '0.02', 'N', 'O', '1996-05-25', '1996-07-17', '1996-06-03', 'COLLECT COD', 'AIR', ' ironic packag');
insert into orders values ('299', '7933', 'F', '45769.43', '1993-10-23', '4-NOT SPECIFIED', 'Clerk#000000914', '0', 'en accounts. regular, bold sauternes d');
insert into lineitem values ('299', '1521', '773', '1', '31', '44098.12', '0.03', '0.07', 'R', 'F', '1993-12-02', '1993-12-22', '1993-12-04', 'NONE', 'FOB', ' theodolites boost carefully. a');
insert into orders values ('300', '6283', 'F', '63999.57', '1993-10-10', '5-LOW', 'Clerk#000000424', '0', 'ites affix furiously bold requests. ideas detect regularly carefully ');
insert into lineitem values ('300', '583', '84', '1', '17', '25220.86', '0.04', '0.03', 'R', 'F', '1993-11-29', '1994-01-06', '1993-12-08', 'NONE', 'SHIP', 'ages. furiously ironic theodolite');
insert into lineitem values ('300', '7332', '590', '2', '34', '42137.22', '0.10', '0.03', 'A', 'F', '1993-11-30', '1994-01-02', '1993-12-26', 'TAKE BACK RETURN', 'AIR', ' ruthlessly express accounts along the unu');
insert into orders values ('301', '12382', 'O', '131235.59', '1995-12-08', '1-URGENT', 'Clerk#000000523', '0', 'uriously. ironic, final forges wake blithely among the');
insert into lineitem values ('301', '923', '424', '1', '40', '72956.80', '0.02', '0.08', 'N', 'O', '1996-01-27', '1996-01-25', '1996-02-22', 'TAKE BACK RETURN', 'SHIP', 'ans nag blithely. carefully ex');
insert into lineitem values ('301', '7721', '493', '2', '35', '57005.20', '0.08', '0.03', 'N', 'O', '1996-02-19', '1996-02-03', '1996-02-24', 'TAKE BACK RETURN', 'REG AIR', 'accounts. final requests cajole furiously ');
insert into orders values ('302', '11950', 'F', '32760.85', '1994-09-26', '5-LOW', 'Clerk#000000197', '0', 'ges are slyly furiously thin accounts. requests are among the bold requ');
insert into lineitem values ('302', '3918', '425', '1', '19', '34616.29', '0.09', '0.04', 'R', 'F', '1994-12-26', '1994-11-07', '1995-01-08', 'DELIVER IN PERSON', 'RAIL', 'e above the furiously ironic reques');
insert into orders values ('303', '8315', 'F', '104434.72', '1993-11-22', '3-MEDIUM', 'Clerk#000000558', '0', 'ake blithely express de');
insert into lineitem values ('303', '591', '592', '1', '4', '5966.36', '0.01', '0.02', 'A', 'F', '1993-12-22', '1993-12-31', '1994-01-11', 'COLLECT COD', 'RAIL', ' beneath the sl');
insert into lineitem values ('303', '18069', '338', '2', '42', '41456.52', '0.08', '0.01', 'A', 'F', '1994-01-18', '1994-01-29', '1994-01-29', 'COLLECT COD', 'AIR', 'are at the foxe');
insert into lineitem values ('303', '19908', '909', '3', '23', '42041.70', '0.02', '0.02', 'R', 'F', '1994-01-23', '1994-01-27', '1994-02-18', 'NONE', 'MAIL', 'ing theodolites hang ar');
insert into lineitem values ('303', '12758', '21', '4', '11', '18378.25', '0.10', '0.08', 'A', 'F', '1994-01-12', '1994-02-01', '1994-02-07', 'NONE', 'TRUCK', 'accounts bel');
insert into orders values ('328', '659', 'O', '141769.26', '1998-02-17', '5-LOW', 'Clerk#000000455', '0', ' ironic accounts sleep. fluffily even depos');
insert into lineitem values ('328', '4301', '302', '1', '13', '15668.90', '0.01', '0.05', 'N', 'O', '1998-03-31', '1998-04-12', '1998-04-03', 'TAKE BACK RETURN', 'REG AIR', 'e slyly close pinto beans. sometim');
insert into lineitem values ('328', '18425', '694', '2', '33', '44332.86', '0.04', '0.05', 'N', 'O', '1998-06-08', '1998-05-03', '1998-06-22', 'COLLECT COD', 'REG AIR', 'ctions wake blithely fina');
insert into lineitem values ('328', '1908', '909', '3', '48', '86875.20', '0.07', '0.00', 'N', 'O', '1998-03-06', '1998-04-06', '1998-03-31', 'DELIVER IN PERSON', 'FOB', 's sleep blithely express ');
insert into orders values ('329', '11983', 'O', '153713.19', '1995-07-16', '1-URGENT', 'Clerk#000000450', '0', 'riously express dependencies are fluffily final pinto beans. special pinto bea');
insert into lineitem values ('329', '18578', '847', '1', '20', '29931.40', '0.03', '0.03', 'N', 'O', '1995-08-29', '1995-08-17', '1995-09-16', 'DELIVER IN PERSON', 'FOB', 'requests detect ironically u');
insert into lineitem values ('329', '15220', '16', '2', '50', '56761.00', '0.08', '0.04', 'N', 'O', '1995-08-26', '1995-09-28', '1995-09-10', 'TAKE BACK RETURN', 'TRUCK', 'e blithely. furiously silent deposits a');
insert into lineitem values ('329', '7889', '404', '3', '27', '48515.76', '0.01', '0.08', 'N', 'O', '1995-09-04', '1995-09-02', '1995-10-02', 'NONE', 'MAIL', 'eposits sleep care');
insert into lineitem values ('329', '2183', '940', '4', '16', '17362.88', '0.06', '0.08', 'N', 'O', '1995-11-14', '1995-09-25', '1995-12-08', 'DELIVER IN PERSON', 'AIR', ' deposits. quickly even t');
insert into orders values ('330', '7327', 'F', '180591.62', '1993-04-21', '1-URGENT', 'Clerk#000000376', '0', 'osits cajole fluffily. carefully bold deposits cajo');
insert into lineitem values ('330', '13499', '763', '1', '12', '16949.88', '0.09', '0.04', 'R', 'F', '1993-06-10', '1993-07-20', '1993-06-20', 'DELIVER IN PERSON', 'AIR', 'lyly final requests? regular instru');
insert into lineitem values ('330', '8991', '250', '2', '41', '77899.59', '0.09', '0.00', 'R', 'F', '1993-07-28', '1993-07-09', '1993-08-14', 'DELIVER IN PERSON', 'REG AIR', 's haggle. regular d');
insert into lineitem values ('330', '2696', '453', '3', '11', '17585.59', '0.06', '0.05', 'A', 'F', '1993-05-14', '1993-06-12', '1993-06-08', 'NONE', 'MAIL', 'eat quickly final pinto beans. instruc');
insert into lineitem values ('330', '19445', '984', '4', '40', '54577.60', '0.10', '0.02', 'R', 'F', '1993-05-23', '1993-06-04', '1993-06-10', 'DELIVER IN PERSON', 'REG AIR', 'ss requests. quickly even platelets ');
insert into lineitem values ('330', '2937', '694', '5', '15', '27598.95', '0.06', '0.01', 'R', 'F', '1993-07-31', '1993-07-04', '1993-08-19', 'DELIVER IN PERSON', 'TRUCK', ' regular packages alongside of the expres');
insert into orders values ('331', '14516', 'F', '138868.52', '1993-05-23', '3-MEDIUM', 'Clerk#000000386', '0', 'ironic asymptotes. fluffy');
insert into lineitem values ('331', '5155', '666', '1', '1', '1060.15', '0.03', '0.07', 'A', 'F', '1993-08-04', '1993-08-11', '1993-08-14', 'DELIVER IN PERSON', 'MAIL', 'ar accounts ab');
insert into lineitem values ('331', '17922', '923', '2', '25', '45998.00', '0.10', '0.06', 'R', 'F', '1993-09-01', '1993-08-01', '1993-09-23', 'TAKE BACK RETURN', 'SHIP', ' braids sleep carefully furi');
insert into lineitem values ('331', '18360', '897', '3', '25', '31959.00', '0.02', '0.03', 'A', 'F', '1993-09-16', '1993-08-04', '1993-10-08', 'NONE', 'MAIL', 's. express acco');
insert into lineitem values ('331', '1229', '732', '4', '32', '36167.04', '0.03', '0.01', 'R', 'F', '1993-08-31', '1993-07-01', '1993-09-04', 'DELIVER IN PERSON', 'AIR', '. enticing, bold courts');
insert into lineitem values ('331', '98', '349', '5', '27', '26948.43', '0.10', '0.08', 'A', 'F', '1993-06-30', '1993-07-09', '1993-07-13', 'TAKE BACK RETURN', 'TRUCK', 'iously even requests. f');
insert into orders values ('332', '8906', 'O', '79577.50', '1996-12-18', '4-NOT SPECIFIED', 'Clerk#000000294', '0', 'tes boost blithely. ironic, fi');
insert into lineitem values ('332', '1471', '225', '1', '18', '24704.46', '0.10', '0.08', 'N', 'O', '1997-02-14', '1997-03-02', '1997-03-11', 'TAKE BACK RETURN', 'REG AIR', 'theodolites wake slyly pending ');
insert into lineitem values ('332', '9803', '581', '2', '8', '13702.40', '0.00', '0.03', 'N', 'O', '1997-01-29', '1997-01-18', '1997-02-06', 'DELIVER IN PERSON', 'RAIL', 'ely bold pinto beans boost c');
insert into lineitem values ('332', '7416', '931', '3', '29', '38378.89', '0.06', '0.07', 'N', 'O', '1997-01-01', '1997-03-16', '1997-01-02', 'NONE', 'FOB', ' dolphins boost. final pint');
insert into lineitem values ('332', '7043', '301', '4', '3', '2850.12', '0.01', '0.01', 'N', 'O', '1997-04-14', '1997-03-11', '1997-05-06', 'TAKE BACK RETURN', 'TRUCK', ' deposits accordin');
insert into orders values ('333', '2497', 'O', '129557.58', '1997-06-13', '2-HIGH', 'Clerk#000000846', '0', 'ions. express, even accounts dazzl');
insert into lineitem values ('333', '2312', '817', '1', '6', '7285.86', '0.08', '0.02', 'N', 'O', '1997-06-22', '1997-08-31', '1997-07-02', 'TAKE BACK RETURN', 'FOB', 'osits wake fluf');
insert into lineitem values ('333', '10828', '609', '2', '29', '50425.78', '0.03', '0.07', 'N', 'O', '1997-07-14', '1997-07-27', '1997-08-12', 'NONE', 'TRUCK', 'eposits sleep above the fina');
insert into lineitem values ('333', '711', '712', '3', '36', '58021.56', '0.02', '0.05', 'N', 'O', '1997-06-17', '1997-09-01', '1997-07-12', 'COLLECT COD', 'REG AIR', 'silent deposits are blithely acc');
insert into lineitem values ('333', '2690', '447', '4', '7', '11148.83', '0.07', '0.03', 'N', 'O', '1997-10-08', '1997-08-22', '1997-10-30', 'NONE', 'AIR', 'finally ironic foxes. packages across the');
insert into orders values ('334', '8818', 'F', '29573.27', '1994-06-09', '4-NOT SPECIFIED', 'Clerk#000000312', '0', 'eposits cajole furiously. furiously fin');
insert into lineitem values ('334', '6975', '232', '1', '15', '28229.55', '0.03', '0.08', 'R', 'F', '1994-07-01', '1994-07-10', '1994-07-17', 'DELIVER IN PERSON', 'TRUCK', 'warhorses nag fluffily unusual deposits.');
insert into orders values ('335', '13310', 'O', '88250.45', '1997-02-25', '1-URGENT', 'Clerk#000000176', '0', ' accounts. quickly expre');
insert into lineitem values ('335', '4311', '566', '1', '2', '2430.62', '0.06', '0.00', 'N', 'O', '1997-04-25', '1997-04-12', '1997-05-06', 'NONE', 'RAIL', 'al theodoli');
insert into lineitem values ('335', '7540', '798', '2', '11', '15922.94', '0.01', '0.03', 'N', 'O', '1997-04-02', '1997-04-22', '1997-04-26', 'DELIVER IN PERSON', 'TRUCK', 'nstructions wake ');
insert into lineitem values ('335', '12526', '527', '3', '21', '30208.92', '0.02', '0.08', 'N', 'O', '1997-06-03', '1997-03-28', '1997-06-15', 'COLLECT COD', 'REG AIR', 'dependencies d');
insert into lineitem values ('335', '1066', '67', '4', '37', '35781.22', '0.01', '0.01', 'N', 'O', '1997-05-16', '1997-05-16', '1997-06-13', 'DELIVER IN PERSON', 'RAIL', 'ar, even forges are furi');
insert into lineitem values ('335', '15055', '586', '5', '2', '1940.10', '0.01', '0.03', 'N', 'O', '1997-05-18', '1997-05-09', '1997-06-17', 'DELIVER IN PERSON', 'RAIL', 's. regular instruct');
insert into orders values ('360', '10915', 'F', '32539.48', '1992-03-02', '3-MEDIUM', 'Clerk#000000583', '0', 'braids use slyly alongside of the carefully ironic t');
insert into lineitem values ('360', '13700', '964', '1', '13', '20978.10', '0.09', '0.03', 'R', 'F', '1992-05-21', '1992-05-08', '1992-06-15', 'TAKE BACK RETURN', 'REG AIR', 's. final packages doze. pa');
insert into lineitem values ('360', '1258', '761', '2', '11', '12751.75', '0.01', '0.02', 'A', 'F', '1992-06-29', '1992-05-09', '1992-07-14', 'DELIVER IN PERSON', 'MAIL', 'es against the pending, bold dept');
insert into orders values ('361', '6470', 'F', '194962.65', '1993-11-12', '2-HIGH', 'Clerk#000000558', '0', 'ely special theodolites cajole furiously bold, ev');
insert into lineitem values ('361', '18726', '263', '1', '25', '41118.00', '0.06', '0.04', 'R', 'F', '1993-11-13', '1994-01-15', '1993-11-17', 'COLLECT COD', 'FOB', 'c packages haggle carefully accounts. slyly');
insert into lineitem values ('361', '5109', '875', '2', '40', '40564.00', '0.02', '0.00', 'A', 'F', '1994-01-04', '1993-12-28', '1994-01-20', 'COLLECT COD', 'FOB', 'ding to the furiously bold asymptotes');
insert into lineitem values ('361', '13977', '241', '3', '19', '35928.43', '0.01', '0.08', 'A', 'F', '1994-01-11', '1993-12-25', '1994-02-02', 'NONE', 'SHIP', 'even pinto beans a');
insert into lineitem values ('361', '10104', '885', '4', '12', '12169.20', '0.07', '0.06', 'R', 'F', '1993-11-21', '1994-01-20', '1993-12-20', 'COLLECT COD', 'FOB', 'fily regular foxes along the final in');
insert into lineitem values ('361', '7808', '580', '5', '37', '63484.60', '0.04', '0.06', 'R', 'F', '1994-03-13', '1994-01-13', '1994-04-04', 'DELIVER IN PERSON', 'RAIL', ' slyly quick instructions; bold d');
insert into orders values ('362', '1676', 'P', '71765.36', '1995-05-17', '2-HIGH', 'Clerk#000000766', '0', 'ly across the slyly pending accounts. quickly even accounts boost after ');
insert into lineitem values ('362', '15687', '483', '1', '14', '22437.52', '0.01', '0.02', 'N', 'F', '1995-06-06', '1995-07-01', '1995-06-30', 'TAKE BACK RETURN', 'RAIL', 'ickly among the ironic,');
insert into lineitem values ('362', '2457', '710', '2', '3', '4078.35', '0.00', '0.02', 'N', 'O', '1995-06-25', '1995-07-16', '1995-07-15', 'DELIVER IN PERSON', 'REG AIR', 'osits. slyly final ');
insert into lineitem values ('362', '14131', '660', '3', '42', '43895.46', '0.06', '0.01', 'N', 'O', '1995-07-27', '1995-08-12', '1995-08-16', 'DELIVER IN PERSON', 'REG AIR', ' deposits alongside of the unusual court');
insert into lineitem values ('362', '10746', '527', '4', '2', '3313.48', '0.05', '0.04', 'N', 'F', '1995-06-11', '1995-08-02', '1995-07-04', 'DELIVER IN PERSON', 'TRUCK', 'y instructions. b');
insert into orders values ('363', '8180', 'O', '97589.73', '1995-09-23', '2-HIGH', 'Clerk#000000520', '0', 'dolites. furiously u');
insert into lineitem values ('363', '11662', '185', '1', '29', '45636.14', '0.04', '0.02', 'N', 'O', '1995-11-09', '1995-12-15', '1995-12-01', 'TAKE BACK RETURN', 'MAIL', ' unusual accounts detect along th');
insert into lineitem values ('363', '17025', '26', '2', '13', '12246.26', '0.03', '0.03', 'N', 'O', '1995-10-16', '1995-12-18', '1995-10-26', 'DELIVER IN PERSON', 'AIR', 'haggle regularly amon');
insert into lineitem values ('363', '18161', '966', '3', '37', '39928.92', '0.03', '0.05', 'N', 'O', '1995-12-29', '1995-11-24', '1996-01-22', 'NONE', 'SHIP', ' bold packages are special requests.');
insert into orders values ('364', '2923', 'F', '84340.24', '1992-11-26', '5-LOW', 'Clerk#000000170', '0', 'furiously bold accounts snooze');
insert into lineitem values ('364', '15220', '486', '1', '13', '14757.86', '0.06', '0.04', 'R', 'F', '1993-01-06', '1993-01-12', '1993-01-28', 'NONE', 'MAIL', ', ironic senti');
insert into lineitem values ('364', '1021', '273', '2', '16', '14752.32', '0.00', '0.03', 'A', 'F', '1993-03-20', '1993-02-07', '1993-04-19', 'COLLECT COD', 'RAIL', 'gly unusual accounts. regular acc');
insert into lineitem values ('364', '17330', '598', '3', '25', '31183.25', '0.02', '0.05', 'A', 'F', '1993-02-22', '1993-01-22', '1993-03-14', 'NONE', 'TRUCK', 'Tiresias acco');
insert into lineitem values ('364', '2521', '278', '4', '16', '22776.32', '0.08', '0.08', 'R', 'F', '1993-03-11', '1993-01-29', '1993-03-16', 'TAKE BACK RETURN', 'TRUCK', 'lose deposits affix regul');
insert into orders values ('365', '8524', 'F', '172533.67', '1992-07-06', '3-MEDIUM', 'Clerk#000000200', '0', 'ymptotes sleep carefully dolphins. sometimes regular deposits cajole si');
insert into lineitem values ('365', '7975', '976', '1', '45', '84733.65', '0.03', '0.05', 'R', 'F', '1992-08-07', '1992-08-19', '1992-08-14', 'COLLECT COD', 'SHIP', 'bout the sp');
insert into lineitem values ('365', '10536', '57', '2', '6', '8679.18', '0.01', '0.02', 'R', 'F', '1992-08-31', '1992-09-19', '1992-09-10', 'DELIVER IN PERSON', 'MAIL', '. express packages doubt against the s');
insert into lineitem values ('365', '11642', '165', '3', '5', '7768.20', '0.01', '0.03', 'A', 'F', '1992-08-11', '1992-09-14', '1992-08-26', 'TAKE BACK RETURN', 'AIR', 'ackages. carefully regular ');
insert into lineitem values ('365', '229', '480', '4', '42', '47427.24', '0.05', '0.01', 'A', 'F', '1992-07-19', '1992-09-09', '1992-08-01', 'DELIVER IN PERSON', 'MAIL', ' should haggle slyly doggedly');
insert into lineitem values ('365', '16232', '31', '5', '15', '17223.45', '0.00', '0.00', 'A', 'F', '1992-09-19', '1992-09-30', '1992-10-03', 'TAKE BACK RETURN', 'REG AIR', 'accounts after the sl');
insert into lineitem values ('365', '8770', '29', '6', '4', '6715.08', '0.06', '0.08', 'A', 'F', '1992-10-19', '1992-08-17', '1992-11-09', 'DELIVER IN PERSON', 'REG AIR', 'the carefully regular foxes. regular, sil');
insert into orders values ('366', '9949', 'P', '363035.75', '1995-06-08', '3-MEDIUM', 'Clerk#000000272', '0', '. carefully final theodolites wake carefully about the idly i');
insert into lineitem values ('366', '8540', '541', '1', '31', '44904.74', '0.04', '0.05', 'N', 'O', '1995-09-23', '1995-09-04', '1995-10-04', 'DELIVER IN PERSON', 'AIR', 'ag quickly. ruthless id');
insert into lineitem values ('366', '4845', '354', '2', '49', '85742.16', '0.01', '0.07', 'N', 'O', '1995-07-13', '1995-08-16', '1995-08-03', 'TAKE BACK RETURN', 'FOB', 'long the even deposits. iron');
insert into lineitem values ('366', '16965', '232', '3', '46', '86570.16', '0.02', '0.01', 'N', 'O', '1995-10-05', '1995-07-08', '1995-10-29', 'TAKE BACK RETURN', 'AIR', ' integrate f');
insert into lineitem values ('366', '1919', '920', '4', '17', '30955.47', '0.07', '0.08', 'N', 'O', '1995-10-02', '1995-08-01', '1995-10-07', 'TAKE BACK RETURN', 'AIR', ', regular accounts haggle sl');
insert into lineitem values ('366', '1106', '107', '5', '48', '48340.80', '0.04', '0.08', 'N', 'O', '1995-09-16', '1995-08-01', '1995-10-06', 'TAKE BACK RETURN', 'TRUCK', 'ole furiously. silent att');
insert into lineitem values ('366', '1008', '260', '6', '40', '36360.00', '0.05', '0.07', 'N', 'F', '1995-06-12', '1995-08-11', '1995-06-27', 'NONE', 'REG AIR', '. furiously pending dependencie');
insert into lineitem values ('366', '72', '573', '7', '25', '24301.75', '0.05', '0.00', 'N', 'O', '1995-07-03', '1995-07-14', '1995-08-01', 'DELIVER IN PERSON', 'TRUCK', 'ending foxes doze enticingly. ');
insert into orders values ('367', '14551', 'F', '126210.95', '1993-10-09', '1-URGENT', 'Clerk#000000425', '0', 'nal requests integrate evenly requests. even');
insert into lineitem values ('367', '14569', '362', '1', '17', '25220.52', '0.03', '0.02', 'A', 'F', '1994-02-03', '1993-12-08', '1994-02-17', 'TAKE BACK RETURN', 'REG AIR', 's courts. regular packages against ');
insert into lineitem values ('367', '4556', '557', '2', '17', '24829.35', '0.07', '0.05', 'A', 'F', '1993-11-28', '1993-11-27', '1993-12-08', 'TAKE BACK RETURN', 'RAIL', 'furiously. ironic');
insert into lineitem values ('367', '6291', '804', '3', '48', '57469.92', '0.03', '0.08', 'A', 'F', '1993-11-01', '1994-01-02', '1993-11-30', 'DELIVER IN PERSON', 'REG AIR', 'egular deposits belie');
insert into lineitem values ('367', '4987', '242', '4', '9', '17027.82', '0.06', '0.05', 'A', 'F', '1993-12-24', '1993-12-28', '1994-01-07', 'NONE', 'TRUCK', 'ding to the slyly unusu');
insert into orders values ('392', '2830', 'F', '36582.21', '1994-06-07', '4-NOT SPECIFIED', 'Clerk#000000977', '0', 'lar packages haggle slyly about the qui');
insert into lineitem values ('392', '690', '441', '1', '23', '36585.87', '0.01', '0.01', 'R', 'F', '1994-08-01', '1994-07-19', '1994-08-29', 'COLLECT COD', 'FOB', 'ar deposits nag. special, pendin');
insert into orders values ('393', '6466', 'O', '207317.89', '1997-11-01', '2-HIGH', 'Clerk#000000488', '0', 'ag blithely silent accounts. quickly regular theodo');
insert into lineitem values ('393', '9304', '823', '1', '25', '30332.50', '0.02', '0.07', 'N', 'O', '1998-02-28', '1997-12-31', '1998-03-17', 'COLLECT COD', 'RAIL', ' final, special ins');
insert into lineitem values ('393', '1588', '342', '2', '44', '65541.52', '0.02', '0.02', 'N', 'O', '1997-11-04', '1997-12-17', '1997-11-23', 'COLLECT COD', 'REG AIR', 'uickly pending foxes integrate furiously sp');
insert into lineitem values ('393', '591', '92', '3', '6', '8949.54', '0.06', '0.04', 'N', 'O', '1998-01-15', '1997-12-19', '1998-02-10', 'COLLECT COD', 'AIR', 'haggle quickly am');
insert into lineitem values ('393', '2953', '710', '4', '30', '55678.50', '0.06', '0.00', 'N', 'O', '1997-12-01', '1997-12-18', '1997-12-31', 'NONE', 'TRUCK', 'luffily final p');
insert into lineitem values ('393', '4750', '751', '5', '29', '47987.75', '0.02', '0.04', 'N', 'O', '1997-12-26', '1998-01-03', '1998-01-21', 'DELIVER IN PERSON', 'RAIL', ' integrate bli');
insert into orders values ('394', '13099', 'F', '195149.64', '1994-03-03', '3-MEDIUM', 'Clerk#000000841', '0', 'ideas. even foxes are slyly at the eve');
insert into lineitem values ('394', '7618', '619', '1', '21', '32037.81', '0.00', '0.00', 'R', 'F', '1994-03-16', '1994-05-13', '1994-03-31', 'TAKE BACK RETURN', 'MAIL', 'ously express foxes boost fluffily spec');
insert into lineitem values ('394', '7772', '30', '2', '47', '78949.19', '0.04', '0.07', 'R', 'F', '1994-06-16', '1994-04-10', '1994-06-28', 'DELIVER IN PERSON', 'MAIL', ' blithely. pains ab');
insert into lineitem values ('394', '2023', '276', '3', '35', '32375.70', '0.07', '0.02', 'R', 'F', '1994-04-16', '1994-05-19', '1994-05-13', 'TAKE BACK RETURN', 'SHIP', 'pinto beans? slyly ironic accounts alon');
insert into lineitem values ('394', '17163', '431', '4', '7', '7561.12', '0.05', '0.08', 'R', 'F', '1994-06-24', '1994-05-09', '1994-07-15', 'COLLECT COD', 'MAIL', 'cross the i');
insert into lineitem values ('394', '10037', '298', '5', '49', '46404.47', '0.08', '0.02', 'R', 'F', '1994-07-01', '1994-04-02', '1994-07-29', 'TAKE BACK RETURN', 'AIR', 'ests to the carefully fin');
insert into orders values ('395', '301', 'O', '268265.30', '1996-12-03', '1-URGENT', 'Clerk#000000896', '0', 'riously pending reque');
insert into lineitem values ('395', '17674', '476', '1', '43', '68441.81', '0.05', '0.01', 'N', 'O', '1996-12-29', '1997-02-15', '1997-01-06', 'TAKE BACK RETURN', 'SHIP', 'out the final Tiresias. furiously fi');
insert into lineitem values ('395', '2883', '388', '2', '16', '28574.08', '0.08', '0.05', 'N', 'O', '1997-02-14', '1997-03-03', '1997-02-24', 'DELIVER IN PERSON', 'MAIL', 'tes haggle car');
insert into lineitem values ('395', '12958', '221', '3', '48', '89805.60', '0.05', '0.04', 'N', 'O', '1996-12-22', '1997-03-01', '1997-01-10', 'TAKE BACK RETURN', 'TRUCK', 'ost blithely. pending, regular');
insert into lineitem values ('395', '17418', '220', '4', '30', '40062.30', '0.09', '0.00', 'N', 'O', '1997-03-02', '1997-02-16', '1997-03-15', 'TAKE BACK RETURN', 'RAIL', 'al sauternes. requests');
insert into lineitem values ('395', '1998', '999', '5', '25', '47499.75', '0.02', '0.07', 'N', 'O', '1997-03-15', '1997-01-20', '1997-04-04', 'TAKE BACK RETURN', 'SHIP', 'gular foxes mold a');
insert into orders values ('396', '4310', 'F', '195388.82', '1995-01-07', '1-URGENT', 'Clerk#000000810', '0', 's. special, bold pinto beans nag carefully? fluffily');
insert into lineitem values ('396', '17531', '66', '1', '27', '39110.31', '0.05', '0.00', 'A', 'F', '1995-02-03', '1995-03-23', '1995-02-25', 'NONE', 'REG AIR', 'sly regular requests sleep carefully bu');
insert into lineitem values ('396', '10685', '206', '2', '26', '41487.68', '0.10', '0.06', 'R', 'F', '1995-02-13', '1995-03-16', '1995-03-15', 'COLLECT COD', 'AIR', 'ts boost ironic, iro');
insert into lineitem values ('396', '1446', '698', '3', '36', '48507.84', '0.07', '0.03', 'R', 'F', '1995-04-11', '1995-03-29', '1995-05-02', 'NONE', 'RAIL', 'ctions haggle sl');
insert into lineitem values ('396', '2634', '635', '4', '7', '10756.41', '0.07', '0.01', 'R', 'F', '1995-01-09', '1995-02-22', '1995-01-24', 'DELIVER IN PERSON', 'FOB', ' carefully. blithely even Tiresias ');
insert into lineitem values ('396', '7680', '452', '5', '28', '44455.04', '0.03', '0.07', 'A', 'F', '1995-04-25', '1995-02-11', '1995-05-08', 'COLLECT COD', 'RAIL', 'maintain fl');
insert into lineitem values ('396', '9035', '813', '6', '17', '16048.51', '0.08', '0.08', 'A', 'F', '1995-04-09', '1995-03-17', '1995-05-05', 'DELIVER IN PERSON', 'MAIL', 'nusual packages ');
insert into orders values ('397', '11884', 'O', '239461.10', '1996-05-23', '5-LOW', 'Clerk#000000547', '0', 'ffily unusual excuses. slyly spec');
insert into lineitem values ('397', '19721', '529', '1', '12', '19688.64', '0.03', '0.04', 'N', 'O', '1996-08-29', '1996-07-18', '1996-09-07', 'TAKE BACK RETURN', 'TRUCK', 'uctions. blithely unusual ideas sleep f');
insert into lineitem values ('397', '18645', '914', '2', '19', '29709.16', '0.05', '0.05', 'N', 'O', '1996-09-17', '1996-07-18', '1996-09-22', 'DELIVER IN PERSON', 'SHIP', 'efully daring instru');
insert into lineitem values ('397', '16745', '12', '3', '37', '61484.38', '0.04', '0.03', 'N', 'O', '1996-07-11', '1996-07-26', '1996-08-02', 'NONE', 'REG AIR', 'ial accounts across the furiously ironic ac');
insert into lineitem values ('397', '18160', '697', '4', '38', '40970.08', '0.07', '0.00', 'N', 'O', '1996-08-15', '1996-07-22', '1996-09-11', 'COLLECT COD', 'REG AIR', 'haggle furiously pending in');
insert into lineitem values ('397', '9338', '339', '5', '40', '49893.20', '0.01', '0.06', 'N', 'O', '1996-07-17', '1996-07-26', '1996-08-12', 'TAKE BACK RETURN', 'MAIL', 'e of the slyly special th');
insert into lineitem values ('397', '17840', '375', '6', '9', '15820.56', '0.01', '0.08', 'N', 'O', '1996-08-15', '1996-07-13', '1996-08-16', 'TAKE BACK RETURN', 'SHIP', 'ptotes haggle. carefully regular pack');
insert into lineitem values ('397', '2163', '920', '7', '22', '23433.52', '0.07', '0.00', 'N', 'O', '1996-06-10', '1996-08-20', '1996-06-15', 'COLLECT COD', 'REG AIR', 'unusual dependencies. slyly specia');
insert into orders values ('398', '7631', 'F', '102622.25', '1994-12-03', '4-NOT SPECIFIED', 'Clerk#000000578', '0', 'ly final excuses about the blithely ironic packages c');
insert into lineitem values ('398', '5024', '535', '1', '31', '28799.62', '0.10', '0.00', 'R', 'F', '1995-01-24', '1995-02-21', '1995-02-03', 'DELIVER IN PERSON', 'REG AIR', 'ccounts solve fluffy deposits. depos');
insert into lineitem values ('398', '4638', '639', '2', '49', '75588.87', '0.09', '0.05', 'R', 'F', '1994-12-12', '1995-02-02', '1995-01-04', 'DELIVER IN PERSON', 'TRUCK', 'ithely after ');
insert into lineitem values ('398', '6010', '779', '3', '5', '4580.05', '0.06', '0.04', 'R', 'F', '1995-03-06', '1995-01-06', '1995-04-01', 'NONE', 'REG AIR', ' packages among the blithe ideas c');
insert into orders values ('399', '13505', 'F', '156050.53', '1994-05-02', '4-NOT SPECIFIED', 'Clerk#000000972', '0', 'ggle furiously according ');
insert into lineitem values ('399', '7745', '746', '1', '3', '4958.22', '0.09', '0.02', 'R', 'F', '1994-07-26', '1994-06-07', '1994-08-06', 'NONE', 'MAIL', 'around the blithely unusual fox');
insert into lineitem values ('399', '16252', '253', '2', '49', '57244.25', '0.01', '0.00', 'R', 'F', '1994-08-01', '1994-07-25', '1994-08-23', 'NONE', 'RAIL', 'regular deposits are. blith');
insert into lineitem values ('399', '12993', '256', '3', '8', '15247.92', '0.05', '0.05', 'A', 'F', '1994-07-16', '1994-07-08', '1994-08-07', 'COLLECT COD', 'AIR', 'deposits bet');
insert into lineitem values ('399', '19825', '364', '4', '38', '66303.16', '0.08', '0.00', 'A', 'F', '1994-08-04', '1994-07-09', '1994-08-24', 'COLLECT COD', 'AIR', 'arefully ironic r');
insert into lineitem values ('399', '4886', '887', '5', '10', '17908.80', '0.04', '0.08', 'A', 'F', '1994-05-27', '1994-07-28', '1994-06-25', 'NONE', 'AIR', 'ns. blithely regular deposits ');
insert into orders values ('424', '5654', 'F', '49498.78', '1992-03-19', '5-LOW', 'Clerk#000000552', '0', 'l ideas cajole furiously');
insert into lineitem values ('424', '10993', '774', '1', '26', '49503.74', '0.01', '0.01', 'A', 'F', '1992-03-29', '1992-05-01', '1992-04-22', 'TAKE BACK RETURN', 'REG AIR', 'bold escapades. quickly ironic requests');
insert into orders values ('425', '10546', 'O', '40421.72', '1996-02-24', '1-URGENT', 'Clerk#000000095', '0', 'y regular deposits affix slyly pending no');
insert into lineitem values ('425', '16523', '322', '1', '30', '43185.60', '0.10', '0.04', 'N', 'O', '1996-04-23', '1996-03-27', '1996-05-15', 'TAKE BACK RETURN', 'REG AIR', 'its. furiously');
insert into orders values ('426', '5350', 'F', '277488.16', '1993-07-17', '2-HIGH', 'Clerk#000000634', '0', ' around the quick foxes are blit');
insert into lineitem values ('426', '5749', '260', '1', '43', '71153.82', '0.03', '0.01', 'A', 'F', '1993-09-08', '1993-09-21', '1993-10-01', 'TAKE BACK RETURN', 'RAIL', ' slyly regular instr');
insert into lineitem values ('426', '9901', '679', '2', '1', '1810.90', '0.10', '0.07', 'R', 'F', '1993-07-26', '1993-09-17', '1993-07-28', 'COLLECT COD', 'RAIL', 'efully careful multip');
insert into lineitem values ('426', '537', '538', '3', '50', '71876.50', '0.04', '0.00', 'A', 'F', '1993-07-28', '1993-08-23', '1993-08-04', 'DELIVER IN PERSON', 'FOB', 'l accounts. pinto beans are care');
insert into lineitem values ('426', '10575', '576', '4', '21', '31196.97', '0.06', '0.00', 'R', 'F', '1993-07-23', '1993-10-02', '1993-08-10', 'NONE', 'TRUCK', 'eposits. special requests');
insert into lineitem values ('426', '6145', '914', '5', '47', '49403.58', '0.05', '0.00', 'R', 'F', '1993-10-23', '1993-10-08', '1993-11-17', 'TAKE BACK RETURN', 'MAIL', 'rnis wake furiously regular packages');
insert into lineitem values ('426', '6591', '360', '6', '41', '61401.19', '0.02', '0.01', 'R', 'F', '1993-08-09', '1993-10-14', '1993-08-31', 'TAKE BACK RETURN', 'SHIP', ' carefully carefully regular deposits. exp');
insert into orders values ('427', '2887', 'F', '52426.80', '1993-02-02', '2-HIGH', 'Clerk#000000508', '0', 'refully regular deposits sno');
insert into lineitem values ('427', '6965', '478', '1', '18', '33695.28', '0.07', '0.03', 'R', 'F', '1993-04-03', '1993-04-28', '1993-04-11', 'COLLECT COD', 'SHIP', ' packages around the slyly');
insert into lineitem values ('427', '6366', '879', '2', '16', '20357.76', '0.02', '0.01', 'R', 'F', '1993-05-16', '1993-04-24', '1993-05-19', 'DELIVER IN PERSON', 'TRUCK', 'grouches run fluffily. fluffily pending the');
insert into orders values ('428', '3266', 'F', '244104.27', '1992-07-14', '2-HIGH', 'Clerk#000000236', '0', 'posits. carefully express pinto beans are reg');
insert into lineitem values ('428', '6724', '237', '1', '38', '61967.36', '0.03', '0.06', 'R', 'F', '1992-10-01', '1992-10-10', '1992-10-06', 'TAKE BACK RETURN', 'FOB', 'heodolites. bold');
insert into lineitem values ('428', '10105', '626', '2', '38', '38573.80', '0.09', '0.00', 'R', 'F', '1992-11-05', '1992-09-16', '1992-11-16', 'DELIVER IN PERSON', 'FOB', 'ns doze pending, even se');
insert into lineitem values ('428', '4817', '580', '3', '41', '70594.21', '0.08', '0.04', 'R', 'F', '1992-07-30', '1992-09-24', '1992-08-16', 'NONE', 'SHIP', ' express accou');
insert into lineitem values ('428', '16867', '666', '4', '25', '44596.50', '0.08', '0.03', 'R', 'F', '1992-08-26', '1992-08-30', '1992-09-16', 'NONE', 'MAIL', 'efully above the express dep');
insert into lineitem values ('428', '9491', '492', '5', '26', '36412.74', '0.09', '0.04', 'R', 'F', '1992-08-07', '1992-08-24', '1992-08-12', 'COLLECT COD', 'FOB', '. blithely ');
insert into lineitem values ('428', '9192', '711', '6', '1', '1101.19', '0.09', '0.02', 'A', 'F', '1992-08-02', '1992-09-12', '1992-08-24', 'NONE', 'AIR', ' ironic, r');
insert into orders values ('429', '388', 'F', '110728.72', '1993-01-30', '5-LOW', 'Clerk#000000306', '0', ' deposits are alongside of the quickly unusual platelet');
insert into lineitem values ('429', '2510', '267', '1', '35', '49437.85', '0.10', '0.06', 'A', 'F', '1993-04-07', '1993-04-21', '1993-04-11', 'TAKE BACK RETURN', 'AIR', ' pending theodolites dazzle blithely aft');
insert into lineitem values ('429', '13752', '542', '2', '36', '59967.00', '0.00', '0.06', 'R', 'F', '1993-04-10', '1993-04-19', '1993-04-19', 'COLLECT COD', 'REG AIR', 'ght to are quickly carefully ');
insert into orders values ('430', '1487', 'O', '216959.45', '1997-06-09', '2-HIGH', 'Clerk#000000462', '0', 'g according to the quickly ironic theodol');
insert into lineitem values ('430', '11767', '29', '1', '43', '72186.68', '0.00', '0.08', 'N', 'O', '1997-08-17', '1997-08-13', '1997-09-11', 'COLLECT COD', 'MAIL', 'er the bold');
insert into lineitem values ('430', '7111', '369', '2', '21', '21380.31', '0.05', '0.05', 'N', 'O', '1997-06-24', '1997-08-17', '1997-07-01', 'TAKE BACK RETURN', 'SHIP', 'egular ideas wake deposits. b');
insert into lineitem values ('430', '18152', '689', '3', '41', '43876.15', '0.09', '0.05', 'N', 'O', '1997-06-23', '1997-07-10', '1997-06-27', 'COLLECT COD', 'TRUCK', 'c accounts according to the quickly fina');
insert into lineitem values ('430', '18097', '902', '4', '15', '15226.35', '0.05', '0.03', 'N', 'O', '1997-08-15', '1997-09-04', '1997-09-09', 'COLLECT COD', 'TRUCK', 'affix. final deposits haggle across th');
insert into lineitem values ('430', '4886', '141', '5', '33', '59099.04', '0.01', '0.04', 'N', 'O', '1997-07-10', '1997-08-16', '1997-07-17', 'DELIVER IN PERSON', 'FOB', 'ggle slyly unus');
insert into orders values ('431', '11792', 'F', '41038.75', '1992-03-30', '4-NOT SPECIFIED', 'Clerk#000000257', '0', 'eas must have to haggle carefully final dependencies. quickly unusual');
insert into lineitem values ('431', '6902', '903', '1', '6', '10853.40', '0.02', '0.07', 'R', 'F', '1992-04-25', '1992-05-07', '1992-05-19', 'NONE', 'AIR', 'beans sleep furiously across t');
insert into lineitem values ('431', '13139', '403', '2', '4', '4208.52', '0.02', '0.08', 'R', 'F', '1992-07-29', '1992-05-17', '1992-08-22', 'TAKE BACK RETURN', 'SHIP', 'riously even');
insert into lineitem values ('431', '4275', '276', '3', '3', '3537.81', '0.05', '0.06', 'R', 'F', '1992-07-21', '1992-05-20', '1992-08-09', 'DELIVER IN PERSON', 'TRUCK', 'ges integrate carefully ');
insert into lineitem values ('431', '15287', '553', '4', '18', '21641.04', '0.00', '0.00', 'A', 'F', '1992-05-01', '1992-05-18', '1992-05-09', 'COLLECT COD', 'TRUCK', 'he depths use aroun');
insert into orders values ('456', '4795', 'F', '178087.25', '1992-01-17', '5-LOW', 'Clerk#000000483', '0', 'the requests. carefully even dependencies caj');
insert into lineitem values ('456', '778', '779', '1', '21', '35254.17', '0.02', '0.04', 'R', 'F', '1992-02-29', '1992-03-06', '1992-03-04', 'TAKE BACK RETURN', 'TRUCK', 'ly across th');
insert into lineitem values ('456', '15388', '919', '2', '47', '61258.86', '0.04', '0.06', 'A', 'F', '1992-03-07', '1992-02-26', '1992-03-08', 'NONE', 'AIR', 'ular platelet');
insert into lineitem values ('456', '15955', '956', '3', '44', '82321.80', '0.04', '0.01', 'R', 'F', '1992-03-19', '1992-03-01', '1992-04-15', 'DELIVER IN PERSON', 'FOB', 'as impress slyly about the bravely ex');
insert into orders values ('457', '8377', 'O', '65977.92', '1996-04-08', '3-MEDIUM', 'Clerk#000000899', '0', ' platelets must nag furiousl');
insert into lineitem values ('457', '12542', '329', '1', '48', '69817.92', '0.10', '0.05', 'N', 'O', '1996-05-31', '1996-06-13', '1996-06-20', 'TAKE BACK RETURN', 'MAIL', 'efully fina');
insert into orders values ('458', '14972', 'F', '18007.54', '1995-01-10', '5-LOW', 'Clerk#000000788', '0', 'kages. regular, ironic ');
insert into lineitem values ('458', '842', '343', '1', '11', '19171.24', '0.07', '0.01', 'A', 'F', '1995-03-02', '1995-02-23', '1995-03-15', 'COLLECT COD', 'TRUCK', ' pending realms haggle fluffily. final ');
insert into orders values ('459', '1633', 'O', '186105.07', '1995-07-31', '2-HIGH', 'Clerk#000000071', '0', 'xes. platelets nag furiously carefully final instruc');
insert into lineitem values ('459', '4156', '665', '1', '1', '1060.15', '0.09', '0.00', 'N', 'O', '1995-09-29', '1995-09-01', '1995-10-11', 'TAKE BACK RETURN', 'RAIL', 'final, regular deposits sleep ');
insert into lineitem values ('459', '2411', '412', '2', '15', '19701.15', '0.07', '0.00', 'N', 'O', '1995-11-15', '1995-10-13', '1995-11-25', 'TAKE BACK RETURN', 'SHIP', 'st regular requests. ironic,');
insert into lineitem values ('459', '5123', '889', '3', '27', '27759.24', '0.09', '0.03', 'N', 'O', '1995-10-09', '1995-08-30', '1995-11-08', 'DELIVER IN PERSON', 'RAIL', 'ses serve quickly.');
insert into lineitem values ('459', '7019', '791', '4', '31', '28706.31', '0.02', '0.02', 'N', 'O', '1995-09-01', '1995-10-20', '1995-09-07', 'TAKE BACK RETURN', 'FOB', 'alongside of the ');
insert into lineitem values ('459', '14530', '795', '5', '40', '57781.20', '0.06', '0.07', 'N', 'O', '1995-08-29', '1995-09-03', '1995-09-23', 'DELIVER IN PERSON', 'AIR', 'ickly express i');
insert into lineitem values ('459', '9236', '237', '6', '45', '51535.35', '0.03', '0.08', 'N', 'O', '1995-09-13', '1995-09-11', '1995-10-10', 'NONE', 'REG AIR', 'lyly final realm');
insert into orders values ('460', '14311', 'O', '76555.47', '1998-04-12', '2-HIGH', 'Clerk#000000376', '0', 'he fluffily special pinto beans. furiously furious courts use am');
insert into lineitem values ('460', '18356', '357', '1', '8', '10194.80', '0.05', '0.04', 'N', 'O', '1998-05-14', '1998-07-09', '1998-06-09', 'COLLECT COD', 'SHIP', 'st the quickly even deposits. bli');
insert into lineitem values ('460', '16382', '181', '2', '36', '46741.68', '0.04', '0.02', 'N', 'O', '1998-05-18', '1998-05-13', '1998-06-17', 'NONE', 'TRUCK', 'refully quickly final attainments.');
insert into lineitem values ('460', '2709', '710', '3', '14', '22563.80', '0.10', '0.02', 'N', 'O', '1998-06-30', '1998-07-01', '1998-07-02', 'NONE', 'SHIP', 'ites hinder a');
insert into orders values ('461', '7136', 'O', '171667.74', '1997-11-13', '2-HIGH', 'Clerk#000000532', '0', 'olites. regular, regular requests x-ray slyly');
insert into lineitem values ('461', '11721', '983', '1', '13', '21225.36', '0.07', '0.03', 'N', 'O', '1998-01-22', '1997-12-21', '1998-01-28', 'TAKE BACK RETURN', 'MAIL', 'cajole blithely. regular excuses besi');
insert into lineitem values ('461', '4813', '322', '2', '33', '56687.73', '0.09', '0.07', 'N', 'O', '1998-02-08', '1998-01-18', '1998-02-18', 'COLLECT COD', 'FOB', 's. blithely final packages ');
insert into lineitem values ('461', '10709', '710', '3', '25', '40492.50', '0.01', '0.04', 'N', 'O', '1997-12-11', '1998-01-28', '1997-12-20', 'NONE', 'SHIP', 'rets haggle fluffily above the even depe');
insert into lineitem values ('461', '14260', '525', '4', '48', '56364.48', '0.08', '0.05', 'N', 'O', '1998-02-02', '1997-12-29', '1998-02-19', 'COLLECT COD', 'SHIP', 'ag carefully bold, regular accounts');
insert into orders values ('462', '7087', 'F', '228163.01', '1993-08-11', '3-MEDIUM', 'Clerk#000000063', '0', ' carefully bold accounts. blithely unusual decoys haggle');
insert into lineitem values ('462', '7958', '473', '1', '48', '89565.60', '0.00', '0.04', 'A', 'F', '1993-11-20', '1993-09-28', '1993-11-22', 'DELIVER IN PERSON', 'MAIL', 'symptotes. blithely regular pinto bea');
insert into lineitem values ('462', '17759', '561', '2', '13', '21797.75', '0.09', '0.04', 'A', 'F', '1993-09-01', '1993-10-09', '1993-09-30', 'COLLECT COD', 'AIR', '? quickly regular reques');
insert into lineitem values ('462', '18741', '10', '3', '4', '6638.96', '0.06', '0.08', 'A', 'F', '1993-09-05', '1993-10-06', '1993-10-01', 'COLLECT COD', 'MAIL', 'y pending accounts use');
insert into lineitem values ('462', '10058', '579', '4', '47', '45498.35', '0.02', '0.08', 'R', 'F', '1993-09-02', '1993-10-15', '1993-09-23', 'COLLECT COD', 'RAIL', 'slyly blithely ironic foxes. carefully b');
insert into lineitem values ('462', '18409', '946', '5', '26', '34512.40', '0.06', '0.03', 'A', 'F', '1993-08-24', '1993-09-23', '1993-09-17', 'COLLECT COD', 'RAIL', 'l requests was ');
insert into lineitem values ('462', '15254', '520', '6', '24', '28062.00', '0.08', '0.01', 'A', 'F', '1993-08-18', '1993-11-05', '1993-08-29', 'NONE', 'RAIL', ' requests around the asymptotes cajole ');
insert into orders values ('463', '5230', 'F', '70810.39', '1993-09-23', '4-NOT SPECIFIED', 'Clerk#000000048', '0', 'eodolites detect. slyly pending braids');
insert into lineitem values ('463', '10847', '368', '1', '13', '22851.92', '0.07', '0.07', 'R', 'F', '1993-12-23', '1993-12-03', '1994-01-22', 'NONE', 'TRUCK', 'lyly express');
insert into lineitem values ('463', '13188', '189', '2', '43', '47350.74', '0.06', '0.08', 'R', 'F', '1993-12-29', '1993-11-27', '1994-01-12', 'TAKE BACK RETURN', 'RAIL', 'lar instructions: carefully ruthles');
insert into orders values ('488', '91', 'O', '134630.31', '1997-10-07', '2-HIGH', 'Clerk#000000819', '0', ' according to the regular dolph');
insert into lineitem values ('488', '2337', '338', '1', '17', '21068.61', '0.04', '0.03', 'N', 'O', '1998-01-25', '1997-12-21', '1998-02-19', 'TAKE BACK RETURN', 'AIR', 'express packages detect? blithe sheaves boo');
insert into lineitem values ('488', '11835', '358', '2', '21', '36683.43', '0.01', '0.04', 'N', 'O', '1997-12-16', '1997-12-22', '1997-12-26', 'TAKE BACK RETURN', 'SHIP', 'are furiously ');
insert into lineitem values ('488', '8195', '196', '3', '32', '35302.08', '0.07', '0.00', 'N', 'O', '1998-01-21', '1997-11-23', '1998-01-25', 'DELIVER IN PERSON', 'AIR', ' fluffily bold instructions. slyly r');
insert into lineitem values ('488', '17141', '943', '4', '42', '44441.88', '0.10', '0.08', 'N', 'O', '1997-10-24', '1997-12-01', '1997-11-16', 'DELIVER IN PERSON', 'TRUCK', 'odolites slee');
insert into orders values ('489', '12859', 'O', '80101.91', '1997-06-05', '3-MEDIUM', 'Clerk#000000895', '0', 'ounts are furiously. courts snooze furiously ironic epitaphs. blithely ');
insert into lineitem values ('489', '17773', '308', '1', '48', '81156.96', '0.06', '0.05', 'N', 'O', '1997-07-11', '1997-08-23', '1997-08-03', 'COLLECT COD', 'SHIP', 'l, regular ideas? iro');
insert into orders values ('490', '14006', 'F', '42243.26', '1992-02-02', '4-NOT SPECIFIED', 'Clerk#000000135', '0', 'y slyly pending instructions. b');
insert into lineitem values ('490', '16373', '172', '1', '23', '29655.51', '0.03', '0.08', 'R', 'F', '1992-04-25', '1992-04-07', '1992-05-03', 'DELIVER IN PERSON', 'SHIP', 'bold sauternes. asymptotes nag. furious');
insert into lineitem values ('490', '11728', '729', '2', '7', '11478.04', '0.09', '0.07', 'A', 'F', '1992-03-20', '1992-03-20', '1992-04-18', 'DELIVER IN PERSON', 'TRUCK', 'de of the requests boost caref');
insert into orders values ('491', '13073', 'O', '126571.63', '1998-05-20', '1-URGENT', 'Clerk#000000508', '0', 'ccounts was regular pa');
insert into lineitem values ('491', '12068', '593', '1', '10', '9800.60', '0.09', '0.01', 'N', 'O', '1998-06-29', '1998-07-04', '1998-07-28', 'COLLECT COD', 'TRUCK', 'to beans boost ');
insert into lineitem values ('491', '14219', '220', '2', '46', '52127.66', '0.04', '0.06', 'N', 'O', '1998-07-21', '1998-08-13', '1998-08-04', 'NONE', 'TRUCK', 'p above the even excuses. ');
insert into lineitem values ('491', '9921', '181', '3', '23', '42111.16', '0.01', '0.01', 'N', 'O', '1998-07-09', '1998-08-05', '1998-07-19', 'NONE', 'REG AIR', 'ly final acco');
insert into lineitem values ('491', '6525', '294', '4', '16', '22904.32', '0.05', '0.03', 'N', 'O', '1998-08-19', '1998-06-26', '1998-09-11', 'COLLECT COD', 'REG AIR', 'nal packages run courts. s');
insert into orders values ('492', '12061', 'O', '43056.63', '1997-08-11', '1-URGENT', 'Clerk#000000899', '0', 'nding requests detect. carefully regular de');
insert into lineitem values ('492', '16111', '644', '1', '34', '34921.74', '0.02', '0.02', 'N', 'O', '1997-11-30', '1997-10-27', '1997-12-26', 'COLLECT COD', 'REG AIR', 'rts. quickly regular asymptotes inte');
insert into lineitem values ('492', '13232', '759', '2', '7', '8016.61', '0.05', '0.07', 'N', 'O', '1997-08-16', '1997-10-03', '1997-08-22', 'DELIVER IN PERSON', 'MAIL', ' regular pinto beans are against');
insert into orders values ('493', '8177', 'O', '54619.88', '1996-11-20', '5-LOW', 'Clerk#000000130', '0', 'ccounts integrate furiously pending, unusual theodolit');
insert into lineitem values ('493', '17659', '194', '1', '35', '55182.75', '0.02', '0.01', 'N', 'O', '1996-12-28', '1997-02-14', '1997-01-26', 'TAKE BACK RETURN', 'REG AIR', 'kages detect quickly slyl');
insert into orders values ('494', '14231', 'P', '200694.68', '1995-04-19', '4-NOT SPECIFIED', 'Clerk#000000439', '0', ' packages boost. dolphins haggle quickly quickly bold ');
insert into lineitem values ('494', '11880', '664', '1', '32', '57340.16', '0.02', '0.05', 'A', 'F', '1995-05-26', '1995-06-20', '1995-06-01', 'NONE', 'FOB', 'ully across the special packages; carefu');
insert into lineitem values ('494', '11482', '483', '2', '9', '12541.32', '0.07', '0.05', 'N', 'O', '1995-07-31', '1995-07-06', '1995-08-05', 'TAKE BACK RETURN', 'RAIL', 's. slyly unusual ideas haggle among the');
insert into lineitem values ('494', '5002', '513', '3', '19', '17233.00', '0.09', '0.07', 'N', 'O', '1995-07-12', '1995-07-07', '1995-08-01', 'COLLECT COD', 'SHIP', 'sleep furiously regular packages. request');
insert into lineitem values ('494', '3181', '435', '4', '19', '20599.42', '0.06', '0.02', 'N', 'O', '1995-06-26', '1995-06-08', '1995-06-30', 'COLLECT COD', 'REG AIR', 'l requests ');
insert into lineitem values ('494', '11141', '403', '5', '48', '50502.72', '0.01', '0.01', 'N', 'O', '1995-07-22', '1995-05-26', '1995-07-23', 'TAKE BACK RETURN', 'FOB', 'en packages. regular t');
insert into lineitem values ('494', '1750', '2', '6', '25', '41293.75', '0.04', '0.07', 'N', 'O', '1995-08-06', '1995-07-07', '1995-08-25', 'COLLECT COD', 'FOB', 'ithely bold theodo');
insert into orders values ('495', '9931', 'O', '238448.32', '1997-01-31', '5-LOW', 'Clerk#000000713', '0', ' deposits. blithely final reques');
insert into lineitem values ('495', '17001', '2', '1', '6', '5508.00', '0.05', '0.00', 'N', 'O', '1997-03-21', '1997-03-05', '1997-03-27', 'COLLECT COD', 'MAIL', 'ipliers. carefully regular re');
insert into lineitem values ('495', '3058', '312', '2', '10', '9610.50', '0.03', '0.01', 'N', 'O', '1997-05-05', '1997-04-23', '1997-05-21', 'COLLECT COD', 'REG AIR', 'regular excuses; blithely final acc');
insert into lineitem values ('495', '12844', '631', '3', '37', '65003.08', '0.03', '0.04', 'N', 'O', '1997-02-24', '1997-03-13', '1997-02-25', 'TAKE BACK RETURN', 'TRUCK', 'ggle outside the carefully special ');
insert into lineitem values ('495', '8004', '779', '4', '33', '30096.00', '0.10', '0.05', 'N', 'O', '1997-04-13', '1997-04-18', '1997-04-17', 'TAKE BACK RETURN', 'RAIL', 'uickly final, regular packages. quickly e');
insert into lineitem values ('495', '7380', '381', '5', '43', '55357.34', '0.06', '0.06', 'N', 'O', '1997-02-15', '1997-04-29', '1997-03-10', 'DELIVER IN PERSON', 'TRUCK', 'e. carefully ironic packa');
insert into lineitem values ('495', '19691', '692', '6', '45', '72481.05', '0.01', '0.04', 'N', 'O', '1997-05-17', '1997-04-06', '1997-06-09', 'TAKE BACK RETURN', 'FOB', 'arefully bold packages wake. ideas sleep ');
insert into orders values ('520', '4273', 'F', '93087.06', '1992-03-13', '2-HIGH', 'Clerk#000000997', '0', 'gular braids might nag fluffily regular, bold dolphi');
insert into lineitem values ('520', '19740', '279', '1', '47', '78007.78', '0.09', '0.07', 'R', 'F', '1992-06-04', '1992-05-06', '1992-06-07', 'COLLECT COD', 'AIR', 'lites. expre');
insert into lineitem values ('520', '4458', '713', '2', '13', '17711.85', '0.07', '0.04', 'R', 'F', '1992-05-01', '1992-06-09', '1992-05-03', 'COLLECT COD', 'MAIL', 'yly silent Tiresias. furio');
insert into orders values ('521', '8272', 'O', '105363.11', '1995-07-23', '5-LOW', 'Clerk#000000331', '0', ' quickly final pinto beans around the fu');
insert into lineitem values ('521', '18983', '252', '1', '22', '41843.56', '0.00', '0.02', 'N', 'O', '1995-08-23', '1995-09-12', '1995-08-26', 'NONE', 'AIR', 'y ironic p');
insert into lineitem values ('521', '17842', '843', '2', '36', '63354.24', '0.03', '0.02', 'N', 'O', '1995-08-18', '1995-09-13', '1995-09-04', 'COLLECT COD', 'FOB', 'usly even exc');
insert into orders values ('522', '800', 'O', '210753.40', '1998-05-11', '4-NOT SPECIFIED', 'Clerk#000000395', '0', 'theodolites poach sl');
insert into lineitem values ('522', '9546', '806', '1', '11', '16010.94', '0.10', '0.04', 'N', 'O', '1998-08-26', '1998-08-07', '1998-09-20', 'COLLECT COD', 'AIR', 'regular theodolites boost a');
insert into lineitem values ('522', '11603', '387', '2', '43', '65127.80', '0.10', '0.08', 'N', 'O', '1998-05-22', '1998-06-24', '1998-06-07', 'COLLECT COD', 'FOB', 'regular depo');
insert into lineitem values ('522', '6199', '456', '3', '3', '3315.57', '0.10', '0.04', 'N', 'O', '1998-06-28', '1998-08-03', '1998-07-25', 'COLLECT COD', 'AIR', 'wake furiously s');
insert into lineitem values ('522', '2645', '646', '4', '36', '55715.04', '0.07', '0.08', 'N', 'O', '1998-05-22', '1998-06-21', '1998-05-26', 'COLLECT COD', 'REG AIR', ' packages sleep beside the final');
insert into lineitem values ('522', '1456', '210', '5', '19', '25791.55', '0.03', '0.05', 'N', 'O', '1998-06-18', '1998-08-01', '1998-06-29', 'NONE', 'FOB', 'otes nag furiousl');
insert into lineitem values ('522', '3560', '320', '6', '31', '45370.36', '0.02', '0.06', 'N', 'O', '1998-05-27', '1998-07-30', '1998-05-29', 'NONE', 'REG AIR', 'slyly slyly express d');
insert into orders values ('523', '9859', 'O', '41483.10', '1997-09-12', '3-MEDIUM', 'Clerk#000000450', '0', 'ronic dependencies from the blithely express pinto beans cajole idly abo');
insert into lineitem values ('523', '10558', '339', '1', '7', '10279.85', '0.08', '0.06', 'N', 'O', '1997-09-24', '1997-11-18', '1997-10-05', 'TAKE BACK RETURN', 'MAIL', 'ickly silent requests. furiously reg');
insert into lineitem values ('523', '19763', '764', '2', '1', '1682.76', '0.02', '0.03', 'N', 'O', '1997-10-09', '1997-10-24', '1997-10-16', 'COLLECT COD', 'RAIL', 'thely regular ideas. furiously special foxe');
insert into lineitem values ('523', '9001', '2', '3', '16', '14560.00', '0.09', '0.08', 'N', 'O', '1997-10-25', '1997-10-31', '1997-11-20', 'TAKE BACK RETURN', 'SHIP', 'kages. regular packages cajol');
insert into lineitem values ('523', '13055', '56', '4', '16', '15488.80', '0.05', '0.05', 'N', 'O', '1997-11-20', '1997-11-09', '1997-12-04', 'DELIVER IN PERSON', 'RAIL', 're carefully final ');
insert into orders values ('524', '2191', 'F', '51217.30', '1993-07-03', '2-HIGH', 'Clerk#000000373', '0', 'fix blithely even, unusual accounts. blithely sp');
insert into lineitem values ('524', '14472', '473', '1', '37', '51299.39', '0.04', '0.04', 'R', 'F', '1993-08-24', '1993-09-07', '1993-08-28', 'NONE', 'AIR', 'he multipliers sleep');
insert into orders values ('525', '10799', 'O', '183911.14', '1995-12-16', '2-HIGH', 'Clerk#000000791', '0', 'the silent accounts. unu');
insert into lineitem values ('525', '17655', '457', '1', '24', '37743.60', '0.05', '0.02', 'N', 'O', '1996-01-16', '1996-01-15', '1996-02-03', 'NONE', 'MAIL', 'es wake slyly after the express');
insert into lineitem values ('525', '6688', '457', '2', '17', '27109.56', '0.05', '0.08', 'N', 'O', '1996-01-01', '1996-02-25', '1996-01-23', 'DELIVER IN PERSON', 'SHIP', 'es use fluffily');
insert into lineitem values ('525', '12687', '474', '3', '34', '54389.12', '0.06', '0.02', 'N', 'O', '1995-12-25', '1996-02-26', '1996-01-03', 'DELIVER IN PERSON', 'AIR', ' the even deposit');
insert into lineitem values ('525', '5003', '769', '4', '40', '36320.00', '0.02', '0.03', 'N', 'O', '1996-02-21', '1996-02-15', '1996-03-04', 'TAKE BACK RETURN', 'REG AIR', 'e carefully? ironic theodolites ');
insert into lineitem values ('525', '11250', '251', '5', '11', '12773.75', '0.08', '0.07', 'N', 'O', '1996-03-21', '1996-01-18', '1996-04-18', 'COLLECT COD', 'RAIL', 's. regular, regular ');
insert into lineitem values ('525', '6601', '602', '6', '2', '3015.20', '0.09', '0.02', 'N', 'O', '1996-01-25', '1996-01-19', '1996-02-05', 'DELIVER IN PERSON', 'MAIL', 'bove the regular requests detect sl');
insert into lineitem values ('525', '10837', '98', '7', '9', '15730.47', '0.08', '0.06', 'N', 'O', '1996-01-01', '1996-03-09', '1996-01-03', 'TAKE BACK RETURN', 'FOB', 'ideas about the furiou');
insert into orders values ('526', '11662', 'F', '193507.18', '1992-11-19', '3-MEDIUM', 'Clerk#000000010', '0', 'ully even deposits enga');
insert into lineitem values ('526', '12937', '200', '1', '40', '73997.20', '0.04', '0.05', 'A', 'F', '1992-12-14', '1993-02-12', '1993-01-11', 'COLLECT COD', 'SHIP', 'furiously unus');
insert into lineitem values ('526', '23', '24', '2', '10', '9230.20', '0.00', '0.02', 'A', 'F', '1993-02-23', '1993-02-16', '1993-03-24', 'COLLECT COD', 'FOB', 'pinto beans. packages haggle slyly care');
insert into lineitem values ('526', '9979', '980', '3', '5', '9444.85', '0.01', '0.08', 'R', 'F', '1992-12-29', '1993-01-16', '1993-01-26', 'COLLECT COD', 'RAIL', 'fully. ideas haggl');
insert into lineitem values ('526', '15844', '845', '4', '29', '51035.36', '0.03', '0.07', 'R', 'F', '1993-01-18', '1993-01-08', '1993-02-16', 'TAKE BACK RETURN', 'REG AIR', ' the quickly');
insert into lineitem values ('526', '17527', '62', '5', '25', '36113.00', '0.10', '0.05', 'R', 'F', '1993-02-10', '1993-01-14', '1993-03-06', 'COLLECT COD', 'REG AIR', 'longside of the carefully regular');
insert into lineitem values ('526', '1974', '728', '6', '7', '13131.79', '0.09', '0.03', 'R', 'F', '1992-12-05', '1992-12-31', '1992-12-13', 'NONE', 'FOB', 'ouches. fu');
insert into orders values ('527', '10565', 'O', '294124.14', '1996-08-23', '4-NOT SPECIFIED', 'Clerk#000000061', '0', 'g foxes are carefully furiously e');
insert into lineitem values ('527', '820', '821', '1', '39', '67111.98', '0.01', '0.05', 'N', 'O', '1996-09-20', '1996-11-13', '1996-10-03', 'COLLECT COD', 'MAIL', 's. quickly unusual requests wake fluf');
insert into lineitem values ('527', '18020', '21', '2', '32', '30016.64', '0.05', '0.03', 'N', 'O', '1996-12-19', '1996-09-29', '1996-12-30', 'TAKE BACK RETURN', 'SHIP', 'arefully pending');
insert into lineitem values ('527', '9730', '990', '3', '45', '73787.85', '0.03', '0.03', 'N', 'O', '1996-09-19', '1996-09-26', '1996-09-21', 'DELIVER IN PERSON', 'MAIL', 'ly regular pinto bea');
insert into lineitem values ('527', '17126', '394', '4', '33', '34422.96', '0.00', '0.01', 'N', 'O', '1996-09-24', '1996-11-19', '1996-10-07', 'TAKE BACK RETURN', 'TRUCK', 'ic packages. slyly pend');
insert into lineitem values ('527', '12454', '979', '5', '16', '21863.20', '0.08', '0.06', 'N', 'O', '1996-10-27', '1996-11-20', '1996-11-19', 'NONE', 'TRUCK', 'p slyly above the furiously bo');
insert into lineitem values ('527', '19440', '979', '6', '49', '66612.56', '0.05', '0.03', 'N', 'O', '1996-08-29', '1996-10-28', '1996-09-19', 'NONE', 'MAIL', 'g to the fluffily ironic pla');
insert into orders values ('552', '2117', 'F', '131028.11', '1994-04-26', '1-URGENT', 'Clerk#000000285', '0', 'xes nag carefully; carefully pending pinto bea');
insert into lineitem values ('552', '574', '575', '1', '32', '47186.24', '0.02', '0.00', 'R', 'F', '1994-06-01', '1994-05-30', '1994-06-20', 'TAKE BACK RETURN', 'SHIP', 'deas across');
insert into lineitem values ('552', '519', '770', '2', '45', '63877.95', '0.06', '0.04', 'R', 'F', '1994-05-26', '1994-07-13', '1994-06-08', 'DELIVER IN PERSON', 'RAIL', 'sly pinto beans. blithely bold ');
insert into lineitem values ('552', '12189', '714', '3', '21', '23124.78', '0.08', '0.05', 'A', 'F', '1994-06-01', '1994-06-01', '1994-06-18', 'COLLECT COD', 'AIR', 'manently unusual dependencies. ');
insert into orders values ('553', '2755', 'O', '122727.72', '1996-12-16', '4-NOT SPECIFIED', 'Clerk#000000509', '0', 'lyly. pinto beans sleep furiously final accounts. final, r');
insert into lineitem values ('553', '18495', '764', '1', '30', '42404.70', '0.10', '0.06', 'N', 'O', '1996-12-19', '1997-01-18', '1997-01-17', 'NONE', 'RAIL', 'lyly ironic requests sleep sl');
insert into lineitem values ('553', '13116', '906', '2', '18', '18523.98', '0.01', '0.05', 'N', 'O', '1997-02-08', '1997-03-16', '1997-02-20', 'COLLECT COD', 'REG AIR', ' beans wake quickly along the quic');
insert into lineitem values ('553', '7406', '407', '3', '48', '63043.20', '0.02', '0.02', 'N', 'O', '1997-01-08', '1997-01-20', '1997-01-24', 'DELIVER IN PERSON', 'TRUCK', 'ular deposits. bli');
insert into orders values ('554', '14177', 'O', '192130.68', '1995-11-13', '2-HIGH', 'Clerk#000000071', '0', ' according to the final pa');
insert into lineitem values ('554', '11228', '229', '1', '15', '17088.30', '0.10', '0.05', 'N', 'O', '1996-02-17', '1996-01-23', '1996-03-09', 'TAKE BACK RETURN', 'SHIP', 'iously. carefully final pinto beans doz');
insert into lineitem values ('554', '19594', '133', '2', '42', '63570.78', '0.01', '0.02', 'N', 'O', '1996-03-06', '1996-02-07', '1996-04-05', 'COLLECT COD', 'TRUCK', 'nts about the express ideas cajole alo');
insert into lineitem values ('554', '15677', '208', '3', '16', '25482.72', '0.08', '0.02', 'N', 'O', '1995-12-05', '1996-01-24', '1996-01-01', 'COLLECT COD', 'RAIL', 'nic theodolites are along the caref');
insert into lineitem values ('554', '9424', '425', '4', '10', '13334.20', '0.01', '0.01', 'N', 'O', '1995-12-03', '1996-01-23', '1995-12-22', 'COLLECT COD', 'FOB', 'ideas. even deposi');
insert into lineitem values ('554', '2542', '543', '5', '46', '66448.84', '0.09', '0.01', 'N', 'O', '1996-01-21', '1996-01-28', '1996-02-14', 'DELIVER IN PERSON', 'RAIL', 'ang fluffily ironic accounts. slyly regular');
insert into lineitem values ('554', '17566', '834', '6', '9', '13352.04', '0.03', '0.04', 'N', 'O', '1996-03-02', '1996-01-13', '1996-03-04', 'DELIVER IN PERSON', 'SHIP', 'ng pinto beans. packages was');
insert into orders values ('555', '12697', 'O', '43958.78', '1996-09-19', '3-MEDIUM', 'Clerk#000000857', '0', 'ctions use quickly after the a');
insert into lineitem values ('555', '7994', '766', '1', '24', '45647.76', '0.10', '0.07', 'N', 'O', '1996-11-29', '1996-11-04', '1996-12-12', 'DELIVER IN PERSON', 'AIR', 'fully final deposits about the f');
insert into orders values ('556', '1811', 'F', '76076.90', '1994-06-10', '1-URGENT', 'Clerk#000000817', '0', 'tain carefully express dependencies. slyly even a');
insert into lineitem values ('556', '3114', '621', '1', '28', '28479.08', '0.06', '0.05', 'R', 'F', '1994-07-10', '1994-08-28', '1994-07-15', 'DELIVER IN PERSON', 'SHIP', 'nag furiously blithely pending in');
insert into lineitem values ('556', '13050', '314', '2', '49', '47189.45', '0.05', '0.07', 'A', 'F', '1994-08-21', '1994-08-11', '1994-08-27', 'DELIVER IN PERSON', 'SHIP', 'es are furiou');
insert into orders values ('557', '907', 'F', '135659.92', '1993-09-28', '2-HIGH', 'Clerk#000000137', '0', 'symptotes use quickly quickly brave r');
insert into lineitem values ('557', '16278', '545', '1', '1', '1194.27', '0.08', '0.05', 'R', 'F', '1993-10-12', '1993-12-04', '1993-10-24', 'COLLECT COD', 'AIR', 'ccounts ar');
insert into lineitem values ('557', '1889', '392', '2', '18', '32235.84', '0.06', '0.05', 'R', 'F', '1994-01-08', '1993-12-20', '1994-02-06', 'TAKE BACK RETURN', 'REG AIR', 'onic deposits. sentiments by the furiously ');
insert into lineitem values ('557', '2216', '217', '3', '37', '41373.77', '0.00', '0.01', 'R', 'F', '1993-11-07', '1993-10-31', '1993-11-09', 'NONE', 'SHIP', 'furiously regular dep');
insert into lineitem values ('557', '18903', '708', '4', '4', '7287.60', '0.02', '0.05', 'A', 'F', '1993-12-18', '1993-12-10', '1993-12-23', 'DELIVER IN PERSON', 'SHIP', 'he fluffily bold packages. pa');
insert into lineitem values ('557', '15266', '267', '5', '1', '1181.26', '0.08', '0.04', 'R', 'F', '1993-10-26', '1993-11-11', '1993-11-06', 'TAKE BACK RETURN', 'AIR', ' print furiously ');
insert into lineitem values ('557', '1158', '661', '6', '48', '50839.20', '0.03', '0.06', 'R', 'F', '1993-11-15', '1993-11-29', '1993-11-23', 'NONE', 'REG AIR', 'he fluffily silent accounts. packages bo');
insert into orders values ('558', '12262', 'F', '141398.70', '1993-03-19', '2-HIGH', 'Clerk#000000055', '0', 'ideas. pinto beans ');
insert into lineitem values ('558', '9888', '666', '1', '28', '50340.64', '0.08', '0.05', 'A', 'F', '1993-03-23', '1993-05-25', '1993-04-15', 'NONE', 'FOB', 'equests. unusual pinto beans haggle quickly');
insert into lineitem values ('558', '18158', '695', '2', '50', '53807.50', '0.06', '0.08', 'R', 'F', '1993-05-31', '1993-05-10', '1993-06-29', 'TAKE BACK RETURN', 'AIR', '. fluffily even deposits wak');
insert into lineitem values ('558', '1124', '627', '3', '38', '38954.56', '0.04', '0.02', 'R', 'F', '1993-06-23', '1993-05-18', '1993-07-22', 'COLLECT COD', 'RAIL', 'mong the fluffily express dolphins. car');
insert into orders values ('559', '6431', 'O', '121347.86', '1996-12-17', '3-MEDIUM', 'Clerk#000000673', '0', 'y. quietly special ideas haggle quickly unusual foxes. express deposits wake ');
insert into lineitem values ('559', '2522', '523', '1', '50', '71226.00', '0.06', '0.06', 'N', 'O', '1997-02-02', '1997-03-16', '1997-02-10', 'DELIVER IN PERSON', 'REG AIR', 'egular pinto beans? carefu');
insert into lineitem values ('559', '6189', '958', '2', '50', '54759.00', '0.08', '0.00', 'N', 'O', '1997-03-27', '1997-02-25', '1997-04-22', 'TAKE BACK RETURN', 'SHIP', 'ackages. furiously');
insert into orders values ('584', '9326', 'F', '192876.29', '1993-12-31', '5-LOW', 'Clerk#000000662', '0', 'ross the carefully ironic packag');
insert into lineitem values ('584', '19539', '347', '1', '24', '35004.72', '0.03', '0.05', 'A', 'F', '1994-02-08', '1994-03-05', '1994-03-03', 'DELIVER IN PERSON', 'TRUCK', 'structions sleep. slyly ironic');
insert into lineitem values ('584', '8058', '575', '2', '32', '30913.60', '0.06', '0.08', 'A', 'F', '1994-04-28', '1994-03-27', '1994-05-14', 'NONE', 'SHIP', 'ublate pending asymptotes. ');
insert into lineitem values ('584', '16761', '294', '3', '12', '20133.12', '0.03', '0.02', 'R', 'F', '1994-01-28', '1994-02-27', '1994-02-17', 'NONE', 'REG AIR', '. blithely un');
insert into lineitem values ('584', '17738', '273', '4', '23', '38081.79', '0.10', '0.01', 'R', 'F', '1994-02-17', '1994-03-12', '1994-03-06', 'COLLECT COD', 'MAIL', 's. regular foxes grow quic');
insert into lineitem values ('584', '13237', '764', '5', '44', '50610.12', '0.09', '0.01', 'A', 'F', '1994-02-04', '1994-03-27', '1994-02-25', 'COLLECT COD', 'FOB', 'ng to the bold ');
insert into lineitem values ('584', '19186', '725', '6', '23', '25419.14', '0.08', '0.06', 'R', 'F', '1994-02-14', '1994-02-18', '1994-03-03', 'NONE', 'RAIL', 'st the carefully final ideas hag');
insert into orders values ('585', '14971', 'F', '225248.43', '1993-03-28', '5-LOW', 'Clerk#000000513', '0', 'ular pinto beans detect carefully final sentiments. furiously ironic ');
insert into lineitem values ('585', '3973', '227', '1', '32', '60063.04', '0.00', '0.03', 'R', 'F', '1993-07-26', '1993-05-11', '1993-08-17', 'COLLECT COD', 'TRUCK', 'tions. ironic acco');
insert into lineitem values ('585', '2930', '435', '2', '30', '54987.90', '0.08', '0.04', 'R', 'F', '1993-06-13', '1993-05-25', '1993-06-22', 'TAKE BACK RETURN', 'AIR', ' the quickly regular instructions. fluff');
insert into lineitem values ('585', '19194', '2', '3', '23', '25603.37', '0.02', '0.05', 'R', 'F', '1993-06-04', '1993-05-02', '1993-06-22', 'TAKE BACK RETURN', 'SHIP', 'lar pains sleep above the silent');
insert into lineitem values ('585', '13092', '356', '4', '21', '21106.89', '0.09', '0.06', 'A', 'F', '1993-06-06', '1993-06-09', '1993-06-27', 'NONE', 'SHIP', 'regular asymptotes are fluffily above');
insert into lineitem values ('585', '12217', '742', '5', '18', '20325.78', '0.09', '0.05', 'R', 'F', '1993-04-06', '1993-05-20', '1993-04-28', 'NONE', 'AIR', 'y stealthy theodoli');
insert into lineitem values ('585', '1806', '58', '6', '27', '46110.60', '0.06', '0.03', 'A', 'F', '1993-07-26', '1993-06-03', '1993-08-07', 'DELIVER IN PERSON', 'AIR', 'the carefully fin');
insert into orders values ('586', '3400', 'O', '116300.40', '1998-05-26', '4-NOT SPECIFIED', 'Clerk#000000928', '0', 'carefully. carefully ');
insert into lineitem values ('586', '19873', '412', '1', '1', '1792.87', '0.02', '0.07', 'N', 'O', '1998-09-21', '1998-07-01', '1998-10-07', 'NONE', 'MAIL', ' pinto beans use fluffily final instr');
insert into lineitem values ('586', '9067', '327', '2', '10', '9760.60', '0.03', '0.07', 'N', 'O', '1998-06-06', '1998-07-09', '1998-06-18', 'COLLECT COD', 'SHIP', 'encies. express courts kindle ');
insert into lineitem values ('586', '16594', '595', '3', '40', '60423.60', '0.05', '0.00', 'N', 'O', '1998-06-20', '1998-07-26', '1998-07-17', 'TAKE BACK RETURN', 'MAIL', 'kages. carefully spec');
insert into lineitem values ('586', '5221', '987', '4', '43', '48427.46', '0.06', '0.03', 'N', 'O', '1998-07-03', '1998-08-04', '1998-07-27', 'TAKE BACK RETURN', 'MAIL', 'ng the finally special deposits cajole fu');
insert into orders values ('587', '12460', 'F', '81403.44', '1992-09-30', '5-LOW', 'Clerk#000000656', '0', 'eodolites doze across the furiously unusual requests! quic');
insert into lineitem values ('587', '11914', '176', '1', '43', '78514.13', '0.04', '0.08', 'A', 'F', '1992-12-07', '1992-12-22', '1992-12-18', 'COLLECT COD', 'FOB', 'egular accounts are be');
insert into orders values ('588', '12652', 'F', '269439.57', '1993-07-28', '5-LOW', 'Clerk#000000326', '0', 'sly even asymptotes grow f');
insert into lineitem values ('588', '10857', '638', '1', '35', '61874.75', '0.03', '0.07', 'R', 'F', '1993-08-22', '1993-10-12', '1993-09-13', 'COLLECT COD', 'FOB', ' foxes was furiously a');
insert into lineitem values ('588', '12233', '234', '2', '9', '10307.07', '0.06', '0.05', 'A', 'F', '1993-08-09', '1993-09-24', '1993-09-01', 'COLLECT COD', 'FOB', 'e furiously bold warthogs. furiou');
insert into lineitem values ('588', '17752', '20', '3', '50', '83487.50', '0.07', '0.04', 'A', 'F', '1993-11-15', '1993-08-31', '1993-12-08', 'DELIVER IN PERSON', 'RAIL', 'ckly unusual theodolites. quickly bold pa');
insert into lineitem values ('588', '7513', '28', '4', '4', '5682.04', '0.02', '0.01', 'A', 'F', '1993-10-13', '1993-09-20', '1993-10-27', 'DELIVER IN PERSON', 'RAIL', 'thely pending deposits detect ');
insert into lineitem values ('588', '15013', '279', '5', '33', '30624.33', '0.04', '0.00', 'R', 'F', '1993-08-30', '1993-09-30', '1993-09-09', 'NONE', 'RAIL', 'yly ironic');
insert into lineitem values ('588', '15570', '366', '6', '41', '60908.37', '0.10', '0.00', 'R', 'F', '1993-10-13', '1993-09-11', '1993-10-26', 'TAKE BACK RETURN', 'TRUCK', 'odolites. slyly silent fox');
insert into lineitem values ('588', '19579', '118', '7', '17', '25475.69', '0.04', '0.00', 'A', 'F', '1993-09-29', '1993-09-09', '1993-10-29', 'DELIVER IN PERSON', 'TRUCK', '. carefully pending deposits use furiously');
insert into orders values ('589', '4525', 'O', '76359.59', '1997-10-10', '5-LOW', 'Clerk#000000052', '0', 'ithely ironic platelets. fluffily e');
insert into lineitem values ('589', '13313', '103', '1', '46', '56410.26', '0.02', '0.01', 'N', 'O', '1997-10-27', '1998-01-02', '1997-11-15', 'TAKE BACK RETURN', 'MAIL', 'ously bold deposits are. f');
insert into lineitem values ('589', '2891', '648', '2', '3', '5381.67', '0.02', '0.02', 'N', 'O', '1997-11-03', '1997-12-05', '1997-11-10', 'COLLECT COD', 'SHIP', 'long the packages. bold pa');
insert into lineitem values ('589', '15102', '368', '3', '12', '12205.20', '0.10', '0.05', 'N', 'O', '1998-01-19', '1997-12-07', '1998-02-09', 'TAKE BACK RETURN', 'RAIL', 'ly ironic ');
insert into lineitem values ('589', '10847', '628', '4', '2', '3515.68', '0.04', '0.07', 'N', 'O', '1997-12-29', '1997-11-21', '1998-01-02', 'TAKE BACK RETURN', 'RAIL', ' notornis wake slyly. un');
insert into orders values ('590', '461', 'F', '315221.69', '1993-06-25', '4-NOT SPECIFIED', 'Clerk#000000024', '0', 'ealthily. theodolit');
insert into lineitem values ('590', '12243', '244', '1', '42', '48520.08', '0.05', '0.06', 'A', 'F', '1993-07-26', '1993-08-02', '1993-08-22', 'NONE', 'FOB', 'ously furiously regular d');
insert into lineitem values ('590', '2838', '343', '2', '37', '64410.71', '0.09', '0.06', 'A', 'F', '1993-09-06', '1993-08-06', '1993-09-25', 'DELIVER IN PERSON', 'FOB', 'need to cajole quick, fi');
insert into lineitem values ('590', '13001', '791', '3', '5', '4570.00', '0.02', '0.07', 'A', 'F', '1993-08-02', '1993-07-25', '1993-08-08', 'DELIVER IN PERSON', 'FOB', 'nal deposits. furiously even i');
insert into lineitem values ('590', '11437', '699', '4', '27', '36407.61', '0.00', '0.04', 'R', 'F', '1993-08-08', '1993-08-04', '1993-08-16', 'DELIVER IN PERSON', 'SHIP', 'ingly ironic requests.');
insert into lineitem values ('590', '17993', '795', '5', '45', '85994.55', '0.00', '0.06', 'R', 'F', '1993-10-23', '1993-08-04', '1993-11-16', 'DELIVER IN PERSON', 'AIR', 'ess instructions los');
insert into lineitem values ('590', '18578', '847', '6', '4', '5986.28', '0.04', '0.01', 'R', 'F', '1993-07-22', '1993-08-17', '1993-08-19', 'DELIVER IN PERSON', 'FOB', 'ons after the furi');
insert into lineitem values ('590', '10806', '67', '7', '41', '70388.80', '0.10', '0.02', 'R', 'F', '1993-08-20', '1993-09-16', '1993-08-21', 'DELIVER IN PERSON', 'SHIP', 'hs past the quickly special r');

--------------------------------------------------------------------------------

--   Query 1 (repeated 22 times) with parameters from 'qgen'
-- TODO: fix this error when 'order/group by' removed:
--   psql:tpch-sample-workload.sql:778: ERROR:  column "lineitem.l_returnflag" must appear in
--   the GROUP BY clause or be used in an aggregate function
--   LINE 2:  l_returnflag,
--            ^
--
-- Typical query plan (via EXPLAIN ANALYZE):
--     Sort  (cost=42464.77..42464.79 rows=6 width=25) (actual time=2462.931..2462.931 rows=4 loops=1)
--       Sort Key: l_returnflag, l_linestatus
--       Sort Method: quicksort  Memory: 25kB
--       ->  HashAggregate  (cost=42464.59..42464.70 rows=6 width=25) (actual time=2462.903..2462.908 rows=4 loops=1)
--             ->  Seq Scan on lineitem  (cost=0.00..18772.15 rows=592311 width=25) (actual time=0.012..148.740 rows=592553 loops=1)
--                   Filter: (l_shipdate <= '1998-09-06 00:00:00'::timestamp without time zone)
--     Total runtime: 2463.067 ms
--    (7 rows)
--
-- If we drop the GROUP BY and ORDER BY clauses, the new query plan is
--     Aggregate  (cost=39503.04..39503.05 rows=1 width=21) (actual time=2269.772..2269.773 rows=1 loops=1)
--       ->  Seq Scan on lineitem  (cost=0.00..18772.15 rows=592311 width=21) (actual
--    time=0.013..139.886 rows=592553 loops=1)
--             Filter: (l_shipdate <= '1998-09-06 00:00:00'::timestamp without time zone)
--     Total runtime: 2269.895 ms
--    (4 rows)

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '86' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '102' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '118' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '73' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '89' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '105' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '60' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '76' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '92' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '108' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '63' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '79' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '95' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '111' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '66' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '82' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '98' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '115' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '70' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '86' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '102' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

select
	l_returnflag,
	l_linestatus,
	sum(l_quantity) as sum_qty,
	sum(l_extendedprice) as sum_base_price,
	sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
	sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
	avg(l_quantity) as avg_qty,
	avg(l_extendedprice) as avg_price,
	avg(l_discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	l_shipdate <= date '1998-12-01' - interval '118' day
group by
	l_returnflag,
	l_linestatus
order by
	l_returnflag,
	l_linestatus;

--------------------------------------------------------------------------------

--   Refresh function 2:
--     See section 2.7 (page 67) of TPC-H specification:
--       LOOP (SF * 1500) TIMES
--         DELETE FROM ORDERS WHERE O_ORDERKEY = [value]
--         DELETE FROM LINEITEM WHERE L_ORDERKEY = [value]
--       END LOOP
--   Refresh function 2:
--     See section 2.7 (page 67) of TPC-H specification:
--       LOOP (SF * 1500) TIMES
--         DELETE FROM ORDERS WHERE O_ORDERKEY = [value]
--         DELETE FROM LINEITEM WHERE L_ORDERKEY = [value]
--       END LOOP

delete from lineitem where l_orderkey = 9;
delete from orders where o_orderkey = 9;
delete from lineitem where l_orderkey = 10;
delete from orders where o_orderkey = 10;
delete from lineitem where l_orderkey = 11;
delete from orders where o_orderkey = 11;
delete from lineitem where l_orderkey = 12;
delete from orders where o_orderkey = 12;
delete from lineitem where l_orderkey = 13;
delete from orders where o_orderkey = 13;
delete from lineitem where l_orderkey = 14;
delete from orders where o_orderkey = 14;
delete from lineitem where l_orderkey = 15;
delete from orders where o_orderkey = 15;
delete from lineitem where l_orderkey = 40;
delete from orders where o_orderkey = 40;
delete from lineitem where l_orderkey = 41;
delete from orders where o_orderkey = 41;
delete from lineitem where l_orderkey = 42;
delete from orders where o_orderkey = 42;
delete from lineitem where l_orderkey = 43;
delete from orders where o_orderkey = 43;
delete from lineitem where l_orderkey = 44;
delete from orders where o_orderkey = 44;
delete from lineitem where l_orderkey = 45;
delete from orders where o_orderkey = 45;
delete from lineitem where l_orderkey = 46;
delete from orders where o_orderkey = 46;
delete from lineitem where l_orderkey = 47;
delete from orders where o_orderkey = 47;
delete from lineitem where l_orderkey = 72;
delete from orders where o_orderkey = 72;
delete from lineitem where l_orderkey = 73;
delete from orders where o_orderkey = 73;
delete from lineitem where l_orderkey = 74;
delete from orders where o_orderkey = 74;
delete from lineitem where l_orderkey = 75;
delete from orders where o_orderkey = 75;
delete from lineitem where l_orderkey = 76;
delete from orders where o_orderkey = 76;
delete from lineitem where l_orderkey = 77;
delete from orders where o_orderkey = 77;
delete from lineitem where l_orderkey = 78;
delete from orders where o_orderkey = 78;
delete from lineitem where l_orderkey = 79;
delete from orders where o_orderkey = 79;
delete from lineitem where l_orderkey = 104;
delete from orders where o_orderkey = 104;
delete from lineitem where l_orderkey = 105;
delete from orders where o_orderkey = 105;
delete from lineitem where l_orderkey = 106;
delete from orders where o_orderkey = 106;
delete from lineitem where l_orderkey = 107;
delete from orders where o_orderkey = 107;
delete from lineitem where l_orderkey = 108;
delete from orders where o_orderkey = 108;
delete from lineitem where l_orderkey = 109;
delete from orders where o_orderkey = 109;
delete from lineitem where l_orderkey = 110;
delete from orders where o_orderkey = 110;
delete from lineitem where l_orderkey = 111;
delete from orders where o_orderkey = 111;
delete from lineitem where l_orderkey = 136;
delete from orders where o_orderkey = 136;
delete from lineitem where l_orderkey = 137;
delete from orders where o_orderkey = 137;
delete from lineitem where l_orderkey = 138;
delete from orders where o_orderkey = 138;
delete from lineitem where l_orderkey = 139;
delete from orders where o_orderkey = 139;
delete from lineitem where l_orderkey = 140;
delete from orders where o_orderkey = 140;
delete from lineitem where l_orderkey = 141;
delete from orders where o_orderkey = 141;
delete from lineitem where l_orderkey = 142;
delete from orders where o_orderkey = 142;
delete from lineitem where l_orderkey = 143;
delete from orders where o_orderkey = 143;
delete from lineitem where l_orderkey = 168;
delete from orders where o_orderkey = 168;
delete from lineitem where l_orderkey = 169;
delete from orders where o_orderkey = 169;
delete from lineitem where l_orderkey = 170;
delete from orders where o_orderkey = 170;
delete from lineitem where l_orderkey = 171;
delete from orders where o_orderkey = 171;
delete from lineitem where l_orderkey = 172;
delete from orders where o_orderkey = 172;
delete from lineitem where l_orderkey = 173;
delete from orders where o_orderkey = 173;
delete from lineitem where l_orderkey = 174;
delete from orders where o_orderkey = 174;
delete from lineitem where l_orderkey = 175;
delete from orders where o_orderkey = 175;
delete from lineitem where l_orderkey = 200;
delete from orders where o_orderkey = 200;
delete from lineitem where l_orderkey = 201;
delete from orders where o_orderkey = 201;
delete from lineitem where l_orderkey = 202;
delete from orders where o_orderkey = 202;
delete from lineitem where l_orderkey = 203;
delete from orders where o_orderkey = 203;
delete from lineitem where l_orderkey = 204;
delete from orders where o_orderkey = 204;
delete from lineitem where l_orderkey = 205;
delete from orders where o_orderkey = 205;
delete from lineitem where l_orderkey = 206;
delete from orders where o_orderkey = 206;
delete from lineitem where l_orderkey = 207;
delete from orders where o_orderkey = 207;
delete from lineitem where l_orderkey = 232;
delete from orders where o_orderkey = 232;
delete from lineitem where l_orderkey = 233;
delete from orders where o_orderkey = 233;
delete from lineitem where l_orderkey = 234;
delete from orders where o_orderkey = 234;
delete from lineitem where l_orderkey = 235;
delete from orders where o_orderkey = 235;
delete from lineitem where l_orderkey = 236;
delete from orders where o_orderkey = 236;
delete from lineitem where l_orderkey = 237;
delete from orders where o_orderkey = 237;
delete from lineitem where l_orderkey = 238;
delete from orders where o_orderkey = 238;
delete from lineitem where l_orderkey = 239;
delete from orders where o_orderkey = 239;
delete from lineitem where l_orderkey = 264;
delete from orders where o_orderkey = 264;
delete from lineitem where l_orderkey = 265;
delete from orders where o_orderkey = 265;
delete from lineitem where l_orderkey = 266;
delete from orders where o_orderkey = 266;
delete from lineitem where l_orderkey = 267;
delete from orders where o_orderkey = 267;
delete from lineitem where l_orderkey = 268;
delete from orders where o_orderkey = 268;
delete from lineitem where l_orderkey = 269;
delete from orders where o_orderkey = 269;
delete from lineitem where l_orderkey = 270;
delete from orders where o_orderkey = 270;
delete from lineitem where l_orderkey = 271;
delete from orders where o_orderkey = 271;
delete from lineitem where l_orderkey = 296;
delete from orders where o_orderkey = 296;
delete from lineitem where l_orderkey = 297;
delete from orders where o_orderkey = 297;
delete from lineitem where l_orderkey = 298;
delete from orders where o_orderkey = 298;
delete from lineitem where l_orderkey = 299;
delete from orders where o_orderkey = 299;
delete from lineitem where l_orderkey = 300;
delete from orders where o_orderkey = 300;
delete from lineitem where l_orderkey = 301;
delete from orders where o_orderkey = 301;
delete from lineitem where l_orderkey = 302;
delete from orders where o_orderkey = 302;
delete from lineitem where l_orderkey = 303;
delete from orders where o_orderkey = 303;
delete from lineitem where l_orderkey = 328;
delete from orders where o_orderkey = 328;
delete from lineitem where l_orderkey = 329;
delete from orders where o_orderkey = 329;
delete from lineitem where l_orderkey = 330;
delete from orders where o_orderkey = 330;
delete from lineitem where l_orderkey = 331;
delete from orders where o_orderkey = 331;
delete from lineitem where l_orderkey = 332;
delete from orders where o_orderkey = 332;
delete from lineitem where l_orderkey = 333;
delete from orders where o_orderkey = 333;
delete from lineitem where l_orderkey = 334;
delete from orders where o_orderkey = 334;
delete from lineitem where l_orderkey = 335;
delete from orders where o_orderkey = 335;
delete from lineitem where l_orderkey = 360;
delete from orders where o_orderkey = 360;
delete from lineitem where l_orderkey = 361;
delete from orders where o_orderkey = 361;
delete from lineitem where l_orderkey = 362;
delete from orders where o_orderkey = 362;
delete from lineitem where l_orderkey = 363;
delete from orders where o_orderkey = 363;
delete from lineitem where l_orderkey = 364;
delete from orders where o_orderkey = 364;
delete from lineitem where l_orderkey = 365;
delete from orders where o_orderkey = 365;
delete from lineitem where l_orderkey = 366;
delete from orders where o_orderkey = 366;
delete from lineitem where l_orderkey = 367;
delete from orders where o_orderkey = 367;
delete from lineitem where l_orderkey = 392;
delete from orders where o_orderkey = 392;
delete from lineitem where l_orderkey = 393;
delete from orders where o_orderkey = 393;
delete from lineitem where l_orderkey = 394;
delete from orders where o_orderkey = 394;
delete from lineitem where l_orderkey = 395;
delete from orders where o_orderkey = 395;
delete from lineitem where l_orderkey = 396;
delete from orders where o_orderkey = 396;
delete from lineitem where l_orderkey = 397;
delete from orders where o_orderkey = 397;
delete from lineitem where l_orderkey = 398;
delete from orders where o_orderkey = 398;
delete from lineitem where l_orderkey = 399;
delete from orders where o_orderkey = 399;
delete from lineitem where l_orderkey = 424;
delete from orders where o_orderkey = 424;
delete from lineitem where l_orderkey = 425;
delete from orders where o_orderkey = 425;
delete from lineitem where l_orderkey = 426;
delete from orders where o_orderkey = 426;
delete from lineitem where l_orderkey = 427;
delete from orders where o_orderkey = 427;
delete from lineitem where l_orderkey = 428;
delete from orders where o_orderkey = 428;
delete from lineitem where l_orderkey = 429;
delete from orders where o_orderkey = 429;
delete from lineitem where l_orderkey = 430;
delete from orders where o_orderkey = 430;
delete from lineitem where l_orderkey = 431;
delete from orders where o_orderkey = 431;
delete from lineitem where l_orderkey = 456;
delete from orders where o_orderkey = 456;
delete from lineitem where l_orderkey = 457;
delete from orders where o_orderkey = 457;
delete from lineitem where l_orderkey = 458;
delete from orders where o_orderkey = 458;
delete from lineitem where l_orderkey = 459;
delete from orders where o_orderkey = 459;
delete from lineitem where l_orderkey = 460;
delete from orders where o_orderkey = 460;
delete from lineitem where l_orderkey = 461;
delete from orders where o_orderkey = 461;
delete from lineitem where l_orderkey = 462;
delete from orders where o_orderkey = 462;
delete from lineitem where l_orderkey = 463;
delete from orders where o_orderkey = 463;
delete from lineitem where l_orderkey = 488;
delete from orders where o_orderkey = 488;
delete from lineitem where l_orderkey = 489;
delete from orders where o_orderkey = 489;
delete from lineitem where l_orderkey = 490;
delete from orders where o_orderkey = 490;
delete from lineitem where l_orderkey = 491;
delete from orders where o_orderkey = 491;
delete from lineitem where l_orderkey = 492;
delete from orders where o_orderkey = 492;
delete from lineitem where l_orderkey = 493;
delete from orders where o_orderkey = 493;
delete from lineitem where l_orderkey = 494;
delete from orders where o_orderkey = 494;
delete from lineitem where l_orderkey = 495;
delete from orders where o_orderkey = 495;
delete from lineitem where l_orderkey = 520;
delete from orders where o_orderkey = 520;
delete from lineitem where l_orderkey = 521;
delete from orders where o_orderkey = 521;
delete from lineitem where l_orderkey = 522;
delete from orders where o_orderkey = 522;
delete from lineitem where l_orderkey = 523;
delete from orders where o_orderkey = 523;
delete from lineitem where l_orderkey = 524;
delete from orders where o_orderkey = 524;
delete from lineitem where l_orderkey = 525;
delete from orders where o_orderkey = 525;
delete from lineitem where l_orderkey = 526;
delete from orders where o_orderkey = 526;
delete from lineitem where l_orderkey = 527;
delete from orders where o_orderkey = 527;
delete from lineitem where l_orderkey = 552;
delete from orders where o_orderkey = 552;
delete from lineitem where l_orderkey = 553;
delete from orders where o_orderkey = 553;
delete from lineitem where l_orderkey = 554;
delete from orders where o_orderkey = 554;
delete from lineitem where l_orderkey = 555;
delete from orders where o_orderkey = 555;
delete from lineitem where l_orderkey = 556;
delete from orders where o_orderkey = 556;
delete from lineitem where l_orderkey = 557;
delete from orders where o_orderkey = 557;
delete from lineitem where l_orderkey = 558;
delete from orders where o_orderkey = 558;
delete from lineitem where l_orderkey = 559;
delete from orders where o_orderkey = 559;
delete from lineitem where l_orderkey = 584;
delete from orders where o_orderkey = 584;
delete from lineitem where l_orderkey = 585;
delete from orders where o_orderkey = 585;
delete from lineitem where l_orderkey = 586;
delete from orders where o_orderkey = 586;
delete from lineitem where l_orderkey = 587;
delete from orders where o_orderkey = 587;
delete from lineitem where l_orderkey = 588;
delete from orders where o_orderkey = 588;
delete from lineitem where l_orderkey = 589;
delete from orders where o_orderkey = 589;
delete from lineitem where l_orderkey = 590;
delete from orders where o_orderkey = 590;
