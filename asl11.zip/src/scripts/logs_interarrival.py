#!/usr/bin/env python
# encoding: utf-8

import os
import sys

from logs_timing import (MINUTE, RX_LOG_DIRNAME, RX_MIDDLEWARE_REQUEST,
    LogEntries, WalkLogFiles)

SCRIPT_DIR, SCRIPT_NAME = os.path.split(os.path.abspath(__file__))

def RequestTimeFromMiddlewareLog(fn):
    # nanoTime() measures from some 'fixed but arbitrary time' (not necessarily zero).
    # we also assume the clock increases monotonically (with occasional lag due to logging).
    start_time = None
    rel_time = lambda s: int(s) - start_time
    arrival_times = []

    f = open(fn, 'rU')
    try:
        for entry in LogEntries(f):
            message = entry['message']

            # only inspect requests
            match = RX_MIDDLEWARE_REQUEST.search(message)
            if match:
                request_info = match.groupdict()
                time = int(request_info['time'])
                if start_time is None:
                    start_time = time
                time = rel_time(time)
                arrival_times.append(time)
    finally:
        f.close()

    return arrival_times  # not necessarily in sorted order!

def InterarrivalTime(arrival_times):
    arrival_times = sorted(arrival_times)
    for i in xrange(1, len(arrival_times)):
        t1 = arrival_times[i-1]
        t2 = arrival_times[i]
        interarrival = t2 - t1
        assert interarrival >= 0
        minute = (t2 / MINUTE) + 1
        yield minute, interarrival

def ExtractTiming(out_base_fn, log_directories):
    # Validate input paths and gather information
    in_paths = []
    for in_path in log_directories:
        in_path = os.path.abspath(in_path)
        if not os.path.isdir(in_path):
            print >> sys.stderr, 'Error: path does not exist: %s' % in_path
            sys.exit(1)
        match = RX_LOG_DIRNAME.search(in_path)
        if not match:
            print >> sys.stderr, 'Error: invalid directory name: %s' % in_path
            sys.exit(1)
        in_paths.append((in_path, match.groupdict()))

    arrival_times = []
    for in_path, in_info in in_paths:
        for log_fn, log_info in WalkLogFiles(in_path, 'middleware'):
            arrival_times.extend(RequestTimeFromMiddlewareLog(log_fn))

    # Write output file
    base, ext = os.path.splitext(out_base_fn)
    out_fn = '%s-interarrival%s' % (base, ext)
    out_f = open(out_fn, 'w')
    try:
        for minute, interarrival in InterarrivalTime(arrival_times):
            out_f.write('%s %s\n' % (minute, interarrival))
    finally:
        out_f.close()

def main(args):
    """
    Extract timing information for all client jobs and group by minute.
    """
    # parse command-line arguments
    if len(args) <= 1:
        print >> sys.stderr, 'Usage: %s <output file> <log directories>' % SCRIPT_NAME
        sys.exit(1)

    out_base_fn = os.path.abspath(args[0])
    log_directories = args[1:]
    ExtractTiming(out_base_fn, log_directories)

if __name__ == "__main__":
    main(sys.argv[1:])
