#!/usr/bin/env python
# encoding: utf-8

import os
import sys

from pprint import pprint

try:
    import regex as re
except ImportError:
    import re

import numpy

SCRIPT_DIR, SCRIPT_NAME = os.path.split(os.path.abspath(__file__))

REQUEST_ONLY = True
RESPONSE_ONLY = False

# This regex only captures the first line of each log entry.  We re-assemble
# multi-line messages by appending all non-matching lines.
#
# (An alternative may be to use re.MULTILINE in conjunction with re.finditer.)
RX_LOG_ENTRY = re.compile(r"""
    ^
    \[(?P<datetime>[^\]]{23})\]\s+
    (?P<priority>TRACE|DEBUG|INFO|WARN|ERROR|FATAL)\s+
    \[(?P<category>[^\]]+)\]\s+
    \[(?P<thread>[^\]]+)\]\s+
    (?P<message>.*)
    $
""", re.VERBOSE)

def LogEntries(lines):
    """
    Parses a log file and yields each entry as a dictionary.
    Input assumed to have the following format (log4j ConversionPattern):
        "[%d{ISO8601}] %-5p [%c] [%t] %m %n"
    """

    match_info, message_lines = None, None
    for lineno, line in enumerate(lines):
        match = RX_LOG_ENTRY.match(line)
        if match:
            if match_info is not None:
                # stich together message and yield current entry
                assert message_lines is not None
                message = '\n'.join(message_lines)
                match_info['message'] = message
                yield match_info
                match_info, message_lines = None, None

            # start a new log entry
            assert (match_info is None) and (message_lines is None)
            match_info = match.groupdict()
            message_lines = [match_info['message']]
        else:
            if match_info is None:
                raise Exception(
                    'abort: malformed log entry on line %d: %r' % (lineno, line))
            else:
                # append to existing log entry
                assert message_lines is not None
                if line[-1] == '\n':
                    line = line[:-1]
                message_lines.append(line)

    # handle last entry
    if match_info is not None:
        assert message_lines is not None
        message = '\n'.join(message_lines)
        match_info['message'] = message
        yield match_info

def RoundToNextMultiple(num, multiple):
    """
    Rounds |num| up to nearest multiple of |multiple|
    (even if |num| is already a multiple of |multiple|)
    """
    rem = num % multiple
    num_rounded = num + multiple - rem
    assert (num_rounded > num) and (num_rounded % multiple == 0)
    return num_rounded

RX_LOG_DIRNAME = re.compile(r"""
    logs\-
    (?P<date>\d{8}\-\d{6})\-
    (?P<clients>\d+)cl\-
    (?P<middleware>\d+)mw\-
    (?P<databases>\d+)db\-
    (?P<mode>replication|sharding)
""", re.VERBOSE)

RX_LOG_FILENAME = re.compile(r"""
    (?P<node>client|middleware)\-
    (?P<id>\d+)\.
    (?P<datetime>\d{8}\-\d{6})\.
    (?P<priority>DEBUG\-TRACE|INFO|WARNING\-FATAL)
    \.log
""", re.VERBOSE)

def WalkLogFiles(root_dir, node, priority='INFO'):
    logs = []
    for base, _, files in os.walk(root_dir):
        for fn_base in files:
            match = RX_LOG_FILENAME.match(fn_base)
            if not match:
                continue
            info = match.groupdict()
            if info['node'] == node and info['priority'] == priority:
                fn = os.path.join(base, fn_base)
                logs.append((fn, info))

   #dates = set(info['datetime'] for fn, info in logs)
   #if len(dates) > 1:
   #    raise Exception(
   #        'Several experiment results are present: %s', ', '.join(dates))

    return logs

# TODO: replace these with re.finditer(r'\w+\=\[[^\]]+\]')

# Client log entries span multiple lines (parameters and response data)
# Middleware entries fit entirely on a single line
RX_CLIENT_REQUEST = re.compile(
    r'sending request.+jobId\=\[(?P<jobId>[^\]]+)\].+time\=\[(?P<time>\d+)\].+workload\=\[\{(?P<type>REFRESH_\d+_\d+|QUERY_\d+)',
    re.DOTALL | re.MULTILINE)

RX_CLIENT_RESPONSE = re.compile(
    r'received response.+jobId\=\[(?P<jobId>[^\]]+)\].+time\=\[(?P<time>\d+)\].+elapsed=\[(?P<elapsed>\d+)ms\]',
    re.DOTALL | re.MULTILINE)

RX_MIDDLEWARE_REQUEST = re.compile(
    r'received request.+jobId\=\[(?P<jobId>[^\]]+)\].+time\=\[(?P<time>\d+)\].+request\=\[(?P<type>REFRESH_\d+_\d+|QUERY_\d+)')

RX_MIDDLEWARE_EXECUTING = re.compile(
    r'executing.+jobId\=\[(?P<jobId>[^\]]+)\].+time=\[(?P<time>\d+)\]')

RX_MIDDLEWARE_RESPONSE = re.compile(
    r'sending response.+jobId\=\[(?P<jobId>[^\]]+)\].+time=\[(?P<time>\d+)\].+request\=\[(?P<type>REFRESH_\d+_\d+|QUERY_\d+).+elapsed\=\[(?P<elapsed>\d+)ms\]')

RX_COMPONENT_IGNORE = re.compile('|'.join(re.escape(x) for x in [
    'atomikos',
    'org.springframework.',
    'com.mchange.v2.',
    'ch.ethz.asl.common.application.AbstractMain',
]))

def TimingInfoFromFile(fn, node):
    if node == 'client':
        rx_request = RX_CLIENT_REQUEST
        rx_executing = None
        rx_response = RX_CLIENT_RESPONSE
        get_type = lambda req, resp: req['type']
    elif node == 'middleware':
        rx_request = RX_MIDDLEWARE_REQUEST
        rx_executing = RX_MIDDLEWARE_EXECUTING
        rx_response = RX_MIDDLEWARE_RESPONSE
        get_type = lambda req, resp: resp['type']
    else:
        raise NotImplementedError()

    assert not (REQUEST_ONLY and RESPONSE_ONLY), 'both filters should not be active at the same time'

    # nanoTime() measures from some 'fixed but arbitrary time' (not necessarily zero).
    # we also assume the clock increases monotonically (with occasional lag due to logging).
    start_time = None
    last_time = None
    rel_time = lambda s: int(s) - start_time

    # (time, elapsed) - segregated by type
    data_query, data_insert, data_delete = [], [], []
    open_requests = {}
    f = open(fn, 'rU')
    try:
        for entry in LogEntries(f):
            message = entry['message']

            # request
            match = rx_request.search(message)
            if match:
                request_info = match.groupdict()

                time = int(request_info['time'])
                if start_time is None:
                    start_time = time
                time = rel_time(time)
                assert time >= 0, 'negative time!'

                open_requests[request_info['jobId']] = [request_info, None]

                if REQUEST_ONLY:
                    request_type = request_info['type'].lower()
                    if request_type.startswith('query'):
                        data_query.append((time, 1, None))
                    elif request_type.startswith('refresh_1'):
                        data_insert.append((time, 1, None))
                    elif request_type.startswith('refresh_2'):
                        data_delete.append((time, 1, None))
                    else:
                        raise Exception('Unknown request type (%r)' % request_type)
                else:
                    if last_time is not None:
                        assert time + 500 >= last_time, 'clock is not monotonically increasing!'
                    last_time = time

                continue

            # executing
            if rx_executing is not None:
                match = rx_executing.search(message)
                if match:
                    exec_info = match.groupdict()
                    # Ignore the additional entries from 'ThreadMultiDbConnections'
                    if entry['thread'].startswith('Dispatcher'):
                        open_requests[exec_info['jobId']][1] = exec_info
                    continue

            # response
            match = rx_response.search(message)
            if match:
                if not REQUEST_ONLY:
                    response_info = match.groupdict()

                    jobId = response_info['jobId']
                    request_info, exec_info = open_requests[jobId]
                    del open_requests[jobId]

                    req_time = rel_time(request_info['time'])
                    resp_time = rel_time(response_info['time'])
                    assert req_time < resp_time

                    if RESPONSE_ONLY:
                        if request_type.startswith('query'):
                            data_query.append((resp_time, 1, None))
                        elif request_type.startswith('refresh_1'):
                            data_insert.append((resp_time, 1, None))
                        elif request_type.startswith('refresh_2'):
                            data_delete.append((resp_time, 1, None))
                        else:
                            raise Exception('Unknown request type (%r)' % request_type)
                    else:
                        total_interval = resp_time - req_time

                        if rx_executing is not None:
                            assert exec_info is not None, 'Job %r was not executed' % jobId
                            exec_time = rel_time(exec_info['time'])
                            assert req_time <= exec_time < resp_time

                            wait_interval = exec_time - req_time
                            service_interval = resp_time - exec_time
                            payload = (wait_interval, service_interval)
                        else:
                            payload = None

                        elapsed = int(response_info['elapsed'])
                        assert 10 < elapsed < 10 * MINUTE, (
                            'elapsed = %d -> does this make sense?' % elapsed)  # sanity check on data
                        assert abs(elapsed - total_interval) < 2000, (
                            'elapsed = %d but (resp - req) = %d (jobId = %s)' % (
                                elapsed, total_interval, jobId))

                        request_type = get_type(request_info, response_info).lower()
                        if request_type.startswith('query'):
                            data_query.append((req_time, elapsed, payload))
                        elif request_type.startswith('refresh_1'):
                            data_insert.append((req_time, elapsed, payload))
                        elif request_type.startswith('refresh_2'):
                            data_delete.append((req_time, elapsed, payload))
                        else:
                            raise Exception('Unknown request type (%r)' % request_type)

                continue

            if RX_COMPONENT_IGNORE.match(entry['category']):
                continue

            raise Exception('Unexpected log message (%r)' % message)
    finally:
        f.close()

    return data_query, data_insert, data_delete

def AccumulateLogData(in_dir, node):
    global_data_query, global_data_insert, global_data_delete = [], [], []
    for log_fn, info in WalkLogFiles(in_dir, node):
        data_query, data_insert, data_delete = TimingInfoFromFile(log_fn, node)
       #print os.path.basename(log_fn), len(data_query), len(data_insert), len(data_delete)
        global_data_query.extend(data_query)
        global_data_insert.extend(data_insert)
        global_data_delete.extend(data_delete)
   #print '** GLOBAL **', len(global_data_query), len(global_data_insert), len(global_data_delete)

    return global_data_query, global_data_insert, global_data_delete

# time (ms)
SECOND = 1000
MINUTE = 60 * SECOND

def GroupByMinute(data):
    BIN_SIZE = 1 * MINUTE
    data = sorted(data)
    assert len(data) > 2
    assert data[0] >= 0

    # TODO: store directly as numpy.array above
    time = numpy.array([x[0] for x in data])
    assert len(x[1:]) > 0
    if len(x[1:]) == 1:
        other = [x[1] for x in data]
    else:
        other = [x[1:] for x in data]

    min_time = 0
    max_time = RoundToNextMultiple(data[-1][0], BIN_SIZE) + BIN_SIZE
    minute_bins = numpy.arange(min_time, max_time, BIN_SIZE)
    minutes = len(minute_bins)

    inds = numpy.digitize(time, minute_bins)
    data_per_minute = [[] for i in xrange(minutes)]  # grouped data
    for i in xrange(len(time)):
        assert 0 < inds[i] < minutes
        assert minute_bins[inds[i]-1] <= time[i] < minute_bins[inds[i]]
        data_per_minute[inds[i]-1].append(other[i])

    return minute_bins, data_per_minute

def ExtractTiming(out_base_fn, log_directories):
    # Validate input paths and gather information
    in_paths = []
    for in_path in log_directories:
        in_path = os.path.abspath(in_path)
        if not os.path.isdir(in_path):
            print >> sys.stderr, 'Error: path does not exist: %s' % in_path
            sys.exit(1)
        match = RX_LOG_DIRNAME.search(in_path)
        if not match:
            print >> sys.stderr, 'Error: invalid directory name: %s' % in_path
            sys.exit(1)
        in_paths.append((in_path, match.groupdict()))

    # Gather input data and split by type
    if REQUEST_ONLY or RESPONSE_ONLY:
        node_types = ['middleware']
    else:
        node_types = ['client', 'middleware']
    for node in node_types:
        all_data_raw = {
            'replication': dict(Q1=[], RF1=[], RF2=[]),
            'sharding': dict(Q1=[], RF1=[], RF2=[]),
        }
        for path, info in in_paths:
            data_query, data_insert, data_delete = AccumulateLogData(path, node)
            data = all_data_raw[info['mode']]
            data['Q1'].extend(data_query)
            data['RF1'].extend(data_insert)
            data['RF2'].extend(data_delete)

        longest_minute_bin = []
        all_data_grouped = dict(replication=dict(), sharding=dict())  # elapsed_per_minute
        for mode, data in all_data_raw.iteritems():
            for request_type, timing_data in data.iteritems():
                if not timing_data:
                    continue
                minute_bins, elapsed_per_minute = GroupByMinute(timing_data)
                if len(minute_bins) > len(longest_minute_bin):
                    longest_minute_bin = minute_bins
                if REQUEST_ONLY or RESPONSE_ONLY:
                    elapsed_per_minute = [
                        [(sum(x[0] for x in item), None)] for item in elapsed_per_minute]
                all_data_grouped[mode][request_type] = elapsed_per_minute

        # Write output file
        base, ext = os.path.splitext(out_base_fn)
        out_fn = '%s-%s%s' % (base, node, ext)
        out_f = open(out_fn, 'w')
        try:
           #out_f.write('# timing information for %s from %r\n' % (
           #    node, [os.path.relpath(x[0]) for x in in_paths]))
           #out_f.write('# time (minutes), list of elapsed times (ms)\n')

            for i in xrange(len(longest_minute_bin)):
                minute = longest_minute_bin[i] / MINUTE + 1
                for mode in sorted(all_data_grouped):
                    data = all_data_grouped[mode]
                    for request_type in sorted(data):
                        elapsed_per_minute = data[request_type]
                        if i in xrange(len(elapsed_per_minute)):
                            for time, payload in elapsed_per_minute[i]:
                                out_f.write('%s %s %s %s' % (
                                    minute, mode.capitalize(), request_type, time))
                                if payload is not None:
                                    out_f.write(' %s' % ' '.join(str(x) for x in payload))
                                out_f.write('\n')

                           #timings = ' '.join(str(x) for x in elapsed_per_minute[i])
                           #out_f.write('%s %s %s %s\n' % (minute, mode, request_type, timings))
        finally:
            out_f.close()

def main(args):
    """
    Extract timing information for all client jobs and group by minute.
    """
    # parse command-line arguments
    if len(args) <= 1:
        print >> sys.stderr, 'Usage: %s <output file> <log directories>' % SCRIPT_NAME
        sys.exit(1)

    out_base_fn = os.path.abspath(args[0])
    log_directories = args[1:]
    ExtractTiming(out_base_fn, log_directories)

if __name__ == "__main__":
    main(sys.argv[1:])
