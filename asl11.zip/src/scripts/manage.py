#!/usr/bin/env python
# encoding: utf-8

"""
Advanced Systems Lab (Fall 2011)
Class 2, Group 2:
    Giovanni Azua Garcia
    Zaheer Chothia
"""

# TODO: break this file into smaller modules and add a better description

import datetime
import email.utils
import errno
import logging
import os
import pdb
import random
import shutil
import socket
import subprocess
import sys
import tempfile
import textwrap
import time
import traceback
import threading
import urllib2

try:
    import regex as re
except ImportError:
    import re

try:
    from hashlib import sha1
except ImportError:
    from sha import sha as sha1

try:
    import argparse
except ImportError:
    import argparse_local as argparse

import setuptools.archive_util  # unpack_archive

log = logging.getLogger()

SCRIPT_DIR, SCRIPT_NAME = os.path.split(os.path.abspath(__file__))

# Avoid writing platform-specific code, but if necessary prefer POSIX
# to something more specific (i.e. Linux/Mac)
OS_LINUX = sys.platform.startswith('linux')
OS_MAC = sys.platform == 'darwin'
OS_POSIX = os.name == 'posix'
OS_WIN = sys.platform == 'win32'

#-------------------------------------------------------------------------------
# Common utilities

def enum(*sequential, **named):
    # http://stackoverflow.com/questions/36932/whats-the-best-way-to-implement-an-enum-in-python/1695250#1695250
    enums = dict(zip(sequential, range(len(sequential))), **named)
    return type('enum', (), enums)

def _shell_log(command, cwd):
    if isinstance(command, basestring):
        cmdstr = command
    else:
        cmdstr = subprocess.list2cmdline(command)
    if cwd is None:
        log.debug('Executing command %s' % repr(cmdstr))
    else:
        log.debug('Executing command %s from directory %s' %
                  (repr(cmdstr), repr(cwd)))
    return cmdstr

def shell(command, check_retcode=False, print_output=False, env=None, **kwargs):
    """ Runs a command, returning its exit status and output """
    cwd = kwargs.get('cwd', None)
    cmdstr = _shell_log(command, cwd)
    if env is not None:
        new_env = os.environ.copy()
        new_env.update(env)
        env = new_env

    proc = subprocess.Popen(command,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,
                            bufsize=1,  # line buffered
                            env=env,
                            universal_newlines=True,
                            **kwargs)

    if print_output:
        output = None
        # reading directly from proc.stdout could result in deadlock;
        # use reader thread instead (see subprocess.Popen._communicate)
        def worker(inpipe, outpipe, buf, lock):
            line = inpipe.readline()
            while line:
                buf.append(line)
                lock.acquire()
                outpipe.write(line)
                outpipe.flush()
                lock.release()
                line = inpipe.readline()

        output_buffer = []
        console_lock = threading.Lock()
        stdout_worker = threading.Thread(
                target=worker,
                args=(proc.stdout, sys.stdout, output_buffer, console_lock))
        stdout_worker.start()
        stdout_worker.join()
        output = ''.join(output_buffer)
    else:
        output, errout = proc.communicate()
        assert errout is None

    retcode = proc.wait()

    if not output:
        log.debug('process exited (exit status %d)', retcode)
    else:
        log_output = []
        for line in output.splitlines():
            log_output.append('  %s\n' % line)
        log_output = ''.join(log_output)

        log.debug('process exited (exit status %d)\nOutput:\n%s',
                retcode, log_output)

    if check_retcode and retcode != 0:
        raise subprocess.CalledProcessError(retcode, cmdstr)

    return retcode, output

# This is needed to work around PostgreSQL tools hanging or complaining about
# missing command-line arguments.  On Windows, it's important to use shell(...)
# to prevent quoting issues.
if OS_WIN:
    def raw_shell(*args, **kwargs):
        kwargs.pop('check_retcode', None)
        kwargs.pop('print_output', None)
        return shell(*args, check_retcode=True, print_output=True, **kwargs)
else:
    def raw_shell(command, cwd=None, env=None):
        check_retcode = True
        cmdstr = _shell_log(command, cwd)
        if env is not None:
            envcmd = []
            for key, value in env.iteritems():
                assert ' ' not in key
                if ' ' in value:
                    value = '"%s"' % value
                envcmd.append('%s=%s' % (key, value))
            cmdstr = '%s %s' % (' '.join(envcmd), cmdstr)
            log.debug('raw_shell: rewrote command due to environment: %s' % repr(cmdstr))

        try:
            if cwd is not None:
                old_cwd = os.getcwd()
                os.chdir(cwd)

            retcode = os.system(cmdstr)
            output = 'Not supported - this command was launched with raw_shell'
        finally:
            if cwd is not None:
                os.chdir(old_cwd)

        if not output:
            log.debug('process exited (exit status %d)', retcode)
        else:
            log_output = []
            for line in output.splitlines():
                log_output.append('  %s\n' % line)
            log_output = ''.join(log_output)

            log.debug('process exited (exit status %d)\nOutput:\n%s',
                    retcode, log_output)

        if check_retcode and retcode != 0:
            raise subprocess.CalledProcessError(retcode, cmdstr)

        return retcode, output

def cpu_count():
    '''
    Returns the number of CPUs in the system
    Taken from |multiprocessing| module of Python 2.7
    '''
    if sys.platform == 'win32':
        try:
            num = int(os.environ['NUMBER_OF_PROCESSORS'])
        except (ValueError, KeyError):
            num = 0
    elif 'bsd' in sys.platform or sys.platform == 'darwin':
        comm = '/sbin/sysctl -n hw.ncpu'
        if sys.platform == 'darwin':
            comm = '/usr' + comm
        try:
            _, output = shell(comm, shell=True, check_retcode=True)
            num = int(output)
        except ValueError:
            num = 0
    else:
        try:
            num = os.sysconf('SC_NPROCESSORS_ONLN')
        except (ValueError, OSError, AttributeError):
            num = 0

    if num < 1:
        num = 0
    return num

def download(url, filename, sha1):
    if os.path.isfile(filename):
        log.debug('Not downloading "%s" - file "%s" already exists',
                  url, filename)
        url = None
    else:
        log.debug('Downloading "%s" to "%s"', url, filename)
        response = urllib2.urlopen(url)
        # we may have been redirected -> use final url
        url = response.url

        destfile = open(filename, 'wb')
        try:
            shutil.copyfileobj(response, destfile)
        finally:
            destfile.close()

        last_modified = response.headers.getdate_tz('last-modified')
        if last_modified is not None:
            mtime = email.utils.mktime_tz(last_modified)
            st = os.stat(filename)
            os.utime(filename, (st.st_atime, mtime))

    check_sha1(filename, sha1)
    return url

def check_sha1(filename, refhash):
    filehash = sha1()
    class HashStream(object):
        def write(self, bytestr):
            filehash.update(bytestr)

    f = open(filename, 'rb')
    try:
        shutil.copyfileobj(f, HashStream())
    finally:
        f.close()
    actualhash = filehash.hexdigest()

    if actualhash != refhash:
        raise Exception(
            'SHA1 mismatch with file "%s": actual = "%s", expected = "%s"' %
            (filename, actualhash, refhash))
    else:
        log.debug('Valid SHA1 hash for file "%s": "%s"', filename, actualhash)

def unpack_archive(filename, extract_dir):
    # setuptools supports tar.bz2, tar.gz2 and zip
    log.debug('Extracting archive "%s" into directory "%s"', filename, extract_dir)
    setuptools.archive_util.unpack_archive(filename, extract_dir)

def makedirs(*path):
    """Create directory at path, if it doesn't already exist."""
    full_path = os.path.join(*path)
    try:
        os.makedirs(full_path)
    except OSError, e:
        if e.errno != errno.EEXIST:
            raise
    return full_path

def modify_file(filename, line_func):
    f_in = open(filename)
    f_out = atomictempfile(filename, 'w')
    try:
        for line in f_in:
            line = line_func(line)
            if line is not None:
                f_out.write(line)
    finally:
        f_in.close()
        f_out.close()

#-------------------------------------------------------------------------------
# Adapted from Mercurial sources (http://selenic.com/repo/hg, rev: 6dc67dced8c1)
# "from mercurial.util import atomictempfile"

# platform-specific
if OS_WIN:
    # mercurial/windows.py
    def copymode(src, dst, mode=None):
        pass

    def rename(src, dst):
        '''atomically rename file src to dst, replacing dst if it exists'''
        try:
            os.rename(src, dst)
        except OSError, e:
            if e.errno != errno.EEXIST:
                raise
            unlink(dst)
            os.rename(src, dst)

    # mercurial/win32.py
    import ctypes
    _kernel32 = ctypes.windll.kernel32

    _FILE_ATTRIBUTE_NORMAL = 0x80

    def unlink(f):
        '''try to implement POSIX' unlink semantics on Windows'''

        # POSIX allows to unlink and rename open files. Windows has serious
        # problems with doing that:
        # - Calling os.unlink (or os.rename) on a file f fails if f or any
        #   hardlinked copy of f has been opened with Python's open(). There is no
        #   way such a file can be deleted or renamed on Windows (other than
        #   scheduling the delete or rename for the next reboot).
        # - Calling os.unlink on a file that has been opened with Mercurial's
        #   posixfile (or comparable methods) will delay the actual deletion of
        #   the file for as long as the file is held open. The filename is blocked
        #   during that time and cannot be used for recreating a new file under
        #   that same name ("zombie file"). Directories containing such zombie files
        #   cannot be removed or moved.
        # A file that has been opened with posixfile can be renamed, so we rename
        # f to a random temporary name before calling os.unlink on it. This allows
        # callers to recreate f immediately while having other readers do their
        # implicit zombie filename blocking on a temporary name.

        for tries in xrange(10):
            temp = '%s-%08x' % (f, random.randint(0, 0xffffffff))
            try:
                os.rename(f, temp)  # raises OSError EEXIST if temp exists
                break
            except OSError, e:
                if e.errno != errno.EEXIST:
                    raise
        else:
            raise IOError, (errno.EEXIST, "No usable temporary filename found")

        try:
            os.unlink(temp)
        except OSError:
            # The unlink might have failed because the READONLY attribute may heave
            # been set on the original file. Rename works fine with READONLY set,
            # but not os.unlink. Reset all attributes and try again.
            _kernel32.SetFileAttributesA(temp, _FILE_ATTRIBUTE_NORMAL)
            try:
                os.unlink(temp)
            except OSError:
                # The unlink might have failed due to some very rude AV-Scanners.
                # Leaking a tempfile is the lesser evil than aborting here and
                # leaving some potentially serious inconsistencies.
                pass
else:
    # mercurial/posix.py
    _umask = os.umask(0)
    os.umask(_umask)

    def copymode(src, dst, mode=None):
        '''Copy the file mode from the file at path src to dst.
        If src doesn't exist, we're using mode instead. If mode is None, we're
        using umask.'''
        try:
            st_mode = os.lstat(src).st_mode & 0777
        except OSError, inst:
            if inst.errno != errno.ENOENT:
                raise
            st_mode = mode
            if st_mode is None:
                st_mode = ~_umask
            st_mode &= 0666
        os.chmod(dst, st_mode)

    rename = os.rename
    unlink = os.unlink

_notset = object()
def safehasattr(thing, attr):
    return getattr(thing, attr, _notset) is not _notset

def mktempcopy(name, emptyok=False, createmode=None):
    """Create a temporary file with the same contents from name

    The permission bits are copied from the original file.

    If the temporary file is going to be truncated immediately, you
    can use emptyok=True as an optimization.

    Returns the name of the temporary file.
    """
    d, fn = os.path.split(name)
    fd, temp = tempfile.mkstemp(prefix='.%s-' % fn, dir=d)
    os.close(fd)
    # Temporary files are created with mode 0600, which is usually not
    # what we want.  If the original file already exists, just copy
    # its mode.  Otherwise, manually obey umask.
    copymode(name, temp, createmode)
    if emptyok:
        return temp
    try:
        try:
            ifp = open(name, "rb")
        except IOError, inst:
            if inst.errno == errno.ENOENT:
                return temp
            if not getattr(inst, 'filename', None):
                inst.filename = name
            raise
        ofp = open(temp, "wb")
        shutil.copyfileobj(ifp, ofp)
        ifp.close()
        ofp.close()
    except:
        try: os.unlink(temp)
        except: pass
        raise
    return temp

class atomictempfile(object):
    '''writeable file object that atomically updates a file

    All writes will go to a temporary copy of the original file. Call
    close() when you are done writing, and atomictempfile will rename
    the temporary copy to the original name, making the changes
    visible. If the object is destroyed without being closed, all your
    writes are discarded.
    '''
    def __init__(self, name, mode='w+b', createmode=None):
        self.__name = name      # permanent name
        self._tempname = mktempcopy(name, emptyok=('w' in mode),
                                    createmode=createmode)
        self._fp = open(self._tempname, mode)

        # delegated methods
        self.write = self._fp.write
        self.fileno = self._fp.fileno

    def close(self):
        if not self._fp.closed:
            self._fp.close()
            rename(self._tempname, self.__name)

    def discard(self):
        if not self._fp.closed:
            try:
                os.unlink(self._tempname)
            except OSError:
                pass
            self._fp.close()

    def __del__(self):
        if safehasattr(self, '_fp'): # constructor actually did something
            self.discard()

#-------------------------------------------------------------------------------
# Configuration parameters

# TODO: once we add SSH/SCP, this needs to be passed as a parameter
HOSTNAME, _, _ = socket.gethostbyaddr(socket.gethostname())
ETHZ_CLUSTER = re.match(r'ikr\d+\.ethz\.ch', HOSTNAME)

if ETHZ_CLUSTER:
    # TODO: chmod go-rwx (limit permissions)
    TOOLS_DIR = '/local/asl11/c2g2/tools'
else:
    TOOLS_DIR = os.path.join(SCRIPT_DIR, 'tools')

POSTGRESQL_VERSION = '9.1.1'
POSTGRESQL_BASE = 'postgresql-%s' % POSTGRESQL_VERSION
POSTGRESQL_FILE = '%s.tar.bz2' % POSTGRESQL_BASE
POSTGRESQL_URL = 'http://ftp2.ch.postgresql.org/pub/mirrors/postgresql/source/v%s/%s' % (
    POSTGRESQL_VERSION, POSTGRESQL_FILE)
POSTGRESQL_SHA1 = '4df7b6f6b23acdac5ea198e3623796a2b62fc7a4'

READLINE_VERSION = '6.2'
READLINE_BASE = 'readline-%s' % READLINE_VERSION
READLINE_FILE = '%s.tar.gz' % READLINE_BASE
READLINE_URL = 'ftp://ftp.cwru.edu/pub/bash/%s' % READLINE_FILE
READLINE_SHA1 = 'a9761cd9c3da485eb354175fcc2fe35856bc43ac'

TPCH_DBGEN_BASE = 'tpch_2_14_0_dbgen'
TPCH_DBGEN_FILE = '%s.tar.bz2' % TPCH_DBGEN_BASE
TPCH_DBGEN_URL = 'http://n.ethz.ch/~zchothia/asl2011/%s' % TPCH_DBGEN_FILE
TPCH_DBGEN_SHA1 = 'f0e598c61152af424f788d1f8d82b61c3166e25d'
TPCH_DBGEN_SCALE_FACTOR = 0.1

TPCH_DB_PORT = 22000
TPCH_DB_NAME = 'tpch'
TPCH_DB_USER = 'asl_c2g2'
TPCH_DB_PSWD = 'matterhorn'

PG_HBA_CONF_ETHZ = textwrap.dedent("""
    # http://www.postgresql.org/docs/9.1/static/auth-pg-hba-conf.html
    # http://www.komcenter.ethz.ch/confluence/display/dk/IP-Bereich
    # ETH-Hauptnetz
    host    all             all             82.130.64.0/18             trust
    host    all             all             129.132.0.0/16             trust
    host    all             all             195.176.96.0/19            trust
    # public-WLan und guest-Docking
    host    all             all             172.30.0.0/16              trust
    # NETng Spezial-Subnetze
    host    all             all             172.31.0.0/16              trust
    # nicht geroutet to Switch
    host    all             all             192.33.87.0/24             trust
    # ETH-Hauptnetz
    host    all             all             192.33.88.0/24             trust
    host    all             all             192.33.89.0/24             trust
    # ETH-Open-Net
    host    all             all             192.33.90.0/24             trust
    # ETH-Hauptnetz
    host    all             all             192.33.91.0/24             trust
    # Verbindung zwischen ETH und SWITCH
    host    all             all             192.33.92.0/24             trust
    # ETH-Hauptnetz
    host    all             all             192.33.93.0/24             trust
    host    all             all             192.33.94.0/24             trust
    host    all             all             192.33.95.0/24             trust
    host    all             all             192.33.96.0/21             trust
    host    all             all             192.33.104.0/22            trust
    host    all             all             192.33.108.0/23            trust
    host    all             all             192.33.110.0/24            trust
    # zchothia
    host    all             all             217.162.213.238/32         trust
""")

SQL_TABLE_CONSTRAINTS = [
    'ALTER TABLE REGION ADD PRIMARY KEY (R_REGIONKEY);',
    'ALTER TABLE NATION ADD PRIMARY KEY (N_NATIONKEY);',
    'ALTER TABLE NATION ADD FOREIGN KEY (N_REGIONKEY) REFERENCES REGION;',

    'ALTER TABLE PART ADD PRIMARY KEY (P_PARTKEY);',

    'ALTER TABLE SUPPLIER ADD PRIMARY KEY (S_SUPPKEY);',
    'ALTER TABLE SUPPLIER ADD FOREIGN KEY (S_NATIONKEY) REFERENCES NATION;',

    'ALTER TABLE PARTSUPP ADD PRIMARY KEY (PS_PARTKEY,PS_SUPPKEY);',

    'ALTER TABLE CUSTOMER ADD PRIMARY KEY (C_CUSTKEY);',
    'ALTER TABLE CUSTOMER ADD FOREIGN KEY (C_NATIONKEY) REFERENCES NATION;',

    'ALTER TABLE LINEITEM ADD PRIMARY KEY (L_ORDERKEY,L_LINENUMBER);',

    'ALTER TABLE ORDERS ADD PRIMARY KEY (O_ORDERKEY);',

    'ALTER TABLE PARTSUPP ADD FOREIGN KEY (PS_SUPPKEY) REFERENCES SUPPLIER;',

    'ALTER TABLE PARTSUPP ADD FOREIGN KEY (PS_PARTKEY) REFERENCES PART;',

    'ALTER TABLE ORDERS ADD FOREIGN KEY (O_CUSTKEY) REFERENCES CUSTOMER;',

    'ALTER TABLE LINEITEM ADD FOREIGN KEY (L_ORDERKEY)  REFERENCES ORDERS;',

    'ALTER TABLE LINEITEM ADD FOREIGN KEY (L_PARTKEY,L_SUPPKEY) REFERENCES PARTSUPP;',
]

#-------------------------------------------------------------------------------
# Tasks

SH_KWARGS = dict(shell=True, check_retcode=True, print_output=True)

class SetupTask(object):
    MAKE_CMD = 'make'

    GCC_FLAGS_PGSQL = ('-O3 -DNDEBUG -mfpmath=sse -msse2 -march=native -mtune=native'
        ' -fomit-frame-pointer -fwrapv -fno-strict-aliasing -fno-stack-protector')

    # Define EOL_HANDLING to suppress final column separator
    # Do not use optimizations; dbgen is very fragile.  e.g. with 100 update sets:
    #    Program received signal SIGSEGV, Segmentation fault.
    #    dbg_print (format=3, target=0x0, data=0x3175, len=0, sep=1) at print.c:124
    #    124                     fprintf(target, HUGE_FORMAT, *(DSS_HUGE *)data);
    GCC_FLAGS_TPCH_DBGEN = ('-O0 -g3 -ggdb3 -DDBNAME=\"dss\" -D$(MACHINE) -D$(DATABASE)'
        ' -D$(WORKLOAD) -DRNG_TEST -D_FILE_OFFSET_BITS=64 -DEOL_HANDLING')

    @classmethod
    def main(cls, args):
        log.info('Running tools setup')
        log.debug('dbsetup args: %s', repr(args))
        tools_dir = os.path.abspath(args.tools_dir)

        temp_dir = tempfile.mkdtemp(prefix='asl-c2g2-')
        log.debug('temporary directory: "%s"', temp_dir)

        cpu = cpu_count()
        log.debug('Detected %d processors', cpu)
        if cpu > 1:
            cls.MAKE_CMD = '%s -j%d' % (cls.MAKE_CMD, cpu)

        if not args.only_dbgen:
            pgsql_dir = os.path.join(tools_dir, POSTGRESQL_BASE)
            log.debug('PostgreSQL installation directory: "%s"', pgsql_dir)
            if OS_WIN:
                if not os.path.isdir(pgsql_dir):
                    print 'Error: PostgreSQL not found'
                    print 'Download from "http://www.enterprisedb.com/products-services-training/pgbindownload"'
                    print 'and extract into the directory "%s"' % pgsql_dir
                    sys.exit(1)
            else:
                if not os.path.isdir(pgsql_dir):
                    cls.compile_postgresql(temp_dir, pgsql_dir)
                assert os.path.isdir(pgsql_dir)

        tpch_dir = os.path.join(tools_dir, TPCH_DBGEN_BASE)
        if not os.path.isdir(tpch_dir):
            cls.build_tpch_dbgen(temp_dir, tpch_dir)
        assert os.path.isdir(tpch_dir)

        shutil.rmtree(temp_dir)
        log.info('Tools setup complete')

    @classmethod
    def compile_postgresql(cls, temp_dir, pgsql_install_dir):
        log.info('Building PostgreSQL v%s', POSTGRESQL_VERSION)

        # Build readline
        rl_file = os.path.join(temp_dir, READLINE_FILE)
        download(READLINE_URL, rl_file, READLINE_SHA1)
        unpack_archive(rl_file, os.path.dirname(rl_file))
        rl_extract_dir = os.path.join(os.path.dirname(rl_file), READLINE_BASE)
        assert os.path.isdir(rl_extract_dir)

        rl_install_dir = '%s-install' % rl_extract_dir
        shell('./configure --prefix="%s"' % rl_install_dir,
              cwd=rl_extract_dir, **SH_KWARGS)
        shell(cls.MAKE_CMD, cwd=rl_extract_dir, **SH_KWARGS)
        shell('make install', cwd=rl_extract_dir, **SH_KWARGS)

        # Build PostgreSQL
        pgsql_file = os.path.join(temp_dir, POSTGRESQL_FILE)
        download(POSTGRESQL_URL, pgsql_file, POSTGRESQL_SHA1)
        unpack_archive(pgsql_file, os.path.dirname(pgsql_file))
        pgsql_extract_dir = os.path.join(os.path.dirname(pgsql_file), POSTGRESQL_BASE)
        assert os.path.isdir(pgsql_extract_dir)

        shell(
            './configure --prefix="%s" --with-includes="%s" --with-libraries="%s" '
            'CFLAGS="%s" CPPFLAGS="%s"' % (
                pgsql_install_dir,
                os.path.join(rl_install_dir, 'include'),
                os.path.join(rl_install_dir, 'lib'),
                cls.GCC_FLAGS_PGSQL,
                cls.GCC_FLAGS_PGSQL,
            ), cwd=pgsql_extract_dir, **SH_KWARGS)
        shell(cls.MAKE_CMD, cwd=pgsql_extract_dir, **SH_KWARGS)
        shell('make check', cwd=pgsql_extract_dir, **SH_KWARGS)

        if os.path.isdir(pgsql_install_dir):
            shutil.rmtree(pgsql_install_dir)
        makedirs(pgsql_install_dir)
        shell('make install', cwd=pgsql_extract_dir, **SH_KWARGS)

    @classmethod
    def build_tpch_dbgen(cls, temp_dir, install_dir):
        log.info('Building TPC-H dbgen (%s)', TPCH_DBGEN_BASE)

        tpch_file = os.path.join(temp_dir, TPCH_DBGEN_FILE)
        download(TPCH_DBGEN_URL, tpch_file, TPCH_DBGEN_SHA1)
        unpack_archive(tpch_file, os.path.dirname(tpch_file))
        tpch_extract_dir = os.path.join(os.path.dirname(tpch_file), TPCH_DBGEN_BASE)
        assert os.path.isdir(tpch_extract_dir)

        # Adapt Makefile
        RX_KEY_VALUE = re.compile(r'^(\w+)\s*=\s*(.*?)\s*$')
        MAKEFILE_KV = {
            'CC': 'gcc',
            'DATABASE': 'SQLSERVER',
            'WORKLOAD': 'TPCH',
            'CFLAGS': cls.GCC_FLAGS_TPCH_DBGEN,
            'LDFLAGS': '',  # CFLAGS suffices
        }
        if OS_WIN:
            MAKEFILE_KV['MACHINE'] = 'WIN32'
        else:
            MAKEFILE_KV['MACHINE'] = 'LINUX'

        f_in = open(os.path.join(tpch_extract_dir, 'makefile.suite'))
        f_out = open(os.path.join(tpch_extract_dir, 'Makefile'), 'w')
        try:
            for line in f_in:
                if MAKEFILE_KV:
                    match = RX_KEY_VALUE.match(line)
                    if match is not None:
                        k = match.group(1)
                        # ignore v = match.group(2)
                        try:
                            v = MAKEFILE_KV.pop(k)
                        except KeyError:
                            pass
                        else:
                            line = '%s = %s\n' % (k, v)
                f_out.write(line)
        finally:
            f_in.close()
            f_out.close()

        if OS_MAC:
            # https://bugs.eclipse.org/bugs/show_bug.cgi?id=276591
            #   "<malloc.h> is a non-standard library reference.
            #    The correct reference is <stdlib.h>"
            RX_MALLOC_H = re.compile(r'#include\s+<malloc\.h>')
            line_func = lambda line: RX_MALLOC_H.sub(r'#include <stdlib.h>', line)
            for fn in ['bm_utils.c', 'varsub.c']:
                fn = os.path.join(tpch_extract_dir, fn)
                modify_file(fn, line_func)

        if OS_WIN:
            # MinGW doesn't support Visual Studio's integer suffix
            fn = os.path.join(tpch_extract_dir, 'config.h')
            RX_INT_SUFFIX = re.compile(r'(\d+)[uU][iI]64')
            line_func = lambda line: RX_INT_SUFFIX.sub(r'\1ull', line)
            modify_file(fn, line_func)

        shell(cls.MAKE_CMD, cwd=tpch_extract_dir, **SH_KWARGS)

        if os.path.isdir(install_dir):
            shutil.rmtree(install_dir)
        shutil.move(tpch_extract_dir, os.path.dirname(install_dir))

class PostgreSQL(object):
    _BINARIES_CHECK = ['initdb', 'createdb', 'pg_ctl', 'psql']

    def __init__(self, path):
        self.root_path = path
        self.bin_path = os.path.join(path, 'bin')

        if not os.path.isdir(self.bin_path):
            raise Exception(
                'PostgreSQL directory %s does not exist' % path)
        for binary in self._BINARIES_CHECK:
            if not os.path.isfile(self.bin(binary)):
                raise Exception(
                    '%s is missing from PostgreSQL in directory %s' % (
                    binary, path))

    def bin(self, name):
        if OS_WIN:
            name = '%s.exe' % name
        return os.path.join(self.bin_path, name)

class InitDBTask(object):
    # http://informatik.unibas.ch/lehre/fs11/cs242/_Downloads/exercises/cs242-e6.pdf
    # http://dsl.serc.iisc.ernet.in/projects/PICASSO/picasso_download/doc/Installation/tpch.htm
    # http://www.fuzzy.cz/en/articles/dss-tpc-h-benchmark-with-postgresql/
    # http://pub.eigenbase.org/wiki/LucidDbTpch

    TABLES = [
      'customer',
      'lineitem',
      'nation',
      'orders',
      'part',
      'partsupp',
      'region',
      'supplier'
    ]

    HELP_DB_STRING = (
        'Databases to generate: <type>:<directory>\n'
        'where |type| is of the format: "replica" or "partition-1/5"\n'
        'and |directory| specifies the path to store the database'
    )

    RX_DB_STRING = re.compile(
        r"""^(
            (?P<type_replica>replica)|
            ((?P<type_partition>partition)
                \-(?P<partition_piece>\d+)\/(?P<partition_total>\d+))
         ):(?P<path>.+)$""",
        re.VERBOSE)

    JOB_REPLICA = object()
    JOB_PARTITION = object()

    @classmethod
    def main(cls, args):
        log.debug('initdb args: %s', repr(args))

        job_type, job_args, db_dir = cls._parse_db_string(args.databases)
        assert not os.path.isdir(db_dir)

        port = args.port
        dbname = args.dbname
        username = args.username
        password = args.password
        scale_factor = args.scale_factor
        assert scale_factor > 0
        tools_dir = os.path.abspath(args.tools_dir)
        assert os.path.isdir(tools_dir)

        log.info('Initializing TPC-H database with scale factor %f in directory "%s"',
                 scale_factor, db_dir)

        temp_dir = tempfile.mkdtemp(prefix='asl-c2g2-')
        log.debug('temporary directory: "%s"', temp_dir)

        # Generate data (TPC-H dbgen)
        tpch_dir = os.path.join(tools_dir, TPCH_DBGEN_BASE)
        temp_replica_data_dir = os.path.join(temp_dir, 'replica')
        table_data_map = cls._generate_tpch_data(
                temp_replica_data_dir, tpch_dir, scale_factor)

        # nothing additional needed for full replica
        if job_type is cls.JOB_PARTITION:
            piece, total = job_args
            temp_partition_data_dir = os.path.join(
                temp_dir, 'partition_%d_%d' % (piece + 1, total))
            table_data_map = cls._partition_data(
                piece, total, table_data_map, temp_partition_data_dir)

        # PostgreSQL: create database and populate with data
        pgsql = PostgreSQL(os.path.join(tools_dir, POSTGRESQL_BASE))
        log.info('Creating TPC-H database in directory "%s"', db_dir)

        # TODO: on Linux, even if we specify '-D' to initdb, PostgreSQL complains
        # ... perhaps this is a solution
        # default connection parameters (psql, createdb)
        if OS_WIN:
            # With this environment present, on Windows, we receive the following error:
            #   could not translate host name "localhost" to address: Unknown server error
            # Exact cause unknown, but at least this resolves the issue.
            # http://stackoverflow.com/questions/5019722/subprocess-popen-and-psql
            pgsql_env = None
        else:
            pgsql_env = {
                'PGDATABASE': dbname,
                'PGHOST': 'localhost',
                'PGPORT': str(port),
                'PGUSER': username,
                'PGDATA': db_dir,  # for initdb, pg_ctl
            }

        # Previously we would write data, flush [f.flush(); os.fsync(f.fileno())]
        # and only close (and implicitly delete) once the process has run.
        # Problem: as long as the file is open in Python, the external process
        # will be denied access (at least on Windows).
        pswd_file = tempfile.NamedTemporaryFile(prefix='pgsql-password-', delete=False)
        try:
            try:
                pswd_file.write('%s\n' % password)
            finally:
                pswd_file.close()

            raw_shell([
                pgsql.bin('initdb'),
                '--username=%s' % username,
                '--pwfile=%s' % pswd_file.name,
                '-D', db_dir
            ])
        finally:
            try:
                os.unlink(pswd_file.name)
            except:
                pass
        assert os.path.isdir(db_dir)

        # Configuration
        # - Main (postgresql.conf)
        # http://www.postgresql.org/docs/9.1/static/config-setting.html
        # (Rather than trying to parse this file, just append new config values
        # which take precedence due to appearing last.)
        #
        # Notes:
        # http://wiki.postgresql.org/wiki/Tuning_Your_PostgreSQL_Server
        # https://www.packtpub.com/article/server-configuration-tuning-postgresql
        # http://media.revsys.com/talks/djangocon/2011/secrets-of-postgresql-performance.pdf
        # http://pgmag.org/_media/00/issue-00.english.screen.72dpi.pdf
        # http://www.depesz.com/index.php/2011/05/06/understanding-postgresql-conf-log/
        #
        # Biplob K. Debnath, David J. Lilja, Mohamed F. Mokbel, "SARD: A statistical approach for ranking database tuning parameters," icdew, pp.11-18, 2008 IEEE 24th International Conference on Data Engineering Workshop, 2008
        # Biplob K. Debnath, Mohamed F. Mokbel, David J. Lilja, "Exploiting the Impact of Database System Configuration Parameters: A Design of Experiments Approach"
        #
        # Just append these to the end of the file rather than fiddling about with parsing
        #
        # Big 3:
        # - shared_buffers
        #   25% of RAM and move up/down 5% to ﬁnd sweet spot
        #   (Windows: useful range is 64MB to 512MB - using OS cache more may be more effective)
        # - effective_cache_size
        #   (Planning hint that tells PG how much RAM it can expect for OS disk cache.)
        #   50-75% of available RAM
        #   "On UNIX-like systems, add the free+cached numbers from free or top to get an estimate.
        #    On Windows see the "System Cache" size in the Windows Task Manager's Performance tab"
        # - work_mem
        #   Start with 5 MB (per process amount of ORDER BY space)
        #   See also: http://wiki.postgresql.org/wiki/Tuning_Your_PostgreSQL_Server#work_mem_maintainance_work_mem
        #
        # Others:
        # - wal_buffers
        #   set to 16MB and forget it (default = ~3% of shared_buffers, this is max value)
        # - checkpoint_segments
        #   increase to at least 10 (default = 3)
        #   checkpoint_completion_target = 0.9
        #   See also: http://wiki.postgresql.org/wiki/Tuning_Your_PostgreSQL_Server#checkpoint_segments_checkpoint_completion_target
        # - maintenance_work_mem > work_mem
        #   50MB for every GB of RAM
        # - synchronous_commit = off
        #   no risk of inconsistency, but transaction may abort during 600 ms interval
        # - separate out the WAL onto it’s own disk can 4x write performance
        # - Use pgbouncer to pool connections
        # - pgfouine (log analyzer)
        #   Possibly need to combine with log_min_duration = 1000 (Slow Query Log)
        #   See last page of: http://pgmag.org/_media/00/issue-00.english.screen.72dpi.pdf
        #
        # - max_connections
        #   default = 100 and we probably won't need more
        #   (but could reduce as it uses semaphores/shared memory!)
        # - default_statistics_target > 250 (link suggests ~400 - 500, PG9.1 allows even beyond 1000)
        #   http://archives.postgresql.org/pgsql-performance/2008-09/msg00157.php
        # - unix_socket_directory
        #   mentioned in ASL pgsql handout, but I don't think we need to tweak...
        # - unix_socket_permissions = 0700  # only user can connect
        # - max_prepared_transactions
        #   can set to 0 since we don't use two-phase commit
        #   note this does not relate to prepared statements - leave alone...
        # - constraint_exclusion = off (?)
        #   we partition across separate databases, so this may not help
        # - logging_collector/log_directory/log_filename/...
        # - deadlock_timeout >= typical transaction time
        # - restart_after_crash = true
        lines = [
            '\n# asl-c2g2 configuration',
            "listen_addresses = '*'",
            'port = %d' % port,
            # assume 4 GB of RAM
            'effective_cache_size = 2500MB',  # 62.5% of RAM
            'work_mem = 5MB',  # be careful if lots of connections (!)
            'checkpoint_segments = 10',
            'checkpoint_completion_target = 0.9',
            # important for good planning with TPC-H
            'default_statistics_target = 750',
            # - deadlock_timeout >= typical transaction time
            'deadlock_timeout = 15s',
            'restart_after_crash = true',
            # disabled by default, but critical for XA (two-phase commit)
            'max_prepared_transactions = 100',

            ## Logging
            # default log_destination (stderr)
            'logging_collector = on',  # old name for 'redirect_stderr'
            "log_directory = 'pg_log'",
            "log_filename = 'postgresql-%Y%m%d-%H%M%S.log'",
            'log_rotation_age = 0',
            'log_rotation_size = 0',
            'log_min_duration_statement = 0',  # all statements together with timing
            'log_duration = off',
            "log_statement = 'none'",
            "log_line_prefix = '[time=%m][remote=%r][session=%c][transaction=%x][line=%l]: '",
           #"log_lock_waits = 'on'",
        ]

        # The maximum shared memory segment size (SHMMAX) is very small on the
        # cluster machines:
        #   $ sysctl -a | grep shmmax
        #   kernel.shmmax = 33554432
        # Here we have to stick with the defaults (shared_buffers = 24MB,
        # wal_buffers based on shared_buffers)
        if not ETHZ_CLUSTER:
            # On Windows, larger OS cache tends to be more effective
            shared_buffers = '512MB' if OS_WIN else '1GB'
            lines.append('shared_buffers = %s' % shared_buffers)
            lines.append('wal_buffers = 16MB')

        if OS_POSIX:
            # only user can connect
            lines.append('unix_socket_permissions = 0700')

        f = open(os.path.join(db_dir, 'postgresql.conf'), 'a')
        try:
            f.write('\n'.join(lines))
        finally:
            f.close()

        # - Authentication (pg_hba.conf)
        fn = os.path.join(db_dir, 'pg_hba.conf')
        f = open(fn, 'a')
        try:
            f.write(PG_HBA_CONF_ETHZ)
        finally:
            f.close()

        # When run from the console this process returns fairly quickly.
        # With shell(...) however, this call will block waiting indefinitely.
        # Perhaps this is due to several long-running sub-processes being
        # launched.
        #
        # On Windows, ignore log message 'FATAL: role "..." does not exist'
        # http://archives.postgresql.org/pgsql-bugs/2007-01/msg00033.php
        shell_cmd = [
            pgsql.bin('pg_ctl'),
            '-D', db_dir,
            '-l', os.path.join(db_dir, 'postgresql.log'),
            '-w',  # block until the postmaster comes up
            'start'
        ]
        _shell_log(shell_cmd, db_dir)
        subprocess.Popen(
            shell_cmd,
            cwd=db_dir,
            env=pgsql_env,
            stdout=open(os.path.join(db_dir, 'pg_ctl_start.log'), 'w'),
            stderr=subprocess.STDOUT,
            bufsize=-1,  # fully buffered
            universal_newlines=True,
        )
        time.sleep(10)

        # TODO: cleanup superuser and non-priveleged command execution
        raw_shell([
            pgsql.bin('createdb'),
            '-U', username,
            '-h', 'localhost',
            '-p', str(port),
            # TODO: needed for portability, but why do we get this error (on Windows):
            #   "invalid locale name en_US.utf8"
           #'--encoding=utf8',
           #'--locale=en_US.utf8',
            dbname
        ])
        time.sleep(2)  # TODO: is this necessary?

        # TODO: create new role (asl-c2g2 ...) and grant permissions
        # ... not needed since we just use superuser directly
        # (normal users cannot use COPY from file - psql '\f' works though
        #  and VACUUM seemed to give errors...)
        """
        sql_cmds = [
            "CREATE USER %s PASSWORD '%s';" % (username, password),
            "GRANT ALL PRIVILEGES ON DATABASE %s TO %s;" % (dbname, username),
        ]
        for sql_cmd in sql_cmds:
            raw_shell([
                pgsql.bin('psql'),
                '-U', username,
                '-h', 'localhost',
                '-p', str(port),
                '-d', 'postgres',
                '-c', sql_cmd,
                '-w',  # never issue a password prompt
            ])
            time.sleep(2)  # TODO: is this necessary?
        """

        log.info('Created database "%s"; importing schema', dbname)
        def psql(command=None, filename=None):
            if (command is None) == (filename is None):
                raise Exception(
                    'Only one of the arguments should be provided')

            shell_cmd = [
                pgsql.bin('psql'),
                '-U', username,
                '-h', 'localhost',
                '-p', str(port),
                '-d', dbname,
                '-w',  # never issue a password prompt
            ]
            if command is not None:
                shell_cmd.extend(['-c', str(command)])
            if filename is not None:
                shell_cmd.extend(['-f', str(filename)])

            return raw_shell(shell_cmd)
           #return shell(shell_cmd, cwd=db_dir, env=pgsql_env, **SH_KWARGS)

        # Database schema
        psql(filename=os.path.join(tpch_dir, 'dss.ddl'))
        time.sleep(2)

        log.info('Populating database with data')
        for tbl_name in cls.TABLES:
            tbl_fn = table_data_map[tbl_name]
            psql(command="COPY %s FROM '%s' WITH DELIMITER '|';" % (
                    tbl_name, tbl_fn))
            time.sleep(2)

        log.info('Setting table constraints and creating indices')
        # Table constraints (modified from TPC-H dbgen 'dss.ri')
        for sql_cmd in SQL_TABLE_CONSTRAINTS:
            psql(command=sql_cmd)
        time.sleep(2)

        # Defining a primary key will implicitly create a unique index
        # http://www.postgresql.org/docs/9.1/static/indexes-unique.html
        #
        # We don't index too many fields as maintaining these on updates
        # may hurt performance.
        # TODO: Check which fields would be beneficial to index for our workload:
        #   RF1 +    Q1   + RF2
        # or
        #   RF1 + 22 * Q1 + RF2
        """
        for tbl_name in cls.TABLES:
            psql(command="CREATE INDEX %s_IDX ON %s(%s);" % (
                    key_name, tbl_name, key_name))
            time.sleep(2)
        """

        # Examines every table in the current database by default
        psql(command='VACUUM ANALYZE')
        time.sleep(2)

        raw_shell([
            pgsql.bin('pg_ctl'),
            '-D', db_dir,
            'stop'
        ])

        shutil.rmtree(temp_dir)
        log.info('Database created successfully')

    @classmethod
    def _parse_db_string(cls, db_string):
        # Converts string conforming to HELP_DB_STRING into
        # (job_type, job_args, path)
        match = cls.RX_DB_STRING.match(db_string)
        if match is None:
            print 'Error: Unrecognized database argument "%s"' % db_string
            print 'Expected argument as follows:'
            print textwrap.fill(cls.HELP_DB_STRING)
            sys.exit(1)

        match_info = match.groupdict()
        path = os.path.abspath(match_info['path'])
        if match_info.get('type_replica', None):
            return (cls.JOB_REPLICA, None, path)
        elif match_info.get('type_partition', None):
            piece = int(match_info['partition_piece']) - 1
            total = int(match_info['partition_total'])
            assert piece in xrange(total)
            return (cls.JOB_PARTITION, (piece, total), path)
        else:
            raise Exception('unreachable')

    @classmethod
    def _generate_tpch_data(cls, temp_data_dir, tpch_dir, scale_factor):
        # Returns dict mapping table name to data path

        # On Linux, the '-b' flag doesn't seem to have an effect, so we specify
        # the directory to store flat files via the environment (README section 13).
        #
        # Note: dbgen occasionally fails on Linux with:
        #   *** invalid open64 call: O_CREAT without mode ***
        # (e.g.  http://sourceforge.net/tracker/index.php?func=detail&aid=3369465&group_id=52479&atid=466997)
        # For this reason, we retry several times until success.
        MAX_ATTEMPTS = 5
        successful = False
        for attempt in xrange(MAX_ATTEMPTS):
            try:
                makedirs(temp_data_dir)
                env = {'DSS_PATH': temp_data_dir}

                raw_shell([
                    os.path.join(tpch_dir, 'dbgen'),
                    '-v', '-f',
                    '-s', str(scale_factor),
                   #'-b', os.path.join(tpch_dir, 'dists.dss')
                ], cwd=tpch_dir, env=env)
            except subprocess.CalledProcessError:
                shutil.rmtree(temp_data_dir)
            else:
                successful = True
                break  # successfully generated data

        if not successful:
            log.error('Failed to generate data after %d attempts', MAX_ATTEMPTS)
            sys.exit(1)

        table_data_map = {}
        for tbl_name in cls.TABLES:
            tbl_fn = os.path.join(temp_data_dir, '%s.tbl' % tbl_name)
            assert os.path.isfile(tbl_fn)

            # dbgen occassionally sets odd permissions, causing 'permission denied' errors:
            #   ---x--S--T 1 zchothia fuse 2.3M 2011-11-12 01:16 customer.tbl*
            os.chmod(tbl_fn, 0777)

            table_data_map[tbl_name] = tbl_fn

        # Fix trailing delimiter ('|')
        # ... no longer needed due to dbgen configuration (see GCC_FLAGS_TPCH_DBGEN)
        if False:
            log.debug('Removing trailing pipe from table files')
            RX_TRAILING_PIPE = re.compile(r'\|?$')
            line_func = lambda line: RX_TRAILING_PIPE.sub('', line)
            for tbl_name in cls.TABLES:
                fn = os.path.join(temp_data_dir, '%s.tbl' % tbl_name)
                modify_file(fn, line_func)

        return table_data_map

    @classmethod
    def _partition_data(cls, desired_partno, num_partitions, in_table_data_map, output_data_dir):
        makedirs(output_data_dir)

        out_table_data_map = in_table_data_map.copy()

        def _helper(tbl, partfunc, args=None, kwargs=None):
            # 'partfunc' is passed each tuple of the table (and any additional arguments)
            # It should return the primary key and partition number
            if args is None:
                args = ()
            if kwargs is None:
                kwargs = {}

            fn_in = in_table_data_map[tbl]
            fn_out = os.path.join(output_data_dir, os.path.basename(fn_in))
            out_table_data_map[tbl] = fn_out

            f_in = open(fn_in)
            f_out = open(fn_out, 'w')
            partmap = {}
            try:
                for line in f_in:
                    data = line.split('|')
                    key, partno = partfunc(data, *args, **kwargs)
                    assert partno in xrange(num_partitions)
                    if partno == desired_partno:
                        f_out.write(line)
                    partmap[key] = partno
            finally:
                f_in.close()
                f_out.close()
            assert all(v in xrange(num_partitions) for v in partmap.itervalues())
            return partmap

        """
        TPC-H Specification (2.14.2), section 1.2
        Relevant portion of database schema

        CUSTOMER
          [0]: C_CUSTKEY INTEGER NOT NULL
          ...
        ORDERS
          [0]: O_ORDERKEY INTEGER NOT NULL
          [1]: O_CUSTKEY INTEGER NOT NULL
          ...
        LINEITEM
          [0]: L_ORDERKEY INTEGER NOT NULL
          [1]: L_PARTKEY INTEGER NOT NULL
          [2]: L_SUPPKEY INTEGER NOT NULL
          [3]: L_LINENUMBER INTEGER NOT NULL
          ...
        """

        def partition_customer(custdata):
            custkey = int(custdata[0])
            # round-robin assignment to partitions
            # (to aid load-balancing across each partition)
            partno = custkey % num_partitions
            return custkey, partno

        def partition_order(orddata, custmap):
            ordkey = int(orddata[0])
            custkey = int(orddata[1])
            partno = custmap[custkey]
            return ordkey, partno

        def partition_lineitem(lidata, ordmap):
            ordkey = int(lidata[0])
            linenum = int(lidata[3])
            partno = ordmap[ordkey]
            likey = (ordkey, linenum)
            return likey, partno

        # partition each table
        custmap = _helper(
                'customer',
                partition_customer)

        ordmap = _helper(
                'orders',
                partition_order,
                args=[custmap])

        limap = _helper(
                'lineitem',
                partition_lineitem,
                args=[ordmap])

        # print basic statistics
        def count_per_partition(partmap):
            counter = dict()
            for i in xrange(num_partitions):
                counter[i] = 0
            for partno in partmap.itervalues():
                counter[partno] += 1
            return counter

        def no_empty_partitions(counter):
            return all(v > 0 for v in counter.itervalues())

        custcount = count_per_partition(custmap)
        ordcount = count_per_partition(ordmap)
        licount = count_per_partition(limap)

        logging.info(
            'Partition counts:\n'
            '- CUSTOMER: %s\n'
            '- ORDERS: %s\n'
            '- LINEITEM: %s',
            repr(custcount), repr(ordcount), repr(licount)
        )

        assert no_empty_partitions(custcount), 'empty CUSTOMER partition'
        assert no_empty_partitions(ordcount), 'empty ORDERS partition'
        assert no_empty_partitions(licount), 'empty LINEITEM partition'

        return out_table_data_map

class WorkloadTask(object):
    @classmethod
    def main(cls, args):
        log.debug('workload args: %s', repr(args))

        tpch_dir = os.path.join(args.tools_dir, TPCH_DBGEN_BASE)
        assert os.path.isdir(tpch_dir)
        scale_factor = args.scale_factor
        assert scale_factor > 0
        update_sets = args.update_sets
        output_dir = makedirs(os.path.abspath(args.output_dir))

        # See InitDBTask._generate_tpch_data
        MAX_ATTEMPTS = 5
        successful = False
        for attempt in xrange(MAX_ATTEMPTS):
            try:
                makedirs(output_dir)
                env = {'DSS_PATH': output_dir}

                raw_shell([
                    os.path.join(tpch_dir, 'dbgen'),
                    '-v', '-f',
                    '-s', str(scale_factor),
                    '-U', str(update_sets),
                   #'-b', os.path.join(tpch_dir, 'dists.dss')
                ], cwd=tpch_dir, env=env)
            except subprocess.CalledProcessError:
                shutil.rmtree(output_dir)
            else:
                successful = True
                break  # successfully generated data

        if not successful:
            log.error('Failed to generate data after %d attempts', MAX_ATTEMPTS)
            sys.exit(1)

        # Modification: RF2 (delete) should undo the changes from RF1 (insert)
        for i in xrange(1, update_sets + 1):
            orders_fn = os.path.join(output_dir, 'orders.tbl.u%d' % i)
            delete_fn = os.path.join(output_dir, 'delete.%d' % i)
            orders_f = open(orders_fn, 'r')
            try:
                delete_f = open(delete_fn, 'w')
                try:
                    for line in orders_f:
                        ordkey, _ = line.split('|', 1)
                        delete_f.write(ordkey + '\n')
                finally:
                    delete_f.close()
            finally:
                orders_f.close()

        log.info('Generated workload with %d sets: %s', update_sets, output_dir)

#-------------------------------------------------------------------------------

def setup_logging(verbose, logfn=None):
    if logfn is None:
        logfn = '%s-%s.log' % (
            os.path.splitext(SCRIPT_NAME)[0],
            datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
        logfn = os.path.join(SCRIPT_DIR, 'logs', logfn)

    log.setLevel(logging.DEBUG)

    LOG_FMT = '[%(asctime)s][%(levelname)s] %(message)s'
    fmt = logging.Formatter(LOG_FMT)

    console_hdlr = logging.StreamHandler()
    if verbose:
        console_hdlr.setLevel(logging.DEBUG)
    else:
        console_hdlr.setLevel(logging.INFO)
    console_hdlr.setFormatter(fmt)
    log.addHandler(console_hdlr)

    logfn = os.path.abspath(logfn)
    makedirs(os.path.dirname(logfn))

    file_hdlr = logging.FileHandler(logfn)
    file_hdlr.setLevel(logging.DEBUG)
    file_hdlr.setFormatter(fmt)
    log.addHandler(file_hdlr)

def setup_argparse():
    # Handle subcommands and arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-v', '--verbose', dest='verbose',
        action='store_true', default=False,
        help='Enable debug logging'
    )
    parser.add_argument(
        '--log', dest='logfile',
        action='store', default=None,
        help='Path for log file'
    )
    parser.add_argument(
        '--debugger', dest='debugger',
        action='store_true', default=False,
        help='Start debugger'
    )

    subparsers = parser.add_subparsers()

    parser_setup = subparsers.add_parser('setup')
    parser_setup.set_defaults(func=SetupTask.main)
    parser_setup.add_argument(
        '--only-dbgen', dest='only_dbgen',
        action='store_true', default=False,
        help='Only setup TPC-H dbgen'
    )
    parser_setup.add_argument(
        'tools_dir',
        default=TOOLS_DIR, nargs='?',
        help='Path to install tools (default: %s)' % TOOLS_DIR
    )

    parser_initdb = subparsers.add_parser('initdb')
    parser_initdb.set_defaults(func=InitDBTask.main)
    parser_initdb.add_argument(
        '--tools-dir', dest='tools_dir',
        default=TOOLS_DIR,
        help='Path where tools are located (default: %s)' % TOOLS_DIR
    )
    parser_initdb.add_argument(
        '-s', '--scale-factor', dest='scale_factor',
        default=TPCH_DBGEN_SCALE_FACTOR, type=float,
        help='Scale factor (default: %f)' % TPCH_DBGEN_SCALE_FACTOR
    )
    parser_initdb.add_argument(
        '--port',
        default=TPCH_DB_PORT, type=int,
        help='Listening port (default: %d)' % TPCH_DB_PORT
    )
    parser_initdb.add_argument(
        '--database-name',
        dest='dbname',
        default=TPCH_DB_NAME,
        help='Database name (default: %s)' % TPCH_DB_NAME
    )
    parser_initdb.add_argument(
        '--username',
        default=TPCH_DB_USER,
        help='Username (default: %s)' % TPCH_DB_USER
    )
    parser_initdb.add_argument(
        '--password',
        default=TPCH_DB_PSWD,
        help='Password (default: %s)' % TPCH_DB_PSWD
    )
    parser_initdb.add_argument(
        'databases',
        # TODO: add support for multiple databases with single invocation
       #nargs='+',
        help=InitDBTask.HELP_DB_STRING
    )

    # Update workload
    parser_workoad = subparsers.add_parser('workload')
    parser_workoad.set_defaults(func=WorkloadTask.main)
    parser_workoad.add_argument(
        '--tools-dir', dest='tools_dir',
        default=TOOLS_DIR,
        help='Path where tools are located (default: %s)' % TOOLS_DIR
    )
    parser_workoad.add_argument(
        '-s', '--scale-factor', dest='scale_factor',
        default=TPCH_DBGEN_SCALE_FACTOR, type=float,
        help='Scale factor (default: %f)' % TPCH_DBGEN_SCALE_FACTOR
    )
    parser_workoad.add_argument(
        'update_sets',
        type=int,
        help='Number of update sets'
    )
    parser_workoad.add_argument(
        'output_dir',
        help='Output directory for data'
    )

    return parser

def main():
    parser = setup_argparse()
    args = parser.parse_args()

    setup_logging(args.verbose, args.logfile)

    try:
        if args.debugger:
            sys.stderr.write(
                'entering debugger - type c to continue starting %s '
                'or h for help\n' % SCRIPT_NAME)
            pdb.set_trace()

        logging.debug('%s New invocation of %s %s', '-'*30, SCRIPT_NAME, '-'*30)
        logging.debug('Command-line arguments: %s', repr(sys.argv))
        args.func(args)
    except SystemExit:
        raise
    except:
        if args.debugger:
            traceback.print_exc()
            pdb.post_mortem(sys.exc_info()[2])
        log.exception(
            '** An unexpected error occurred - details follow:\n'
            '** Python %s' % sys.version.replace('\n', ''))
        raise

if __name__ == "__main__":
    main()
