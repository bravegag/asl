#!/usr/bin/env python
# encoding: utf-8

"""
Advanced Systems Lab (Fall 2011)
Class 2, Group 2:
    Giovanni Azua Garcia
    Zaheer Chothia

Experiment automation script
"""

# References
# ==========
# paramiko/ssh
# - bitprophet/ssh - GitHub (fork of parmiko with fixes for fabric)
#     https://github.com/bitprophet/ssh
#   robey/paramiko - GitHub
#     https://github.com/robey/paramiko
# - API documentation
#   http://www.lag.net/paramiko/docs/
# - Demos
#   https://github.com/bitprophet/ssh/tree/master/demos
# - Exit code from shell
#   http://stackoverflow.com/questions/5342402/can-i-get-the-exit-code-of-a-command-executed-in-a-subshell-via-ssh
#
# fabric
# - fabfile.org: Parallel execution
#     http://docs.fabfile.org/en/1.3.1/usage/parallel.html
# - #275: Consider forking Paramiko - Issues - fabric/fabric - GitHub
#     https://github.com/fabric/fabric/issues/275
# - Pull request 'olt/shell-env' from vijaykramesh/fabric - GitHub
#     https://github.com/vijaykramesh/fabric/commit/6cf444d56a352dab543475d0e7eeaa0b67b87733
# - Fabric Python with Cleaner API and Parallel Deployment
#     http://tav.espians.com/fabric-python-with-cleaner-api-and-parallel-deployment-support.html
#
# multiprocessing
# - logging
#   http://plumberjack.blogspot.com/2010/09/using-logging-with-multiprocessing.html
#   http://stackoverflow.com/questions/641420/how-should-i-log-while-using-multiprocessing-in-python/3253442#3253442
# - map/exceptions/finally/SIGTERM
#   http://stackoverflow.com/questions/7700929/python-multiprocessing-map-if-one-thread-raises-an-exception-why-arent-other
# - KeyboardInterrupt
#   http://www.bryceboe.com/2010/08/26/python-multiprocessing-and-keyboardinterrupt/

from __future__ import with_statement

import os

SCRIPT_DIR, SCRIPT_NAME = os.path.split(os.path.abspath(__file__))

# Activate virtualenv (if present)
try:
    import virtualenv
except ImportError:
    pass
else:
    VENV_BASE_PATH = os.path.join(SCRIPT_DIR, 'venv')
    _, _, _, VENV_BIN_DIR = virtualenv.path_locations(VENV_BASE_PATH)
    VENV_ACTIVATE = os.path.join(VENV_BIN_DIR, 'activate_this.py')
    if os.path.isfile(VENV_ACTIVATE):
        execfile(VENV_ACTIVATE, dict(__file__=VENV_ACTIVATE))

# Continue loading modules as usual

import datetime
import errno
import itertools
import logging
import multiprocessing
import operator
import posixpath
import pprint
import subprocess
import sys
import textwrap
import threading
import time
import traceback

from collections import OrderedDict
from contextlib import closing, contextmanager

try:
    import cPickle as pickle
except ImportError:
    import pickle

try:
    import argparse
except ImportError:
    import argparse_local as argparse

try:
    import ssh as sshlib
except ImportError:
    # Don't even fallback to 'paramiko'
    # https://github.com/fabric/fabric/issues/275
    print >> sys.stderr, (
            '** ssh module not found **\n'
            'Download and install from: https://github.com/bitprophet/ssh\n')
    raise

from manage import (atomictempfile, enum, makedirs, ETHZ_CLUSTER, TPCH_DB_NAME,
    TPCH_DB_PORT)

#-------------------------------------------------------------------------------
## Configuration
#
# Warning: it is imperative that the following are constants and are only
# initialized at module scope.  Global variables and multiprocessing are not
# a good combination [!]

ASL_DIR = '/local/asl11/c2g2'
MIDDLEWARE_BASE_PORT = 22100

EXPERIMENT_DURATION = 30  # (minutes)
MW_EXTRA_DURATION = 2

# Repetitions should be the outer-most for-loop so that we can analyze a full
# dataset and determine any anomalies early.
EXPERIMENT_REPETITIONS = 3

# Used for 2^k experiment.
#
# Ordering is important so we vary the most important parameters first.
# The recursion (Experiment2K) fixes the first parameter and runs 2**(k-1)
# experiments before changing the level.  Thus the last parameter will vary most
# frequently (every experiment).
EXPERIMENT_PARAMETERS = OrderedDict([
    # parameter -> levels
    ('NUMBER_OF_DATABASES', [4, 1]),
    ('NUMBER_OF_MIDDLEWARE', [4, 2, 1]),
    ('PARTITIONING_MODE', ['SHARDING', 'REPLICATION']),
    ('MIDDLEWARE_QUEUE_SIZE', [100, 40]),
])

# If defined, experiments will only be run during this period.
SLOT_START = datetime.datetime(2011, 11, 14, 01, 05, 00)
SLOT_END = datetime.datetime(2011, 11, 14, 6, 55, 00)
#SLOT_START, SLOT_END  = None, None

DEFAULT_CONFIGURATION = {
    # Experiment parameters
    # All 'None' values must be filled out before execution.
    'SCALE_FACTOR': '0.1',

    # - database: single instance on each
    'DATABASE_HOSTS': ['ikr01.ethz.ch', 'ikr02.ethz.ch', 'ikr03.ethz.ch', 'ikr05.ethz.ch'],
    'NUMBER_OF_DATABASES': None,  # at least this many DATABASE_HOSTS must be specified

    'PARTITIONING_MODE': None,
   #'PARTITIONING_MODE': 'SHARDING',
   #'PARTITIONING_MODE': 'REPLICATION',

    # - middleware
    'MIDDLEWARE_HOSTS': ['ikr07.ethz.ch', 'ikr09.ethz.ch'],
    'NUMBER_OF_MIDDLEWARE': None,
    'MIDDLEWARE_PER_HOST': 2,

    'DB_CONNECTION_POOL_SIZE': 4,
    'MIDDLEWARE_QUEUE_SIZE': None,
    'MIDDLEWARE_DISPATCHER_THREADS': 10,

    # - clients
    'CLIENT_HOSTS': ['ikr10.ethz.ch', 'ikr11.ethz.ch'],
    'NUMBER_OF_CLIENTS': None,
    'CLIENTS_PER_HOST': 32,

    # Internal parameters (set by main/RunExperiment)
    'TIMESTAMP': None,  # used for file paths - be careful which alphabet are used
    'LOCAL_LOG_DIR': None,
    'EXPERIMENT_DIR': None,
    'EXPERIMENT_LOGS_DIR': None,
    'LOGGING_QUEUE': None,
}

OPTIMAL_CONFIGURATION = {
    'NUMBER_OF_DATABASES': 4,
    'NUMBER_OF_MIDDLEWARE': 2,
    'NUMBER_OF_CLIENTS': 64,
    'PARTITIONING_MODE': 'SHARDING',
    'MIDDLEWARE_QUEUE_SIZE': 100,
}

# Parameters are filled in prior to execution (see *Worker)
MIDDLEWARE_CMDLINE_TEMPLATE = ' '.join([
    'java',
    '-Xms1024m',
    '-Xmx1024m',
    '-Did=%(id)d',
    '-Dtimeout=%(timeout)d',
    '-Dlistening_port=%(port)d',
    '-Ddatabase_username=asl_c2g2',
    '-Ddatabase_password=matterhorn',
    '-Ddatabase_url="%(database_url)s"',
    '-Ddatabase_connection_pool_size=%(database_connection_pool_size)d',
    '-Ddatabase_max_cached_statements=50',
    '-Dpartitioning_mode=%(partitioning_mode)s',
    '-Dnumber_of_dispatcher_threads=%(number_of_dispatcher_threads)d',
    '-Ddispatcher_policy=RANDOM',
    '-Djob_queue_capacity=%(job_queue_capacity)d',
    '-Dlog_directory=%(log_directory)s',
    '-Dtransaction_timeout=60',
    '-jar',
    '%(jar_path)s',
])

CLIENT_CMDLINE_TEMPLATE = ' '.join([
    'java',
    '-Xmx32m',
    '-Xmx64m',
    '-Did=%(id)d',
    '-Dtimeout=%(timeout)d',
    '-Dservers="%(servers)s"',
    '-Dworkload_data_path=%(workload_data_path)s',
    '-Dlog_directory=%(log_directory)s',
    '-jar',
    '%(jar_path)s',
])

# Paths to resources (assumes this script is located in 'trunk/scripts')
CODE_DIR = os.path.dirname(SCRIPT_DIR)
assert os.path.isfile(os.path.join(CODE_DIR, 'pom.xml')), (
    'Expected code (Maven pom.xml) in directory "%s"' % CODE_DIR)

MANAGE_PY_LOCAL = os.path.join(SCRIPT_DIR, 'manage.py')
assert os.path.isfile(MANAGE_PY_LOCAL)

ARGPARSE_PY_LOCAL = os.path.join(SCRIPT_DIR, 'argparse_local.py')
assert os.path.isfile(ARGPARSE_PY_LOCAL)

# - Maven build output (expected in 'target' directory)
CLIENT_JAR_FILENAME = 'client-MILESTONE-2.0-SNAPSHOT-jar-with-dependencies.jar'
MIDDLEWARE_JAR_FILENAME = 'middleware-MILESTONE-2.0-SNAPSHOT-jar-with-dependencies.jar'

# SSH parameters
SSH_KNOWN_HOSTS = os.path.join(SCRIPT_DIR, 'sshkey', 'ethz-ikr-ssh-host-keys')
SSH_PRIVATE_KEY = os.path.join(SCRIPT_DIR, 'sshkey', 'sshkey-zchothia-asl11-c2g2.openssh.private')
SSH_USERNAME = 'zchothia'
assert os.path.isfile(SSH_KNOWN_HOSTS)
assert os.path.isfile(SSH_PRIVATE_KEY)

#-------------------------------------------------------------------------------
## General utilities

def Indent(text, spaces=2, strip=False):
    # fabric.utils.Indent
    if not hasattr(text, 'splitlines'):
        text = '\n'.join(text)
    if strip:
        text = textwrap.dedent(text)
    prefix = ' ' * spaces
    output = '\n'.join(prefix + line for line in text.splitlines())
    output = output.strip()
    output = prefix + output
    return output

def BlockedIterator(iterable, block_size):
    # Iterator that returns elements from the iterable in blocks of fixed size.
    # Note the last block may be shorter if the iterable is exhausted early.
    #
    # Example:
    #   >>> list(BlockedIterator(range(10), 4))
    #   [(0, 1, 2, 3), (4, 5, 6, 7), (8, 9)]
    it = iter(iterable)
    stop = False
    while not stop:
        block = []
        try:
            for _ in xrange(block_size):
                block.append(it.next())
        except StopIteration:
            stop = True
        if block:
            yield tuple(block)

def timedelta_total_seconds(td):
    # Fallback for datetime.timedelta.total_seconds (Py < 2.7)
    func = getattr(td, 'total_seconds', None)
    if func is None:
        return (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10**6) / 10**6
    else:
        return func()

#-------------------------------------------------------------------------------
## Logging

class QueueHandler(logging.Handler):
    """
    This is a logging handler which sends events to a multiprocessing queue.
    """

    def __init__(self, queue):
        """
        Initialise an instance, using the passed queue.
        """
        logging.Handler.__init__(self)
        self.queue = queue

    def emit(self, record):
        """
        Emit a record.

        Writes the LogRecord to the queue.
        """
        try:
            # Can't pass exc_info across processes so just format now.
            # (Uses same solution from logging.SocketHandler.makePickle)
            ei = record.exc_info
            if ei:
                dummy = self.format(record) # just to get traceback text into record.exc_text
                record.exc_info = None  # not needed any more
            # If this has an adverse effect on performance, use 'put_nowait' instead.
            self.queue.put(record)
        except (KeyboardInterrupt, SystemExit):
            raise
        except:
            self.handleError(record)

def LoggingListener(queue):
    # This is the event loop for the logging proxy, which handles logging
    # events (LogRecords) from subprocesses.
    ConfigureLoggingListener()
    while True:
        try:
            record = queue.get()
            if record is None:
                # sentinel from main thread, indicating the listener should quit
                break
            logger = logging.getLogger(record.name)
            logger.handle(record)
        except (KeyboardInterrupt, SystemExit):
            raise
        except:
            print >> sys.stderr, (
                '** An unexpected error occurred (LoggingListener) - details follow:\n')
            traceback.print_exc(file=sys.stderr)

LOG_FILE_FORMAT_STR = '[%(asctime)s] [%(levelname)-8s] [%(name)s] %(message)s'
LOG_CONSOLE_FORMAT_STR = '[%(asctime)s] [%(levelname)-8s] [%(processName)s] [%(name)s] %(message)s'

def _AddFileHandler(root, filename, *args, **kwargs):
    file_hdlr = logging.FileHandler(filename, *args, **kwargs)
    file_hdlr.setFormatter(logging.Formatter(LOG_FILE_FORMAT_STR))
    file_hdlr.setLevel(logging.DEBUG)
    root.addHandler(file_hdlr)
    return file_hdlr

def _ConfigureLogging(name, config):
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    # subprocesses may inherit logging configuration from their parent process
    # via fork().  Remove all handlers to prevent, for example, multiple processes
    # sharing the same file.
    root.handlers = []

    log_fn = os.path.join(config['LOCAL_LOG_DIR'], '%s.log' % name)
    _AddFileHandler(root, log_fn)

    queue_hdlr = QueueHandler(config['LOGGING_QUEUE'])
    root.addHandler(queue_hdlr)

def ConfigureMainLogging():
    #multiprocessing.log_to_stderr()

    # Setup logging listener
    logging_queue = multiprocessing.Queue()
    logging_listener = multiprocessing.Process(
            target=LoggingListener, args=(logging_queue,))
    logging_listener.start()

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    # temporary log
    # File handler is setup in ConfigureExperimentLogging
    log_fn = '%s.log' % os.path.splitext(__file__)[0]
    file_hdlr = _AddFileHandler(root, log_fn, mode='w')
    global main_logging_file_hdlr
    main_logging_file_hdlr = file_hdlr

    queue_hdlr = QueueHandler(logging_queue)
    root.addHandler(queue_hdlr)

    return logging_queue, logging_listener

# This global variable is permissible, since it is only used from the main process.
main_logging_file_hdlr = None

def ConfigureExperimentLogging(config):
    global main_logging_file_hdlr

    root = logging.getLogger()
    if main_logging_file_hdlr is not None:
        root.removeHandler(main_logging_file_hdlr)

    log_fn = os.path.join(
        config['LOCAL_LOG_DIR'],
        'experiment-%s.log' % config['TIMESTAMP'])
    file_hdlr = _AddFileHandler(root, log_fn)

    main_logging_file_hdlr = file_hdlr

def ConfigureLoggingListener():
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.handlers = []  # see _ConfigureLogging()

    console_hdlr = logging.StreamHandler()
    console_hdlr.setFormatter(logging.Formatter(LOG_CONSOLE_FORMAT_STR))
    console_hdlr.setLevel(logging.INFO)
    root.addHandler(console_hdlr)

def ConfigureLoggingSubprocess(config):
    name = multiprocessing.current_process().name
    _ConfigureLogging(name, config)

#-------------------------------------------------------------------------------
## SSH Utilities (execute, download, upload)

def _ShellEscape(string):
    # See fabric.operations._shell_escape
    for char in ('"', '$', '`'):
        string = string.replace(char, '\%s' % char)
    return string

def _OutputReader(pipe, buf, name):
    LOG = logging.getLogger('_OutputReader-%s' % name)
    for line in iter(pipe.readline, ''):
        buf.append(line)
        LOG.debug('  %s', line.rstrip())

class SSH(object):
    # Wrapper around sshlib.SSHClient

    @staticmethod
    @contextmanager
    def Connect(hostname):
        LOG = logging.getLogger('SSHConnect')
        LOG.debug('attempting to connect to host %r', hostname)
        ssh_client = sshlib.SSHClient()
        with closing(ssh_client) as ssh_client:
            ssh_client.load_host_keys(SSH_KNOWN_HOSTS)
            ssh_client.load_system_host_keys()
            ssh_client.connect(
                hostname=hostname,
                username=SSH_USERNAME,
                key_filename=SSH_PRIVATE_KEY,
                timeout=30.0,
                compress=True
            )
            LOG.debug('connected to host %r', hostname)

            sftp_client = ssh_client.open_sftp()
            with closing(sftp_client) as sftp_client:
                ssh = SSH(hostname, ssh_client)
                sftp = SFTP(ssh, sftp_client)
                yield (ssh, sftp)

    def __init__(self, host, client):
        self.host = host
        self.client = client  # SSHClient

    def Execute(self, command, check_retcode=True, cwd=None):
        # - command must be a string
        # - caller is responsible for ensuring cwd exists
        LOG = logging.getLogger('SSHExecute')
        msg = 'Running command: %s' % command
        if cwd is not None:
            msg = '%s (from directory %s)' % (msg, cwd)
        LOG.info(msg)

        # fabric.operations._shell_wrap and default env.shell
        # TODO: need fabric.operations._prefix_commands, _prefix_env_vars (for cd ...)
        wrapped_command = command
        if cwd is not None:
            wrapped_command = 'cd "%s" && %s' % (cwd, wrapped_command)
        wrapped_command = '/bin/bash -l -c "%s"' % _ShellEscape(wrapped_command)

        # fabric.operations._run_command()
        #   stdout, stderr, status = _execute(default_channel(), wrapped_command, pty,
        #      combine_stderr)
        channel = self.client.get_transport().open_session()
        LOG.debug('opened new session')
        with closing(channel) as channel:
            # fabric.operations._execute()
            channel.set_combine_stderr(True)
            channel.get_pty()  # default size

            # don't bother setting to True -> banners, ... (we always use bash login shell anyway...)
            invoke_shell = False
            LOG.debug('running wrapped command: %s', wrapped_command)
            if invoke_shell:
                channel.invoke_shell()
                channel.sendall(wrapped_command + '\n')
            else:
                channel.exec_command(wrapped_command)

            # It is crucial that we read data, otherwise the server will be unable
            # to send more data and the remote process may block.
            #
            # We don't read stderr since we have already combined above.
            stdout, stderr = [], []
            stdout_worker = threading.Thread(
                    target=_OutputReader,
                    args=(channel.makefile(), stdout, 'stdout'))
           #stderr_worker = threading.Thread(
           #        target=_OutputReader,
           #        args=(channel.makefile_stderr(), stderr, 'stderr'))
            stdout_worker.start()
           #stderr_worker.start()

            LOG.debug('waiting for process to complete')
            retcode = channel.recv_exit_status()  # blocks until ready
            LOG.debug('process completed: retcode = %d', retcode)
            stdout_worker.join()
           #stderr_worker.join()
            stdout = ''.join(stdout)
           #stderr = ''.join(stdout)

        if check_retcode and retcode != 0:
            # -1 means retcode was not defined by server
            raise subprocess.CalledProcessError(retcode, command)

        return retcode, stdout

class SFTP(object):
    # Wrapper around sshlib.SFTPClient
    # Assumes Unix-style paths (-> use posixpath)
    #
    # Warning: this is not thread-safe
    # (We may be able to achieve this by always opening a new SFTPClient)

    def __init__(self, ssh, client):
        self.ssh = ssh
        self.client = client  # SFTPClient
        self.home = client.normalize('.')

    def Download(self, remote_path, local_path):
        # Note: these methods currently assume individual files
        LOG = logging.getLogger('SFTPDownload')
        local_path, remote_path = self._ExpandHome(local_path, remote_path)
        LOG.info('Downloading file from "%s" to "%s"', remote_path, local_path)
        self.client.get(remote_path, local_path)
        assert os.path.exists(local_path)

    def Upload(self, local_path, remote_path):
        # Note: these methods currently assume individual files
        # returns sshlib.SFTPAttributes
        LOG = logging.getLogger('SFTPUpload')
        local_path, remote_path = self._ExpandHome(local_path, remote_path)
        LOG.info('Uploading file from "%s" to "%s"', local_path, remote_path)
        return self.client.put(local_path, remote_path)

    def MakeDirs(self, path, mode=0777):
        LOG = logging.getLogger('SFTPMakeDirs')
        LOG.debug('Creating directory "%s" with mode 0%o', path, mode)
        if not self.Exists(path):
            self._MakeDirs(path, mode)

    def _MakeDirs(self, path, mode):
        # Adapted form of os.makedirs
        head, tail = posixpath.split(path)
        if not tail:
            head, tail = posixpath.split(head)
        if head and tail and not self.Exists(head):
            try:
                self._MakeDirs(head, mode)
            except OSError, e:
                # be happy if someone already created the path
                if e.errno != errno.EEXIST:
                    raise
        self.client.mkdir(path, mode)

    def Exists(self, path):
        try:
            self.client.lstat(path).st_mode
        except IOError:
            return False
        return True

    def _ExpandHome(self, local_path, remote_path):
        # Expand home directory markers
        local_path = os.path.expanduser(local_path)
        if remote_path.startswith('~'):
            remote_path = remote_path.replace('~', self.home, 1)
        return local_path, remote_path

def _SSHPlayground():
    LOG = logging.getLogger('_SSHPlayground')
    host = 'ikr01.ethz.ch'
    with SSH.Connect(host) as (ssh, sftp):
        _, out = ssh.Execute('uptime')
        LOG.info('uptime on %s: %s', host, out)

        _, out = ssh.Execute('echo x${ASL_DIR}y')
        LOG.info('ASL_DIR: %r', out)
        _, out = ssh.Execute('echo x${PYTHONPATH}y')
        LOG.info('PYTHONPATH: %r', out)
        _, out = ssh.Execute('which java')
        LOG.info('which java: %r', out)
        _, out = ssh.Execute('which python')
        LOG.info('which python: %r', out)

        sftp.MakeDirs('/tmp/zc/inner/dir')
        sftp.Upload('manage.py', '/tmp/zc/inner/dir/upload')
        rc, out = ssh.Execute('sha1sum /tmp/zc/inner/dir/upload')
        LOG.info('SHA1 of upload: %s', out)
        sftp.Download('/tmp/zc/inner/dir/upload', 'manage_test.py')

#-------------------------------------------------------------------------------
## Experiment logic

# Each worker process is responsible for a single role on a given host.
# It maintains a single SSHClient and re-uses this thorughout the experiment
# for running processes and transferring files.
#
# Note: SSHClient cannot be serialized between processes:
#   pickle.PicklingError: Can't pickle <type 'thread.lock'>: it's not found as thread.lock
# (Initial idea was to reuse a single connection for each host and open a new
# Channel as needed.)

Message = enum(
    # Comment indicates format of data
    'SINGLE_DATABASE_READY',        # (host, port)
    'MIDDLEWARE_JAR_UPLOADED',      # None
    'CLIENTS_READY',                # None
    'ALL_DATABASES_READY',          # jdbc_urls: string
    'ALL_MIDDLEWARE_READY',         # None (mw_urls passed in constructor)
    'SHUTDOWN_DATABASE',            # None
)

def _RewriteDir(local_path, dirname):
    assert os.path.isfile(local_path)
    base = os.path.basename(local_path)
    return posixpath.join(dirname, base)

# TODO: currently assume all are replicas
def DatabaseWorker(host, port, id_, in_queue, out_queue, config):
    EXPERIMENT_DIR = config['EXPERIMENT_DIR']
    ConfigureLoggingSubprocess(config)
    LOG = logging.getLogger('DatabaseWorker')

    with SSH.Connect(host) as (ssh, sftp):
        # Don't need workaround here -> hosts assumed not to overlap
        sftp.MakeDirs(EXPERIMENT_DIR)

        manage_py_remote = _RewriteDir(MANAGE_PY_LOCAL, EXPERIMENT_DIR)
        argparse_py_remote = _RewriteDir(ARGPARSE_PY_LOCAL, EXPERIMENT_DIR)
        sftp.Upload(MANAGE_PY_LOCAL, manage_py_remote)
        sftp.Upload(ARGPARSE_PY_LOCAL, argparse_py_remote)

        ssh.Execute('python "%s" setup' % manage_py_remote)

        PARTITIONING_MODE = config['PARTITIONING_MODE']
        if PARTITIONING_MODE  == 'SHARDING':
            db_type = 'partition-%d/%d' % (id_, config['NUMBER_OF_DATABASES'])
            db_dir_base = 'partition-%d_%d' % (id_, config['NUMBER_OF_DATABASES'])
        elif PARTITIONING_MODE == 'REPLICATION':
            db_type = 'replica'
            db_dir_base = 'replica-%d' % (id_)
        else:
            raise NotImplementedError()

        db_dir = posixpath.join(EXPERIMENT_DIR, 'db-%s' % db_dir_base)

        ssh.Execute(
            'python "%s" initdb --scale-factor %s --port %d %s:%s' % (
                manage_py_remote, config['SCALE_FACTOR'], port, db_type, db_dir))
        sftp.client.remove(manage_py_remote)
        sftp.client.remove(argparse_py_remote)

        ssh.Execute(
            'pg_ctl -D %s -l %s/postgresql.log -w start' % (db_dir, db_dir))

        LOG.info('Database %d ready (%s:%d)', id_, host, port)
        out_queue.put((Message.SINGLE_DATABASE_READY, (host, port)))

        LOG.debug('waiting for shutdown message')
        typ, _ = in_queue.get()
        assert typ == Message.SHUTDOWN_DATABASE
        ssh.Execute('pg_ctl -D %s -w stop' % db_dir)

        try:
            ssh.Execute('mv %s/pg_log/ %s-pg_log/' % (db_dir, db_dir))
            ssh.Execute('rm -rf %s' % db_dir)
        except Exception:
            LOG.exception('Failed to cleanup database')
            # cleanup is not critical, so just ignore errors

        LOG.info('Database shutdown (%s:%d) - END', host, port)

def MiddlewareWorker(host, port, id_, leader, jar_local, in_queue, out_queue, config):
    EXPERIMENT_DIR = config['EXPERIMENT_DIR']
    ConfigureLoggingSubprocess(config)
    LOG = logging.getLogger('MiddlewareWorker')

    with SSH.Connect(host) as (ssh, sftp):
        # leader creates experiment directory and uploads JAR
        jar_remote = _RewriteDir(jar_local, EXPERIMENT_DIR)
        if leader:
            LOG.debug('middleware %d is leader for host %s', id_, host)
            sftp.MakeDirs(EXPERIMENT_DIR)

            # It would be more efficient to upload once, then rsync between nodes.
            sftp.Upload(jar_local, jar_remote)
            LOG.debug('JAR file uploaded')
            out_queue.put((Message.MIDDLEWARE_JAR_UPLOADED, None))

        LOG.debug('waiting for ALL_DATABASES_READY')
        typ, data = in_queue.get()
        assert typ == Message.ALL_DATABASES_READY
        jdbc_urls = data

        mw_cmdline = MIDDLEWARE_CMDLINE_TEMPLATE % {
            'id': id_,
            'timeout': EXPERIMENT_DURATION + MW_EXTRA_DURATION,
            'port': port,
            'database_url': jdbc_urls,
            'database_connection_pool_size': config['DB_CONNECTION_POOL_SIZE'],
            'partitioning_mode': config['PARTITIONING_MODE'],
            'number_of_dispatcher_threads': config['MIDDLEWARE_DISPATCHER_THREADS'],
            'job_queue_capacity': config['MIDDLEWARE_QUEUE_SIZE'],
            'log_directory': config['EXPERIMENT_LOGS_DIR'],
            'jar_path': jar_remote,
        }

        if not leader:
            # avoid a race condition starting the tmux server, when several
            # middleware share a single host.
            time.sleep(5.0)

        mw_cmdline = 'tmux new-session -s experiment-%s-middleware%d -d \'%s\'' % (
                config['TIMESTAMP'], id_, mw_cmdline)
        LOG.info('Starting middleware %d (%s:%d)', id_, host, port)
        LOG.debug('Command-line: %s', mw_cmdline)
        # Working directory is important, otherwise Atomikos transaction logs
        # would end up being written to NAS!
        ssh.Execute(mw_cmdline, cwd=EXPERIMENT_DIR)

# TODO: for client we need to make sure workload is uploaded somehow ...
def ClientWorker(host, cl_ids_to_start, mw_urls, jar_local, in_queue, out_queue, config):
    ConfigureLoggingSubprocess(config)
    LOG = logging.getLogger('ClientWorker')

    EXPERIMENT_DIR = config['EXPERIMENT_DIR']
    NUMBER_OF_CLIENTS = config['NUMBER_OF_CLIENTS']
    with SSH.Connect(host) as (ssh, sftp):
        sftp.MakeDirs(EXPERIMENT_DIR)

        jar_remote = _RewriteDir(jar_local, EXPERIMENT_DIR)
        workload_dir = posixpath.join(EXPERIMENT_DIR, 'workload')

        # Take advantage of the fact that all share the same host.
        # Should this change, this will need to be modified.
        # (e.g. upload, then rsync to other nodes)
        sftp.Upload(jar_local, jar_remote)
        LOG.debug('JAR file uploaded')

        # prepare update workload
        manage_py_remote = _RewriteDir(MANAGE_PY_LOCAL, EXPERIMENT_DIR)
        argparse_py_remote = _RewriteDir(ARGPARSE_PY_LOCAL, EXPERIMENT_DIR)
        sftp.Upload(MANAGE_PY_LOCAL, manage_py_remote)
        sftp.Upload(ARGPARSE_PY_LOCAL, argparse_py_remote)

        ssh.Execute('python "%s" setup --only-dbgen' % manage_py_remote)
        ssh.Execute('python "%s" workload %d "%s"' % (
            manage_py_remote, NUMBER_OF_CLIENTS, workload_dir))
        sftp.client.remove(manage_py_remote)
        sftp.client.remove(argparse_py_remote)

        out_queue.put((Message.CLIENTS_READY, None))

        LOG.debug('waiting for ALL_MIDDLEWARE_READY')
        typ, _ = in_queue.get()
        assert typ == Message.ALL_MIDDLEWARE_READY

        tmux_session = 'experiment-%s' % config['TIMESTAMP']
        LOG.debug('Starting clients with id: %r', cl_ids_to_start)
        for cl_id in cl_ids_to_start:
            cl_cmdline = CLIENT_CMDLINE_TEMPLATE % {
                'id': cl_id,
                'timeout': EXPERIMENT_DURATION,
                'servers': mw_urls,
                'workload_data_path': workload_dir,
                'log_directory': config['EXPERIMENT_LOGS_DIR'],
                'jar_path': jar_remote,
            }

            # For whatever reason this didn't work:
            #   'nohup %s > %s 2>&1 < /dev/null &'
            # Execution succeded with retcode = 0, but the remote process didn't exist.
            #
            # This is even suggested in the fabric FAQ:
            # http://fabric.readthedocs.org/en/latest/faq.html#why-can-t-i-run-programs-in-the-background-with-it-makes-fabric-hang

            cl_cmdline = 'tmux new-session -s %s-client%d -d \'%s\'' % (
                    tmux_session, cl_id, cl_cmdline)
            LOG.info('Starting client %d (%s)', cl_id, host)
            LOG.debug('Command-line: %s', cl_cmdline)
            ssh.Execute(cl_cmdline, cwd=EXPERIMENT_DIR)

        # TODO: archive logs and download

def CheckConfiguration(config):
    for key, value in config.iteritems():
        assert value is not None, 'config[%r] has not been set' % key

    db_hosts = len(config['DATABASE_HOSTS'])
    num_db = config['NUMBER_OF_DATABASES']
    assert db_hosts >= num_db, (
        'Experiment requires %d databases, but only %d were specified' % (
            num_db, db_hosts))

    mw_hosts = len(config['MIDDLEWARE_HOSTS'])
    max_middleware = mw_hosts * config['MIDDLEWARE_PER_HOST']
    num_mw = config['NUMBER_OF_MIDDLEWARE']
    assert max_middleware >= num_mw, (
        'Experiment requires %d middleware, but only %d hosts (-> %d middleware)'
        ' were specified' % (num_mw, mw_hosts, max_middleware))

    cl_hosts = len(config['CLIENT_HOSTS'])
    max_clients = cl_hosts * config['CLIENTS_PER_HOST']
    num_cl = config['NUMBER_OF_CLIENTS']
    assert max_clients >= num_cl, (
        'Experiment requires %d clients, but only %d hosts (-> %d clients) were '
        'specified' % (num_cl, cl_hosts, max_clients))

    #if config['PARTITIONING_MODE'] == 'SHARDING':
    #    assert len(config['DATABASE_HOSTS']) > 1, (
    #            "sharding doesn't make sense with just one database")

def GenerateTmuxScript(tmux_fn, config):
    EXPERIMENT_DIR = config['EXPERIMENT_DIR']
    DB_HOSTS = config['DATABASE_HOSTS']
    MW_HOSTS = config['MIDDLEWARE_HOSTS']
    CL_HOSTS = config['CLIENT_HOSTS']

    with open(tmux_fn, 'w') as tmux_f:
        tmux_f.write('#!/bin/bash -e\n')
        for host in itertools.chain(DB_HOSTS, MW_HOSTS, CL_HOSTS):
            host_short = host.replace('.ethz.ch', '')
            tmux_f.write(textwrap.dedent('''
                # %(host)s
                tmux new-window -n "%(host_short)s-htop"
                sleep 0.5
                tmux send-keys "ssh %(host)s" "Enter" "htop" "Enter"
                sleep 0.5
                tmux new-window -n "%(host_short)s-logs"
                sleep 0.5
                tmux send-keys "ssh %(host)s" "Enter" "cd %(EXPERIMENT_DIR)s" "Enter" "ls -la" "Enter"
                sleep 0.5
            ''' % {
                'host_short': host_short,
                'host': host,
                'EXPERIMENT_DIR': EXPERIMENT_DIR,
            }))

def RunExperiment(config, client_jar, middleware_jar):
    # Fill in internal config values
    TIMESTAMP = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    config['TIMESTAMP'] = TIMESTAMP
    LOCAL_LOG_BASE = '%s-%s' % (os.path.splitext(SCRIPT_NAME)[0], TIMESTAMP)
    LOCAL_LOG_DIR = makedirs(SCRIPT_DIR, 'logs', LOCAL_LOG_BASE)
    config['LOCAL_LOG_DIR'] = LOCAL_LOG_DIR
    EXPERIMENT_DIR = posixpath.join(ASL_DIR, 'experiments', TIMESTAMP)
    config['EXPERIMENT_DIR'] = EXPERIMENT_DIR
    config['EXPERIMENT_LOGS_DIR'] = posixpath.join(EXPERIMENT_DIR, 'logs')
    CheckConfiguration(config)
    # config should not be modified beyond this point [!]

    ConfigureExperimentLogging(config)
    LOG = logging.getLogger('RunExperiment')
    LOG.info('Experiment configuration:\n%s', pprint.pformat(config))

    GenerateTmuxScript(os.path.join(LOCAL_LOG_DIR, 'tmux.sh'), config)

    # Star-topology of queues for communiation with worker processes
    # - incoming
    main_db_queue = multiprocessing.Queue()
    main_mw_queue = multiprocessing.Queue()
    main_cl_queue = multiprocessing.Queue()
    # - outgoing: Map<Process -> Queue>
    db_workers = dict()
    mw_workers = dict()
    mw_workers_leaders = dict()
    cl_workers = dict()

    DATABASE_HOSTS = config['DATABASE_HOSTS']
    NUM_DB = config['NUMBER_OF_DATABASES']
    LOG.info('Starting %d databases: %s', NUM_DB, DATABASE_HOSTS[:NUM_DB])
    jdbc_urls = []  # ordering is important for sharding (!)
    for i in xrange(NUM_DB):
        host = DATABASE_HOSTS[i]
        db_id = i + 1
        port = TPCH_DB_PORT + db_id

        in_queue = multiprocessing.Queue()
        p = multiprocessing.Process(
                target=DatabaseWorker,
                name='database_%d_%s' % (db_id, host),
                args=(host, port, db_id, in_queue, main_db_queue, config))
        db_workers[p] = in_queue
        p.start()

        jdbc_urls.append(
            'jdbc:postgresql://%s:%s/%s' % (host, port, TPCH_DB_NAME))
    jdbc_urls = ';'.join(jdbc_urls)
    LOG.debug('JDBC URLs: %s', jdbc_urls)

    # (now would be a good time to run the validation query)

    NUM_MW = config['NUMBER_OF_MIDDLEWARE']
    MIDDLEWARE_HOSTS = config['MIDDLEWARE_HOSTS']
    MW_PER_HOST = config['MIDDLEWARE_PER_HOST']
    mw_urls = []  # ordering is important, since mw_urls[0] is the update middleware
    for i, mw_ids in enumerate(BlockedIterator(xrange(1, NUM_MW + 1), MW_PER_HOST)):
        host = MIDDLEWARE_HOSTS[i]
        for j, mw_id in enumerate(mw_ids):
            leader = (j == 0)
            LOG.info('Starting middleware worker on %s for: %r', host, mw_id)
            port = MIDDLEWARE_BASE_PORT + mw_id
            mw_urls.append('%s:%d' % (host, port))

            in_queue = multiprocessing.Queue()
            p = multiprocessing.Process(
                    target=MiddlewareWorker,
                    name='middleware_%d_%s' % (mw_id, host),
                    args=(host, port, mw_id, leader, middleware_jar,
                          in_queue, main_mw_queue, config))
            mw_workers[p] = in_queue
            if leader:
                mw_workers_leaders[p] = in_queue
            p.start()
    mw_urls = ';'.join(mw_urls)

    CLIENT_HOSTS = config['CLIENT_HOSTS']
    NUM_CL = config['NUMBER_OF_CLIENTS']
    CL_PER_HOST = config['CLIENTS_PER_HOST']
    for i, cl_ids in enumerate(BlockedIterator(xrange(1, NUM_CL + 1), CL_PER_HOST)):
        host = CLIENT_HOSTS[i]
        LOG.info('Starting client worker %d on %s for: %r', i, host, cl_ids)

        in_queue = multiprocessing.Queue()
        p = multiprocessing.Process(
                target=ClientWorker,
                name='client_%s' % host,
                args=(host, cl_ids, mw_urls, client_jar, in_queue, main_cl_queue, config))
        cl_workers[p] = in_queue
        p.start()

    # Wait until all databases are ready
    for i in xrange(NUM_DB):
        typ, data = main_db_queue.get()
        assert typ == Message.SINGLE_DATABASE_READY
        host, port = data
        LOG.debug('received SINGLE_DATABASE_READY from %s:%d', host, port)
    LOG.info('All databases ready')

    # Start middleware once JAR file has uploaded
    for p, in_queue in mw_workers_leaders.iteritems():
        typ, data = main_mw_queue.get()
        assert typ == Message.MIDDLEWARE_JAR_UPLOADED
        LOG.info('Middleware JAR file has been uploaded (%s)', p.name)

    LOG.info('Notiying middleware that databases are ready')
    for p, in_queue in mw_workers.iteritems():
        LOG.debug('ALL_DATABASES_READY -> process %s', p.name)
        in_queue.put((Message.ALL_DATABASES_READY, jdbc_urls))

    # We don't actually know when the middleware is ready -> assume 30 seconds
    # Once the clients are ready too, they can start
    time.sleep(30)
    typ, data = main_cl_queue.get()
    assert typ == Message.CLIENTS_READY
    LOG.info('Clients are ready, one minute has elapsed -> START!')

    for p, in_queue in cl_workers.iteritems():
        LOG.debug('ALL_MIDDLEWARE_READY -> process %s', p.name)
        in_queue.put((Message.ALL_MIDDLEWARE_READY, None))

    # Wait for middleware to complete
    MW_TIMEOUT = EXPERIMENT_DURATION + MW_EXTRA_DURATION
    MW_TIMEOUT_DELTA = datetime.timedelta(minutes=MW_TIMEOUT)
    when = datetime.datetime.now() + MW_TIMEOUT_DELTA
    LOG.info('Waiting %s minutes (%s) for middleware to complete',
            MW_TIMEOUT, when)
    time.sleep(timedelta_total_seconds(MW_TIMEOUT_DELTA))

    # Shutdown and tidy up
    LOG.info('Shutting down all the databases')
    for p, in_queue in db_workers.iteritems():
        LOG.debug('SHUTDOWN_DATABASE -> process %s', p.name)
        in_queue.put((Message.SHUTDOWN_DATABASE, None))

    LOG.info('Killing any lingering processes as a precaution')
    for host in itertools.chain(DATABASE_HOSTS, MIDDLEWARE_HOSTS, CLIENT_HOSTS):
        try:
            with SSH.Connect(host) as (ssh, sftp):
                ssh.Execute('killall postgres java', check_retcode=False)
        except Exception:
            LOG.exception('Failed to kill processes on host %s', host)
            # ignore, since not critical

    LOG.info('Waiting for all workers to complete')
    for p in itertools.chain(db_workers, mw_workers, cl_workers):
        LOG.debug('waiting on join() for %s', p.name)
        p.join()
        LOG.debug('process %s terminated (exitcode: %d)', p.name, p.exitcode)

    # do we also need to close/join_thread the queues?

    LOG.info('Experiment %s completed successfully', TIMESTAMP)

def Experiment2K(parameters):
    # 2^k factorial experiment
    # See slide 25 of:
    #   http://www.systems.ethz.ch/education/hs11/asl/lectures/SysLab-Experiments.pdf
    if any(len(v) < 2 for v in parameters.itervalues()):
        raise ValueError('each parameter should only have exactly 2 levels')

    # initialize recursion
    count = 0
    keys = parameters.keys()
    config = OrderedDict.fromkeys(keys)
    for cfg in Experiment2K_recursion(parameters, keys, config):
        yield cfg
        count += 1

    expected_experiments = reduce(
        operator.mul, (len(v) for v in parameters.itervalues()))
    assert count == expected_experiments, (
        'Incorrect number of experiments: %d instead of %d' % (
            count, expected_experiments))

def Experiment2K_recursion(parameters, keys, config):
    # base case: all parameters have been fixed
    # (must copy config as we modify internally for next combination)
    if not keys:
        yield OrderedDict(config)
        return

    # vary the first paameter ('least important')
    k = keys[0]
    values = parameters[k]
    other_keys = keys[1:]
    for v in values:
        config[k] = v
        for cfg in Experiment2K_recursion(parameters, other_keys, config):
            yield cfg

def VarySingleParameter(param, levels):
    # use default parameters and only vary param at the specified levels
    config = dict(DEFAULT_CONFIGURATION)
    for level in levels:
        config[param] = level
        yield dict(config)

def main():
    # TODO:
    # - how do we disable internal logging for the ssh module (?)
    #   (or just reduce all its level to DEBUG)
    # - global exception handler
    # - exception safety (i.e. clean abort or if not feasible terminate)
    # - log the current SVN revision, all experiment parameters, ...

    # Minimal argument parsing
    parser = argparse.ArgumentParser()
    parser.add_argument(
        'resume', action='store',
        help='Path to store current experiment progress - allows resuming at a later stage.'
    )
    args = parser.parse_args()

    # Enable logging
    logging_queue, logging_listener = ConfigureMainLogging()
    LOG = logging.getLogger('main')

    # Build code with Maven
    LOG.info('Building code with Maven (directory: %s)', CODE_DIR)
    mvn_cmd = 'mvn clean verify'
    if ETHZ_CLUSTER:
        # See README - "Tests on Cluster"
        #   BlockingIOTest: java.net.SocketException: Too many open files
        mvn_cmd = '%s -DskipTests' % mvn_cmd
    subprocess.check_call(mvn_cmd, cwd=CODE_DIR, shell=True)

    client_jar = os.path.join(CODE_DIR, 'client', 'target', CLIENT_JAR_FILENAME)
    middleware_jar = os.path.join(CODE_DIR, 'middleware', 'target', MIDDLEWARE_JAR_FILENAME)
    assert os.path.isfile(client_jar), 'Client JAR not found: %r' % client_jar
    assert os.path.isfile(middleware_jar), 'Middleware JAR not found: %r' % middleware_jar
    LOG.debug('Code built and JAR files exist')

    # Select experiment type:
    if False:
        # 1) vary number of clients
        DEFAULT_CONFIGURATION.update({
            'NUMBER_OF_DATABASES': 1,
            'NUMBER_OF_MIDDLEWARE': 1,
            'PARTITIONING_MODE': 'SHARDING',
        })
        experiment_series = VarySingleParameter(
            'NUMBER_OF_CLIENTS', reversed([2, 4, 8, 16, 32, 64, 128]))
    elif False:
        # 2) 2^k experiment
        DEFAULT_CONFIGURATION['NUMBER_OF_CLIENTS'] = 64
        experiment_series = Experiment2K(EXPERIMENT_PARAMETERS)
    elif True:
        # 3) fixed series - nclients/speed-up/scale-up/scale-out (Thu. 17 Nov)
        def _gen(base_config, deltas):
            for delta in deltas:
                d = dict(base_config)
                d.update(delta)
                yield d

        base_config = dict(DEFAULT_CONFIGURATION)
        base_config.update(OPTIMAL_CONFIGURATION)

        experiment_series = _gen(base_config, [
            # scale-out
            ## 3 machines
            [('NUMBER_OF_CLIENTS', 32), ('NUMBER_OF_DATABASES', 1)],
            ## 4 machines
            [('NUMBER_OF_CLIENTS', 64), ('NUMBER_OF_DATABASES', 2)],
           #[('NUMBER_OF_CLIENTS', 128), ('NUMBER_OF_DATABASES', 4)],  # 2k_r1 (20111112-032436)

            # scale-up
           #[('SCALE_FACTOR', '0.1'), ('NUMBER_OF_DATABASES', 1)],  # 2k_r1_64cl (20111114-163550)
            ## 4 machines
            [('SCALE_FACTOR', '0.2'), ('NUMBER_OF_DATABASES', 2)],
            ## 6 machines
            [('SCALE_FACTOR', '0.4'), ('NUMBER_OF_DATABASES', 4)],

            # speed-up
           #[('NUMBER_OF_CLIENTS', 64), ('NUMBER_OF_DATABASES', 1)],  # 2k_r1_64cl (20111114-163550)
            ## 4 machines
            [('NUMBER_OF_CLIENTS', 64), ('NUMBER_OF_DATABASES', 2)],
           #[('NUMBER_OF_CLIENTS', 64), ('NUMBER_OF_DATABASES', 4)],  # 2k_r1_64cl (20111115-011131)

            # TODO: stress test (256 clients, 2 hours)
        ])
    else:
        raise NotImplementedError()

    # Run series of experiments
    resume_path = os.path.abspath(args.resume)
    if not os.path.isfile(resume_path):
        LOG.info('No resume information found (%s) - starting new experiment', resume_path)
        configs = list(experiment_series)
        LOG.debug('Experiment configurations:\n%s', pprint.pformat(configs))
        with open(resume_path, 'wb') as resume_f:
            pickle.dump(configs, resume_f, pickle.HIGHEST_PROTOCOL)

    if SLOT_START is not None:
        now = datetime.datetime.now()
        LOG.debug('now = %r, slot_start = %r', now, SLOT_START)
        if now < SLOT_START:
            wait_sec = timedelta_total_seconds(SLOT_START - now)
            LOG.info('Waiting %s seconds for start of slot (%s)', wait_sec, SLOT_START)
            time.sleep(wait_sec)
        else:
            LOG.debug('No wait necessary - slot has already started (%s)', SLOT_START)
    else:
        LOG.debug('No wait necessary - no start slot was defined')

    while True:
        # Only continue if we sufficient time remains
        if SLOT_END is not None:
            now = datetime.datetime.now()
            # conservative estimate of time needed for entire experiment
            duration = datetime.timedelta(
                minutes=(EXPERIMENT_DURATION + MW_EXTRA_DURATION + 5))
            if now + duration > SLOT_END:
                LOG.info('Time slot is up (%s) - END', SLOT_END)
                break

        # Load previous experiment progress
        with open(resume_path, 'rb') as resume_f:
            remaining_configs = pickle.load(resume_f)
        if not remaining_configs:
            LOG.info('All experiments complete - END')
            break
        cfg = remaining_configs[0]

        # Run current experiment configuration
        config = dict(DEFAULT_CONFIGURATION)
        config.update(cfg)
        config['LOGGING_QUEUE'] = logging_queue
        RunExperiment(config, client_jar, middleware_jar)

        # 'Commit' - this configuration can be removed now
        remaining_configs = remaining_configs[1:]
        with closing(atomictempfile(resume_path, 'wb')) as resume_f:
            pickle.dump(remaining_configs, resume_f, pickle.HIGHEST_PROTOCOL)

    LOG.debug('waiting for logging listener to shutdown')
    logging_queue.put(None)
    logging_listener.join()

    LOG.info('Current invocation has completed')

if __name__ == '__main__':
    main()
