#!/usr/bin/env python
# encoding: utf-8

import json
import os
import random
import subprocess
import sys

try:
    import regex as re
except ImportError:
    import re

SCRIPT_DIR, SCRIPT_NAME = os.path.split(os.path.abspath(__file__))

#WORKLOAD_DIR = os.path.join(SCRIPT_DIR, 'milestone01_workload')
#assert os.path.isdir(WORKLOAD_DIR), 'Workoad not found: %s' % os.path.relpath(WORKLOAD_DIR)

if False:
    pgsql_tool = lambda x: x
else:
    pgsql_tool = lambda x: os.path.join(SCRIPT_DIR, 'tools', 'postgresql-9.1.1', 'bin', x)

class PostgreSQLDatabase(object):
    RX_PSQL_TIME = re.compile('Time:\s+(\d+\.\d+)\s*ms')

    def __init__(self, host, port):
        self.host = str(host)
        self.port = str(port)

    def psql(self, command):
       #print 'psql: "%s"' % command
        if command[-1] != ';':
            command = command + ';'
        input_ = '\\timing on\n%s' % command
        proc = subprocess.Popen([
                pgsql_tool('psql'),
                '-U', 'asl_c2g2',
                '-h', self.host,
                '-p', self.port,
                '-d', 'tpch',
                '-w',  # never issue a password prompt
            ],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=4096,
            universal_newlines=True)

        output, errout = proc.communicate(input_)
        retcode = proc.wait()

        if retcode != 0:
            raise subprocess.CalledProcessError(
                retcode, '%s\n\n%s\n\n%s' % (command, output, errout))

        return output, errout

    def timed_psql(self, command):
        out, err = self.psql(command)
        match = self.RX_PSQL_TIME.search(out)
        if not match:
            raise Exception('Could not find time:\n%s\n\n%s' % (out, err))
        return float(match.group(1))

def ReadWorkloadData(workload_dir, id_=1):
    tuple_str = lambda t: '(%s)' % ', '.join("'%s'" % x for x in t)
    workload = lambda fn: os.path.join(workload_dir, fn % id_)

    # RF1 data
    orders = []
    with open(workload('orders.tbl.u%d')) as orders_f:
        for orders_line in orders_f:
            order = orders_line.split('|')[:-1]
            orders.append(order)

    lineitems = []
    with open(workload('lineitem.tbl.u%d')) as lineitem_f:
        for lineitem_line in lineitem_f:
            lineitem = lineitem_line.split('|')[:-1]
            lineitems.append(lineitem)

    order_idx = 0
    lineitem_idx = 0
    rf1_workload = []  # list of RF1Data (list of SQL)
    while order_idx < len(orders):
        sql = []

        order = orders[order_idx]
        o_orderkey = order[0]
        order_sql = 'insert into orders values %s;' % tuple_str(order)
        sql.append(order_sql)

        while lineitem_idx < len(lineitems):
            lineitem = lineitems[lineitem_idx]
            l_orderkey = lineitem[0]
            if l_orderkey != o_orderkey:
                break
            lineitem_sql = 'insert into lineitem values %s;' % tuple_str(lineitem)
            sql.append(lineitem_sql)
            lineitem_idx += 1

        rf1_workload.append(sql)
        order_idx += 1

    # RF2 data
    rf2_workload = []
    with open(workload('delete.%d')) as delete_f:
        for line in delete_f:
            orderkey = int(line.split('|')[0])
            # important that lineitem comes first, otherwise:
            #   psql:tpch-sample-workload.sql:1130: ERROR:  update or delete on table
            #   "orders" violates foreign key constraint "lineitem_l_orderkey_fkey" on table "lineitem"
            rf2_workload.append([
                'delete from lineitem where l_orderkey = %d;' % orderkey,
                'delete from orders where o_orderkey = %d;' % orderkey,
            ])

    return rf1_workload, rf2_workload

TPCH_Q1_SQL = """\
select
    l_returnflag,
    l_linestatus,
    sum(l_quantity) as sum_qty,
    sum(l_extendedprice) as sum_base_price,
    sum(l_extendedprice * (1 - l_discount)) as sum_disc_price,
    sum(l_extendedprice * (1 - l_discount) * (1 + l_tax)) as sum_charge,
    avg(l_quantity) as avg_qty,
    avg(l_extendedprice) as avg_price,
    avg(l_discount) as avg_disc,
    count(*) as count_order
from
    lineitem
where
    l_shipdate <= date '1998-12-01' - interval '%s' day
group by
    l_returnflag,
    l_linestatus
order by
    l_returnflag,
    l_linestatus;
"""

def GenerateQuery1():
    return TPCH_Q1_SQL % random.randint(60, 120)

WARMUP_CYCLES = 5
MEASUREMENT_CYCLES = 100
DATABASE_NODES = [
    ('ikr17.ethz.ch', 22001),
   #('localhost', 22002)
]

def RunWorkloadCycle(timed_db_func, rf1_workload, rf2_workload, description):
    # For partitioning: sum of individual times
    print 'Workload %s' % description
    timings = dict(Q1=[], RF1=[], RF2=[])

    print '- RF1'
    for rf1 in rf1_workload:
        rf1_sql = '\n'.join(rf1)
        time = timed_db_func(rf1_sql)
        timings['RF1'].append(time)

    print '- Q1'
    q1_sql = GenerateQuery1()
    time = timed_db_func(q1_sql)
    timings['Q1'].append(time)

    print '- RF2'
    for rf2 in rf2_workload:
        rf2_sql = '\n'.join(rf2)
        time = timed_db_func(rf2_sql)
        timings['RF2'].append(time)

    print '\n'
    return timings

def main(args):
    # parse command-line arguments
    if len(args) != 1:
        print >> sys.stderr, 'Usage: %s <workload directory>' % SCRIPT_NAME
        sys.exit(1)
    workload_dir = os.path.abspath(args[0])

    rf1_workload, rf2_workload = ReadWorkloadData(workload_dir)
    databases = [PostgreSQLDatabase(host, port) for host, port in DATABASE_NODES]

    def psql_sum_all_database_times(*args, **kwargs):
        return sum(db.timed_psql(*args, **kwargs) for db in databases)
    timed_db_func = psql_sum_all_database_times

    description = 'warmup-%d'
    for i in xrange(WARMUP_CYCLES):
        discard_timings = RunWorkloadCycle(
                timed_db_func, rf1_workload, rf2_workload, description % i)

    description = 'measurement-%d'
    global_timings = dict(Q1=[], RF1=[], RF2=[])
    for i in xrange(MEASUREMENT_CYCLES):
        timings = RunWorkloadCycle(
                timed_db_func, rf1_workload, rf2_workload, description % i)
        for k, v in timings.iteritems():
            global_timings[k].extend(v)

    with open('%s.results' % os.path.splitext(__file__)[0], 'w') as f:
        json.dump(global_timings, f, indent=2)

if __name__ == "__main__":
    main(sys.argv[1:])
