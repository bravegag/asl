#!/bin/bash -e

# Advanced Systems Lab (Fall 2011, Class 2, Group 2)
# Script to setup cluster node (PostgreSQL, TPC-H dbgen, ...)

################################################################################

if [ -z "$1" ]; then
  echo "Usage: $0 <database directory>"
  exit 1
fi
TPCHDB_DIR=$1

################################################################################

GROUP_DIR=$HOME/temp/asl-c2g2
test -d $GROUP_DIR || {
  # Create directory, without group/world permissions
  echo "Created group directory: $GROUP_DIR"
  mkdir -p "$GROUP_DIR"
  chmod -R go-rwx "$GROUP_DIR"
}

################################################################################

## Only install PSQL if not present
#PSQL=`builtin type -P psql`
#test "$PSQL" != "" && {
#  echo "PostgreSQL already installed: `dirname $PSQL`"
#} || {
#  # Install PostgreSQL
#}

POSTGRESQL_DIR=$GROUP_DIR/pkg/postgresql
POSTGRESQL_VERSION=9.1.1
POSTGRESQL=postgresql-$POSTGRESQL_VERSION
POSTGRESQL_FILE=$POSTGRESQL.tar.bz2
POSTGRESQL_URL=http://ftp2.ch.postgresql.org/pub/mirrors/postgresql/source/v$POSTGRESQL_VERSION/$POSTGRESQL_FILE

test -d "$POSTGRESQL_DIR" && {
    echo "PostgreSQL already installed in: $POSTGRESQL_DIR"
} || {
    BUILD_TMP=$GROUP_DIR/tmp-setup-psql.$$
    mkdir -p "$BUILD_TMP"
    pushd "$BUILD_TMP"

    echo "Installing PostgreSQL"
    wget $POSTGRESQL_URL
    tar -xjf $POSTGRESQL_FILE
    rm $POSTGRESQL_FILE
    pushd "$POSTGRESQL"

    ./configure --prefix="$POSTGRESQL_DIR" --without-readline
    make
    make install

    popd  # $POSTGRESQL
    popd  # $BUILD_TMP
    rm -rf "$BUILD_TMP"
}

################################################################################

DBGEN=tpch_2_14_0_dbgen
DBGEN_FILE=$DBGEN.tar.bz2
DBGEN_URL=http://n.ethz.ch/~zchothia/asl2011/$DBGEN_FILE
DBGEN_DIR=$GROUP_DIR/pkg/$DBGEN

test -d "$DBGEN_DIR" && {
    echo "TPC-H dbgen already built: $DBGEN_DIR"
} || {
    echo "Building TPC-H dbgen"
    mkdir -p "$GROUP_DIR/pkg"
    pushd "$GROUP_DIR/pkg"
    wget $DBGEN_URL
    tar -xjf $DBGEN_FILE
    rm $DBGEN_FILE
    popd

    pushd "$DBGEN_DIR"

    cp makefile.suite Makefile
    sed -r -i                                       \
        -e "s/^(CC)\s*=.*$/\1=gcc/g"                \
        -e "s/^(DATABASE)\s*=.*$/\1=SQLSERVER/g"    \
        -e "s/^(MACHINE)\s*=.*$/\1=LINUX/g"         \
        -e "s/^(WORKLOAD)\s*=.*$/\1=TPCH/g"         \
      Makefile
    sed -r -i                                       \
        -e "s/^#include\s*<malloc\.h>//"            \
      bm_utils.c varsub.c
    make

    echo "Generating TPC-H database"
    ./dbgen -s 0.1
    # output: 'customer.tbl', 'lineitem.tbl', 'nation.tbl', 'orders.tbl', 'part.tbl', 'partsupp.tbl', 'region.tbl', 'supplier.tbl'
    ./dbgen -s 0.1 -U 1
    # output: 'delete.1', 'lineitem.tbl.u1', 'orders.tbl.u1'

    # Strip pipe at end of last column
    for f in *.tbl *.1 *.u1 ; do
      sed -r -i -e "s/\s*\|?$//" "$f"
    done

    popd  # $DBGEN_DIR
}

################################################################################

TPCHDB_PORT=33333
TPCHDB_DB=tpch
TPCHDB_USER=asl-c2g2
TPCHDB_PSWD=matterhorn
TPCHDB_PSWD_FILE=$HOME/psqlpswd

test -d "$TPCHDB_DIR" && {
    echo "TPC-H PostgreSQL database already exists: $TPCHDB_DIR"
} || {
    echo "Creating TPC-H PostgreSQL database"
    echo "$TPCHDB_PSWD" > "$TPCHDB_PSWD_FILE"
    $POSTGRESQL_DIR/bin/initdb -U "$TPCHDB_USER" --pwfile="$TPCHDB_PSWD_FILE" "$TPCHDB_DIR"
    rm "$TPCHDB_PSWD_FILE"
    sed -r -i                                                 \
        -e "s/^#?(listen_addresses)\s*\=\s*'.*'/\1 = '*'/g"   \
        -e "s/^#?(port)\s*\=\s*[0-9]+/\1 = $TPCHDB_PORT/g"    \
        -e "s/^#?(max_prepared_transactions)\s*\=\s*[0-9]+/\1 = 50/g"    \
      "$TPCHDB_DIR/postgresql.conf"

    cat >> "$TPCHDB_DIR/pg_hba.conf" << EOF
# ikr cluster [ikr01-ikr31: 129.132.186.{14,...,44}]
host    all             all             129.132.186.0/26        trust
EOF

    # Create database, tables and import data
    $POSTGRESQL_DIR/bin/pg_ctl -D "$TPCHDB_DIR" -l "$TPCHDB_DIR/psql.log" start
    sleep 2
    $POSTGRESQL_DIR/bin/createdb -U "$TPCHDB_USER" -h 127.0.0.1 -p $TPCHDB_PORT $TPCHDB_DB

    echo "Created database '$TPCHDB_DB'; importing schema"
    $POSTGRESQL_DIR/bin/psql -U "$TPCHDB_USER" -h 127.0.0.1 -p $TPCHDB_PORT -d $TPCHDB_DB < "$DBGEN_DIR/dss.ddl"
    sleep 2
    for tblf in $DBGEN_DIR/*.tbl ; do
        # get filename without extension
        tblfn=$(basename $tblf)
        tblfb=${tblfn%.*}
        echo "Importing data for '$tblfb' table"
        $POSTGRESQL_DIR/bin/psql -U "$TPCHDB_USER" -h 127.0.0.1 -p $TPCHDB_PORT -d $TPCHDB_DB -c \
            "COPY $tblfb FROM '$tblf' WITH DELIMITER '|';"
        sleep 2
    done

    echo "Creating indices"
    for cmd in "CREATE INDEX N_NATIONKEY_IDX ON NATION(N_NATIONKEY);" \
               "CREATE INDEX N_REGIONKEY_IDX ON NATION(N_REGIONKEY);" \
               "CREATE INDEX R_REGIONKEY_IDX ON REGION(R_REGIONKEY);" \
               "CREATE INDEX P_PARTKEY_IDX ON PART(P_PARTKEY);" \
               "CREATE INDEX S_SUPPKEY_IDX ON SUPPLIER(S_SUPPKEY);" \
               "CREATE INDEX S_NATIONKEY_IDX ON SUPPLIER(S_NATIONKEY);" \
               "CREATE INDEX PS_PARTKEY_IDX ON PARTSUPP(PS_PARTKEY);" \
               "CREATE INDEX PS_SUPPKEY_IDX ON PARTSUPP(PS_SUPPKEY);" \
               "CREATE INDEX C_CUSTKEY_IDX ON CUSTOMER(C_CUSTKEY);" \
               "CREATE INDEX C_NATIONKEY_IDX ON CUSTOMER(C_NATIONKEY);" \
               "CREATE INDEX O_ORDERKEY_IDX ON ORDERS(O_ORDERKEY);" \
               "CREATE INDEX O_CUSTKEY_IDX ON ORDERS(O_CUSTKEY);" \
               "CREATE INDEX L_ORDERKEY_IDX ON LINEITEM(L_ORDERKEY);" \
               "CREATE INDEX L_PARTKEY_IDX ON LINEITEM(L_PARTKEY);" \
               "CREATE INDEX L_SUPPKEY_IDX ON LINEITEM(L_SUPPKEY);" ;
    do
        $POSTGRESQL_DIR/bin/psql -U "$TPCHDB_USER" -h 127.0.0.1 -p $TPCHDB_PORT -d $TPCHDB_DB -c "$cmd"
        sleep 2
    done

    $POSTGRESQL_DIR/bin/psql -U "$TPCHDB_USER" -h 127.0.0.1 -p $TPCHDB_PORT -d $TPCHDB_DB -c "VACUUM ANALYZE"
    $POSTGRESQL_DIR/bin/pg_ctl -D "$TPCHDB_DIR" stop
}
echo "Creating archive with clean database copy"
tar -cjf "`basename "$TPCHDB_DIR"`.tar.bz2" "$TPCHDB_DIR"
