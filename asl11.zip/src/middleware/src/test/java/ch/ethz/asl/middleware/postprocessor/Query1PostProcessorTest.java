/**
 * Query1PostProcessorTest.java
 */
package ch.ethz.asl.middleware.postprocessor;

import java.math.*;
import java.util.*;

import junit.framework.*;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.common.sql.*;

import com.google.common.base.*;
import com.google.common.collect.*;

/**
 * Test suite for the {@link Query1PostProcessor} implementation
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 24, 2011
 */
public class Query1PostProcessorTest extends TestCase {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private static final String SEPARATOR = "|";
	private static final List<String> DUMMY_INPUT = Lists
			.newArrayList(ImmutableList
					.of("A|F|2|2|2|2|2|2|2|2|2",
							"N|F|95649.00|134172572.84|127551693.3068|132726528.690997|25.2638668779714739|35439.137041732699|0.04932382461701003698|3786|0",
							"A|F|4|4|4|4|4|4|4|4|4",
							"A|F|6|6|6|6|6|6|6|6|6",
							"R|F|3813536.00|5378651674.51|5110369031.9836|5314511797.056351|25.5321701637632062|36010.843953013484|0.05001546578112237383|149362|0"));
	private static final List<String> DUMMY_OUTPUT = Lists
			.newArrayList(ImmutableList
					.of("A|F|12.0|12.0|12.0|12.0|12.0|1|1|1|12.0",
							"N|F|95649.00|134172572.84|127551693.3068|132726528.690997|25.2638668779714739|35439.137041732699|0.04932382461701003698|3786|0",
							"R|F|3813536.00|5378651674.51|5110369031.9836|5314511797.056351|25.5321701637632062|36010.843953013484|0.05001546578112237383|149362|0"));

	/**
	 * Maps each input result to expected output.
	 */
	private static final Map<List<String>, List<String>> TEST_DATA = new ImmutableMap.Builder<List<String>, List<String>>()
			.put(DUMMY_INPUT, DUMMY_OUTPUT).build();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Tests that the {@link ResponseData} is processed correctly
	 */
	public void testCorrectProcessing() {
		// create the Query1PostProcessor instance, make sure to get it
		// right from the Factory
		IPostProcessor processor = new PostProcessorFactory().create(TpchWorkload.QUERY_1);

		final BigDecimal EPSILON = BigDecimal.valueOf(1e-10);
		Splitter splitter = Splitter.on(SEPARATOR);
		int count = 0;
		for (Map.Entry<List<String>, List<String>> entry : TEST_DATA.entrySet()) {
			List<String> inputResults = entry.getKey();
			List<String> expectedResults = entry.getValue();

			// create the ResponseData instance
			ResponseData responseData = new ResponseData();
			responseData.setResults(new ArrayList<String>(inputResults));

			// do post processing
			ResponseData newResponseData = processor.process(responseData);
			List<String> testResults = newResponseData.getResults();

			assertEquals("results length must match", expectedResults.size(), testResults.size());

			int size = expectedResults.size();
			for (int i = 0; i < size; i++) {
				String expectedResult = expectedResults.get(i);
				String testResult = testResults.get(i);

				Iterator<String> expectedIterator = splitter.split(expectedResult).iterator();
				Iterator<String> testIterator = splitter.split(testResult).iterator();

				for (int j = 0; j < 2; j++) {
					// skip the first two
					expectedIterator.next();
					testIterator.next();
				}

				while (expectedIterator.hasNext() && testIterator.hasNext()) {
					BigDecimal expectedValue = new BigDecimal(expectedIterator.next());
					BigDecimal testValue = new BigDecimal(testIterator.next());

					assertTrue("precision violated (" + count + "): '" + expectedValue + "-"
							+ testValue + "'",
							expectedValue.add(testValue.negate()).compareTo(EPSILON) == -1);
				}
			}
			count++;
		}
	}
}
