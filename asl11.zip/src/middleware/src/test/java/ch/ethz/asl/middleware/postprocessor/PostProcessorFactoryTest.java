/**
 * PostProcessorFactoryTest.java
 */
package ch.ethz.asl.middleware.postprocessor;

import ch.ethz.asl.common.sql.*;
import junit.framework.*;

/**
 * Test suite for the {@link PostProcessorFactory}
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 24, 2011
 */
public class PostProcessorFactoryTest extends TestCase {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Tests that all {@link TpchWorkload} instances are covered
	 */
	public void testAllWorkloadsCovered() {
		// create PostProcessorFactory instance
		PostProcessorFactory factory = new PostProcessorFactory();

		for (TpchWorkload workload : TpchWorkload.values()) {
			assertNotNull("Factory must deliver a valid non null "
					+ "IPostProcessor instance for Workload " + workload.name(),
					factory.create(workload));
		}
	}
}
