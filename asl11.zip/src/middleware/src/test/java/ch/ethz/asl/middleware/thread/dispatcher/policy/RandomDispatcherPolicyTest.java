/**
 * RandomDispatcherPolicyTest.java
 */
package ch.ethz.asl.middleware.thread.dispatcher.policy;

import junit.framework.*;

import org.easymock.*;
import org.junit.Test;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.middleware.thread.dispatcher.*;

/**
 * Test suite for the {@link RandomDispatcherPolicy} implementation
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 20, 2011
 */
public class RandomDispatcherPolicyTest extends TestCase {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	public static final Logger LOGGER = LoggerFactory.getLogger(RandomDispatcherPolicyTest.class);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Tests that the {@link RandomDispatcherPolicy} never exceeds the
	 * boundaries
	 */
	@Test
	public void testDispatcherPolicy() {
		// define the max indexes to lookup from
		int maxIndex = 10;

		// create the Policy
		int seed = 0;
		IDispatcherPolicy policy = new RandomDispatcherPolicy(maxIndex, seed);

		// create a simple Job
		IJob job = EasyMock.createNiceMock(IJob.class);

		final int repetitions = 10 * maxIndex;
		for (int i = 0; i < repetitions; i++) {
			int index = policy.nextIndex(job);
			LOGGER.debug("next chosen index was {}", index);
			assertTrue("Random policy index didn't respect the boundaries", 0 <= index
					&& index < maxIndex);
		}
	}
}
