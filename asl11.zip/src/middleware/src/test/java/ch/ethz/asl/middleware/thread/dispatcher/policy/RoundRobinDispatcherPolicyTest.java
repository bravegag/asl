/**
 * RoundRobinDispatcherPolicyTest.java
 */
package ch.ethz.asl.middleware.thread.dispatcher.policy;

import junit.framework.*;

import org.easymock.*;
import org.junit.Test;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.middleware.thread.dispatcher.*;

/**
 * Test suite for the {@link RoundRobinDispatcherPolicy} implementation
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 20, 2011
 */
public class RoundRobinDispatcherPolicyTest extends TestCase {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	public static final Logger LOGGER = LoggerFactory
			.getLogger(RoundRobinDispatcherPolicyTest.class);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Tests that the {@link RoundRobinDispatcherPolicy} never exceeds the
	 * boundaries and produces the expected sequence.
	 */
	@Test
	public void testDispatcherPolicy() {
		// define the max indexes to lookup from
		int maxIndex = 10;

		// create the Policy
		int seed = 0;
		IDispatcherPolicy policy = new RoundRobinDispatcherPolicy(maxIndex, seed);

		// create a simple Job
		IJob job = EasyMock.createNiceMock(IJob.class);

		Integer[] expectedSequence = new Integer[] { 4, 8, 9, 6, 3, 5, 2, 1, 7, 0 };

		final int repetitions = 10 * maxIndex;
		for (int i = 0; i < repetitions; i++) {
			Integer index = policy.nextIndex(job);
			LOGGER.debug("next chosen index was {}", index);
			assertTrue("Round Robin policy index didn't respect the boundaries", 0 <= index
					&& index < maxIndex);
			assertEquals("Round Robin policy index didn't cycle correctly", expectedSequence[i
					% maxIndex], index);
		}
	}
}
