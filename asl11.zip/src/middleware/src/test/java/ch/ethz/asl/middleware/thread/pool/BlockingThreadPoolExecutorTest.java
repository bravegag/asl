/**
 * BlockingThreadPoolExecutorTest.java
 */
package ch.ethz.asl.middleware.thread.pool;

import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

import junit.framework.*;

import org.junit.Test;

/**
 * Test suite for the {@link BlockingThreadPoolExecutor} implementation
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Nov 9, 2011
 */
public class BlockingThreadPoolExecutorTest extends TestCase {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Tests that jobs are never rejected but rather the calling thread stays
	 * blocked until the others are done
	 */
	@Test
	public void testRejection() {
		final int POOL_SIZE = 3;
		final long FIVE_MINUTES = 300000;

		int corePoolSize = POOL_SIZE;
		int maximumPoolSize = POOL_SIZE;
		int keepAliveTime = Integer.MAX_VALUE;
		TimeUnit unit = TimeUnit.DAYS;
		BlockingQueue<Runnable> workQueue = new ArrayBlockingQueue<Runnable>(POOL_SIZE);

		final BlockingThreadPoolExecutor threadPool = new BlockingThreadPoolExecutor(corePoolSize,
				maximumPoolSize, keepAliveTime, unit, workQueue);

		// keep track of how many jobs are enqueued
		final AtomicInteger count = new AtomicInteger(0);

		// execute POOL_SIZE number of jobs
		for (int i = 0; i < 10*POOL_SIZE; i++) {
			try {
				// emulate a Dispatcher Thread
				new Thread() {
					@Override
					public void run() {
						threadPool.execute(new Runnable() {
							@Override
							public void run() {
								count.incrementAndGet();

								try {
									Thread.sleep(FIVE_MINUTES);
								}
								catch (InterruptedException exception) {
									exception.printStackTrace();
								}
							}
						});
					}

				}.start();
			}
			catch (RejectedExecutionException exception) {
				fail("BlockingThreadPoolExecutor did not block properly");
			}
		}

		while (count.get() < POOL_SIZE) {
			Thread.yield();
		}

		// check count
		assertEquals("BlockingThreadPoolExecutor violates the maximum pool size", POOL_SIZE,
				count.get());
	}
}
