/**
 * DestinationDispatcherPolicyTest.java
 */
package ch.ethz.asl.middleware.thread.dispatcher.policy;

import junit.framework.*;

import org.easymock.*;
import org.junit.Test;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.middleware.thread.dispatcher.*;

/**
 * Test suite for the {@link DestinationDispatcherPolicy} implementation
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 20, 2011
 */
public class DestinationDispatcherPolicyTest extends TestCase {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	public static final Logger LOGGER = LoggerFactory
			.getLogger(DestinationDispatcherPolicyTest.class);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Tests that the {@link DestinationDispatcherPolicy} never exceeds the
	 * boundaries and produces the expected sequence.
	 */
	@Test
	public void testDispatcherPolicy() {
		// define the max indexes to lookup from
		int maxIndex = 10;

		// create the Policy
		IDispatcherPolicy policy = new DestinationDispatcherPolicy(10);

		// create a simple Job
		IJob job = EasyMock.createNiceMock(IJob.class);
		RequestData requestData = EasyMock.createNiceMock(RequestData.class);

		EasyMock.expect(job.getRequestData()).andReturn(requestData);
		EasyMock.expect(requestData.getPartitionIndex(maxIndex)).andReturn(0);

		EasyMock.replay(job);
		EasyMock.replay(requestData);

		int index = policy.nextIndex(job);
		LOGGER.debug("next chosen index was {}", index);
		assertTrue("Destination policy index didn't respect the boundaries", 0 <= index
				&& index < maxIndex);
		assertEquals("Destination policy index didn't produce the correct result", 0, index);
	}
}
