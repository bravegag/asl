/**
 * DbJobProcessor.java
 */
package ch.ethz.asl.middleware.processor;

import java.util.*;

import javax.sql.*;

import org.slf4j.*;
import org.springframework.jdbc.core.namedparam.*;
import org.springframework.transaction.support.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.middleware.thread.*;

/**
 * Defines a {@link Runnable} Job that processes Database {@link Job}. It
 * processes a single {@link RequestData} against one {@link DataSource} where
 * the {@link DataSource} is acquired dynamically from the executing
 * {@link Thread}
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 1, 2011
 */
public class DbJobProcessor extends AbstractDbJobProcessor {
	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(DbJobProcessor.class);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link DbJobProcessor}
	 *
	 * @param job
	 *            The job to process
	 */
	public DbJobProcessor(IJob job) {
		super(job);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void run() {
		IJob job = super.getJob();

		// create the ResponseData
		ResponseData responseData = new ResponseData();

		final RequestData requestData = job.getRequestData();
		LOGGER.debug("running jobId=[{}] type=[{}]", requestData.getId(),
				requestData.isQuery() ? "QUERY" : "REFRESH");
		
		// correlate RequestData and ResponseData
		responseData.setId(requestData.getId());

		try {
			LOGGER.debug("executing workload ...");

			ThreadPerDbConnection threadPerDbConnection = (ThreadPerDbConnection) Thread
					.currentThread();
			NamedParameterJdbcOperations jdbcOperations = threadPerDbConnection.getJdbcOperations();
			TransactionTemplate transactionTemplate = threadPerDbConnection
					.getTransactionTemplate();

			final List<String> results = executeWorkload(requestData, transactionTemplate,
					jdbcOperations);
			responseData.setResults(results);

			LOGGER.debug("workload succeeded");
		}
		catch (Throwable exception) {
			exception.printStackTrace();
			responseData.setError(exception.getMessage());
		}
		finally {
			job.getObserver().update(responseData);
		}
	}
}