/**
 * Middleware.java
 */
package ch.ethz.asl.middleware;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

import javax.sql.*;

import org.slf4j.*;
import org.springframework.beans.factory.config.*;
import org.springframework.beans.factory.xml.*;
import org.springframework.context.*;
import org.springframework.context.support.*;
import org.springframework.core.io.*;
import org.springframework.jdbc.core.namedparam.*;
import org.springframework.transaction.support.*;

import ch.ethz.asl.common.application.*;
import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.classic.*;
import ch.ethz.asl.middleware.Parameter.DispatcherPolicy;
import ch.ethz.asl.middleware.processor.*;
import ch.ethz.asl.middleware.queueprovider.*;
import ch.ethz.asl.middleware.thread.*;
import ch.ethz.asl.middleware.thread.dispatcher.*;
import ch.ethz.asl.middleware.thread.dispatcher.policy.*;
import ch.ethz.asl.middleware.thread.pool.*;

import com.google.common.base.*;
import com.google.common.collect.*;

/**
 * Middleware main entry point
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 */
public final class Middleware extends AbstractMain {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Middleware.class);
	private static final String COMPONENT_NAME = Middleware.class.getSimpleName();
	private static final String THREAD_PER_DB_CONNECTION_FACTORY_BEAN_NAME = "threadPerDbConnectionFactory";
	private static final String XA_OPERATIONS_BEAN_NAME = "xaJdbcOperations";
	private static final String XA_TRANSACTION_TEMPLATE_BEAN_NAME = "xaTransactionTemplate";
	private static final String XA_DATA_SOURCE_BEAN_NAME = "xaDataSource";

	/**
	 * Middleware Id
	 */
	private final Integer middlewareId;

	/**
	 * Number of databases, this is an implicit paramater calculated from
	 * the high multiplicity {@link Parameter#DATABASE_URL}
	 */
	private int numberOfDatabases;

	/**
	 * {@link List} of {@link ThreadPerDbConnectionFactory} instances
	 */
	private final List<ThreadPerDbConnectionFactory> threadPerDbConnectionFactories = Lists
			.newArrayList();

	/**
	 * {@link List} of {@link ThreadMultiDbConnectionsFactory} instance
	 */
	private ThreadMultiDbConnectionsFactory threadMultiDbConnectionsFactory = null;

	/**
	 * Communication {@link IServer}, concrete instance of classic
	 * {@link BlockingIOServer}
	 */
	private final IServer serverService;

	/**
	 * Middleware single {@link BlockingQueue}
	 */
	private BlockingQueue<IJob> jobsQueue = null;

	/**
	 * Collection of {@link ThreadPoolExecutor} instances, one per Database
	 */
	private final List<ThreadPoolExecutor> threadPerDbThreadPools = Lists.newArrayList();

	/**
	 * {@link ThreadPoolExecutor} instance, holding Threads that execute
	 * {@link IJobProcessor} across multiple Databases
	 */
	private ThreadPoolExecutor threadMultiDbThreadPool = null;

	/**
	 * Collection of Dispatcher Threads
	 */
	private final List<DispatcherThread> dispatcherThreads = Lists.newArrayList();

	/**
	 * Shutdown started flag
	 */
	private final AtomicBoolean shutdownStarted = new AtomicBoolean(false);

	/**
	 * Generic {@link ApplicationContext}
	 */
	private final GenericApplicationContext applicationContext = new GenericApplicationContext();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Component startup main
	 *
	 * @param arguments
	 */
	public static void main(String[] arguments) {
		List<Parameter> parameterValues = Arrays.asList(Parameter.values());

		// when all parameters are OK, start the Middleware component
		if (reusableMain(COMPONENT_NAME, parameterValues)) {
			// print component parameters
			printParameters(COMPONENT_NAME, parameterValues);

			LOGGER.debug("starting component ...");
			final Middleware middleware = new Middleware();
			middleware.setupJdbcDataSources();
			middleware.setupServer();

			LOGGER.debug("setting up shutdown hook ...");
			Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
				@Override
				public void run() {
					middleware.shutdownComponent();
				}
			}));

			LOGGER.debug("component started");

			// setup timeout
			long timeout = Long.valueOf(System.getProperty(Parameter.TIMEOUT.getParameter()));
			middleware.setupTimeoutAndWait(timeout);
		}
	}

	// ------------------------------------------------------------------------
	// protected
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link Middleware}
	 */
	public Middleware() {
		middlewareId = Integer.valueOf(System.getProperty(Parameter.ID.getParameter())).
				intValue();
		this.serverService = new BlockingIOServer(middlewareId.toString());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void shutdownComponent() {
		// shutdown only if it hasn't started yet
		if (!shutdownStarted.getAndSet(true)) {
			try {
				LOGGER.debug("started shutdown sequence ...");

				// stop the Server
				serverService.stop();

				// stop the Dispatcher threads
				LOGGER.debug("interrupting all dispacther threads");
				for (DispatcherThread dispatcherThread : dispatcherThreads) {
					dispatcherThread.interrupt();
				}

				// stop all ThreadPerDbConnection instances in
				// threadPerDbThreadPools
				LOGGER.debug("shutting down all threadPerDbThreadPool");
				for (ThreadPoolExecutor threadPerDbThreadPool : threadPerDbThreadPools) {
					threadPerDbThreadPool.shutdownNow();
				}

				// stop the ForkAndJoin Threads
				LOGGER.debug("shutting down threadMultiDbThreadPool");
				threadMultiDbThreadPool.shutdownNow();

				// destroy all non-XA DataSource instances
				LOGGER.debug("destroying all DataSource instances");
				for (ThreadPerDbConnectionFactory threadPerDbConnectionFactory : threadPerDbConnectionFactories) {
					applicationContext.getBeanFactory().destroyBean(
							THREAD_PER_DB_CONNECTION_FACTORY_BEAN_NAME,
							threadPerDbConnectionFactory);
				}

				// destroy all XA DataSource instances
				threadMultiDbConnectionsFactory.destroy();

				// destroy applicationContext
				applicationContext.close();

				LOGGER.debug("shutdown sequence completed");
			}
			catch (Throwable exception) {
				exception.printStackTrace();
				LOGGER.error(exception.getMessage());
				throw new RuntimeException(exception);
			}
		}
	}

	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	/**
	 * Setup the {@link DataSource} instances, one per Database
	 */
	private void setupJdbcDataSources() {
		LOGGER.debug("setting up databases ...");

		String username = System.getProperty(Parameter.DATABASE_USERNAME.getParameter());
		String password = System.getProperty(Parameter.DATABASE_PASSWORD.getParameter());
		String connectionPoolSize = System.getProperty(Parameter.DATABASE_CONNECTION_POOL_SIZE
				.getParameter());
		String maxStatements = System.getProperty(Parameter.DATABASE_MAX_CACHED_STATEMENTS
				.getParameter());
		String urls = System.getProperty(Parameter.DATABASE_URL.getParameter());
		String transactionTimout = System.getProperty(Parameter.TRANSACTION_TIMEOUT
				.getParameter());

		List<NamedParameterJdbcOperations> xaJdbcOperations = Lists.newArrayList();
		List<DataSource> xaDataSources = Lists.newArrayList();
		StringTokenizer tokenizer = new StringTokenizer(urls, ";");
		int uniqueDataSourceId = 1;
		while (tokenizer.hasMoreTokens()) {
			String url = tokenizer.nextToken();
			LOGGER.debug("setting up database: " + url);

			// create new set of properties for each Database
			Properties properties = new Properties();
			properties.setProperty("jdbc.url", url);
			properties.setProperty("jdbc.username", username);
			properties.setProperty("jdbc.password", password);
			properties.setProperty("jdbc.connectionpool.initialSize", connectionPoolSize);
			properties.setProperty("jdbc.connectionpool.minSize", connectionPoolSize);
			properties.setProperty("jdbc.connectionpool.maxSize", connectionPoolSize);
			properties.setProperty("jdbc.connectionpool.maxStatements", maxStatements);
			properties.setProperty("jdbc.transactionTimeout", transactionTimout);

			// need to derive these from
			// "jdbc:postgresql://localhost:11111/tpch"
			List<String> values = Lists.newArrayList(Splitter.on(":").split(
					url.replaceAll("jdbc:postgresql://", "").replaceAll("/", ":")));
			assert (values.size() == 3);

			String serverName = values.get(0);
			String portNumber = values.get(1);
			String databaseName = values.get(2);
			properties.setProperty("jdbc.serverName", serverName);
			properties.setProperty("jdbc.databaseName", databaseName);
			properties.setProperty("jdbc.portNumber", portNumber);
			properties.setProperty("i", String.valueOf(uniqueDataSourceId++));

			XmlBeanDefinitionReader xmlReader = new XmlBeanDefinitionReader(applicationContext);
			xmlReader.loadBeanDefinitions(new ClassPathResource("persistence-context.xml"));

			// bring in property values
			PropertyPlaceholderConfigurer configurer = new PropertyPlaceholderConfigurer();
			configurer.setProperties(properties);

			// get hold of the BeanFactory
			ConfigurableListableBeanFactory beanFactory = applicationContext.getBeanFactory();

			// now actually do the placeholder replacement
			configurer.postProcessBeanFactory(beanFactory);

			// pull a new ThreadPerDbConnectionFactory with all the required
			// persistence configuration
			ThreadPerDbConnectionFactory threadPerDbConnectionFactory = (ThreadPerDbConnectionFactory) beanFactory
					.getBean(THREAD_PER_DB_CONNECTION_FACTORY_BEAN_NAME);
			threadPerDbConnectionFactory.healthCheck(url);
			threadPerDbConnectionFactory.setApplicationContext(applicationContext);

			// one JdbcTemplate corresponds to one Connection of the database
			// ConnectionPool
			threadPerDbConnectionFactories.add(threadPerDbConnectionFactory);

			// pull a XA-jdbcOperations corresponding to this database
			xaJdbcOperations.add((NamedParameterJdbcOperations) beanFactory
					.getBean(XA_OPERATIONS_BEAN_NAME));

			// pull the XA DataSource as well, otherwise can't destroy it
			xaDataSources.add((DataSource) beanFactory.getBean(XA_DATA_SOURCE_BEAN_NAME));
		}

		numberOfDatabases = threadPerDbConnectionFactories.size();

		// get hold of the BeanFactory
		ConfigurableListableBeanFactory beanFactory = applicationContext.getBeanFactory();

		// now setup the threadMultiDbConnectionsFactory
		TransactionTemplate xaTransactionTemplate = (TransactionTemplate) beanFactory
				.getBean(XA_TRANSACTION_TEMPLATE_BEAN_NAME);
		threadMultiDbConnectionsFactory = new ThreadMultiDbConnectionsFactory(xaTransactionTemplate,
				xaDataSources, xaJdbcOperations.toArray(new NamedParameterJdbcOperations[0]));
		threadMultiDbConnectionsFactory.setApplicationContext(applicationContext);

		LOGGER.debug("databases setup done");
	}

	/**
	 * Setup the Server:
	 * <ul>
	 * <li>Setup the Middleware single Jobs Queue ({@link BlockingQueue})</li>
	 * <li>Thread-per-Db Thread Pool: associates Threads with high-performance C3P0 Db Connection
	 * Pool</li>
	 * <li>Thread-Multiple-Db Thread Pool: associates Threads with Atomikos XA Db Connection
	 * Pool</li>
	 * <li>Db Job Processors (non-XA)</li>
	 * <li>Fork-and-Join Job Processors (non-XA)</li>
	 * <li>Multiplexer Db Transaction Job Processor (XA)</li>
	 * <li>Dispatcher Threads: pull {@link IJob} from the single Middleware Jobs Queue
	 * ({@link BlockingQueue})</li>
	 * <li>Blocking IO Server implementation: implementation of the "One-Thread-per-Socket-Connection"
	 * model</li>
	 * </ul>
	 */
	private void setupServer() {
		LOGGER.debug("setting up serverService ...");

		// ------------------------------------------------------------------------
		// Middleware Queue
		// ------------------------------------------------------------------------

		// setup the BlockingQueue, the capacity is a parameter of the Middleware but
		// should be proportional to the number of database servers i.e. to the workload
		// capacity of the system
		int capacity = Integer.valueOf(System.getProperty(Parameter.JOB_QUEUE_CAPACITY
				.getParameter()));
		final boolean UNFAIR = false;
		jobsQueue = new ArrayBlockingQueue<IJob>(capacity, UNFAIR);

		// setup the IQueueProvider required by the IServer
		IQueueProvider<IJob> queueProvider = new SingleBlockingQueue<IJob>(jobsQueue);

		// ------------------------------------------------------------------------
		// Service Thread Pools i.e. associate Threads with Persistence Services
		// ------------------------------------------------------------------------

		// ThreadPoolExecutor Factory
		ThreadPoolExecutorFactory threadPoolExecutorFactory = new ThreadPoolExecutorFactory();

		// setup the threadPerDbThreadPool instances. The number of ThreadPoolExecutor
		// and connections in the ConnectionPool is the same i.e. one Thread per connection
		long keepAliveTime = 1;
		TimeUnit unit = TimeUnit.DAYS;
		int corePoolSize = Integer.valueOf(System.getProperty(Parameter.
				DATABASE_CONNECTION_POOL_SIZE.getParameter())).intValue();
		int maximumPoolSize = corePoolSize;
		for (ThreadPerDbConnectionFactory threadPerDbConnectionFactory : threadPerDbConnectionFactories) {
			BlockingQueue<Runnable> workQueue = new ArrayBlockingQueue<Runnable>(maximumPoolSize, UNFAIR);
			threadPerDbThreadPools.add(threadPoolExecutorFactory.create(corePoolSize,
					maximumPoolSize, keepAliveTime, unit, workQueue, threadPerDbConnectionFactory));
		}

		// setup the threadMultiDbThreadPool with XA support, ThreadPool size equals the
		// ConnectionPool size since we can have at most ConnectionPool size threads
		// spanning XA or Fork-and-Join transactions on those databases
		BlockingQueue<Runnable> workQueue = new ArrayBlockingQueue<Runnable>(maximumPoolSize, UNFAIR);
		threadMultiDbThreadPool = threadPoolExecutorFactory.create(corePoolSize, maximumPoolSize,
				keepAliveTime, unit, workQueue, threadMultiDbConnectionsFactory);

		// ------------------------------------------------------------------------
		// Job Processors i.e. Runnable that execute the logic
		// ------------------------------------------------------------------------

		// setup the ForkAndJoinJobProcessorFactory instance
		ForkAndJoinJobProcessorFactory forkAndJoinJobProcessorFactory = new ForkAndJoinJobProcessorFactory(
				threadPerDbThreadPools);

		// setup the DbJobProcessorFactory instance
		DbJobProcessorFactory dbJobProcessorFactory = new DbJobProcessorFactory();

		// setup the MultiplexerDbTrxJobProcessorFactory
		MultiplexerDbTrxJobProcessorFactory multiplexerDbTrxJobProcessorFactory =
				new MultiplexerDbTrxJobProcessorFactory();

		// finally setup the single entry point for creating IJobProcessor instances
		IJobProcessorFactory<?> jobProcessorFactory = new JobProcessorFactory(
				forkAndJoinJobProcessorFactory, dbJobProcessorFactory,
				multiplexerDbTrxJobProcessorFactory);

		// ------------------------------------------------------------------------
		// Dispatcher Threads i.e. push model from jobsQueue to Service Threads
		// ------------------------------------------------------------------------

		// setup the Dispatcher Threads
		int numberOfDispatcherThreads = Integer.valueOf(
				System.getProperty(Parameter.NUMBER_OF_DISPATCHER_THREADS.getParameter()))
				.intValue();

		// this is critically important since ensures that all Dispatcher threads have different
		// random sequences, so their seeds must be globally unique
		final int uniqueSeedBase = (middlewareId - 1)*numberOfDispatcherThreads;
		Parameter.DispatcherPolicy policy = DispatcherPolicy.valueOf(System.getProperty(Parameter.
				DISPATCHER_POLICY.getParameter()));
		for (int i = 0; i < numberOfDispatcherThreads; i++) {
			int uniqueSeed = uniqueSeedBase + (i + 1);
			LOGGER.debug("seed set for RandomDispatcherPolicy middleware=[{}] dispatcher=[{}] seed=[{}]",
					new Object[] {middlewareId, i, uniqueSeed});
			IDispatcherPolicy anyDispatcherPolicy = (policy == Parameter.DispatcherPolicy.RANDOM)
				? new RandomDispatcherPolicy(numberOfDatabases, uniqueSeed)
				: new RoundRobinDispatcherPolicy(numberOfDatabases, uniqueSeed);
			DestinationDispatcherPolicy destinationDispatcherPolicy = new DestinationDispatcherPolicy(numberOfDatabases);
			String dispatcherId = String.valueOf(i + 1);
			dispatcherThreads.add(new DispatcherThread(jobsQueue, anyDispatcherPolicy,
					destinationDispatcherPolicy, threadPerDbThreadPools, threadMultiDbThreadPool,
					jobProcessorFactory, dispatcherId));
		}

		// start the Server
		int port = Integer.valueOf(System.getProperty(Parameter.LISTENING_PORT.getParameter()));
		serverService.start(port, queueProvider);

		// start dispatcher threads
		for (Thread dispatcherThread : dispatcherThreads) {
			dispatcherThread.start();
		}

		LOGGER.debug("serverService setup done");
	}
}
