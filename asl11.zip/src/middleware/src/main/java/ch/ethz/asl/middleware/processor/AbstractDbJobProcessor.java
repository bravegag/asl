/**
 * AbstractDbJobProcessor.java
 */
package ch.ethz.asl.middleware.processor;

import java.sql.*;
import java.util.*;

import org.apache.commons.lang.*;
import org.slf4j.*;
import org.springframework.jdbc.core.*;
import org.springframework.jdbc.core.namedparam.*;
import org.springframework.transaction.*;
import org.springframework.transaction.support.*;

import com.google.common.collect.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.common.sql.*;

/**
 * Abstract base reusable partial implementation of {@link IJobProcessor}
 * offering reusable database access method. This implementation is generic i.e.
 * capable of generically handling any type of QUERY or REFRESH function.
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 18, 2011
 */
public abstract class AbstractDbJobProcessor implements IJobProcessor {
	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractDbJobProcessor.class);
	private static final String SEPARATOR = "|";

	/**
	 * {@link Job} to process
	 */
	private final IJob job;

	/**
	 * Reusable and Thread-local {@link StringBuilder} instance
	 */
	private static final ThreadLocal<StringBuilder> STRING_BUILDER = new ThreadLocal<StringBuilder>();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link AbstractDbJobProcessor}
	 *
	 * @param job
	 *            The job to process
	 */
	public AbstractDbJobProcessor(IJob job) {
		Validate.notNull(job, "'job' must not be null");

		this.job = job;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	final public IJob getJob() {
		return job;
	}

	// ------------------------------------------------------------------------
	// protected
	// ------------------------------------------------------------------------
	/**
	 * Returns the results of executing the workload contained in the
	 * {@link RequestData}. Important! this workload is executed as one
	 * transaction and it is reusable for XA and for non-XA transactions that's
	 * why it must be admitted that it looks a bit complicated.
	 *
	 * @param requestData
	 *            The {@link RequestData} containing the workload
	 * @param transactionTemplate
	 *            The {@link TransactionTemplate}
	 * @param jdbcOperations
	 *            The {@link JdbcOperations} instances
	 * @return the results of executing the workload contained in the
	 *         {@link RequestData}
	 */
	protected List<String> executeWorkload(final RequestData requestData,
			TransactionTemplate transactionTemplate,
			final NamedParameterJdbcOperations... jdbcOperations) {
		Validate.notNull(requestData, "'requestData' must not be null");
		Validate.notNull(jdbcOperations, "'jdbcOperations' must not be null");

		LOGGER.debug("running jobId=[{}] type=[{}]", requestData.getId(),
				requestData.isQuery() ? "QUERY" : "REFRESH");

		// results List
		final List<String> results = Lists.newArrayList();

		// reusable Thread-safe StringBuilder instance
		if (STRING_BUILDER.get() == null) {
			STRING_BUILDER.set(new StringBuilder());
		}
		final StringBuilder builder = STRING_BUILDER.get();
		builder.setLength(0);

		// execute the full Workload within a transaction
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				try {
					final List<RequestDataItem> parameters = requestData.getParameters();

					// for every database ...
					for (NamedParameterJdbcOperations jdbcOperation : jdbcOperations) {

						// for every DML part of this requestData unit
						for (RequestDataItem requestDataItem : parameters) {
							final TpchWorkload workload = requestDataItem.getWorkload();
							final Map<String, Object> arguments = requestDataItem.getArguments();
							final String sql = requestData.getWorkload().get(workload);

							LOGGER.debug("{}", sql);
							LOGGER.debug("{}", arguments);

							if (workload.isQuery()) {
								results.addAll(jdbcOperation.query(sql, new MapSqlParameterSource(
										arguments), new RowMapper<String>() {
									// ---------------------------------------------------
									private Integer columnCount = null;

									// ---------------------------------------------------
									public String mapRow(ResultSet resultSet, int row)
											throws SQLException {
										if (columnCount == null) {
											ResultSetMetaData metadata = resultSet.getMetaData();
											columnCount = metadata.getColumnCount();
										}

										// read the current row
										builder.setLength(0);
										for (int i = 1; i <= columnCount; i++) {
											builder.append(resultSet.getString(i));

											// skip the end
											if (i < columnCount) {
												builder.append(SEPARATOR);
											}
										}

										return builder.toString();
									}
								}));
							}
							else {
								assert (!workload.isQuery());

								// for every ocurrence of the same refresh
								builder.setLength(0);
								int rowsAffected = jdbcOperation.update(sql,
										new MapSqlParameterSource(arguments));
								builder.append('\'');
								builder.append(String.valueOf(rowsAffected));
								builder.append("' rows affected");
								results.add(builder.toString());
							}
						}
					}
				}
				catch (Throwable exception) {
					// rollback on exceptions
					status.setRollbackOnly();

					throw new RuntimeException(exception);
				}
			}
		});

		return results;
	}
}
