/**
 * DbJobProcessorFactory.java
 */
package ch.ethz.asl.middleware.processor;

import ch.ethz.asl.common.remoting.*;

/**
 * Concrete {@link IJobProcessorFactory} implementation that creates instances
 * of {@link DbJobProcessor}
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 5, 2011
 */
public class DbJobProcessorFactory extends AbstractJobProcessorFactory<DbJobProcessor> implements
		IJobProcessorFactory<DbJobProcessor> {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * {@inheritDoc}
	 */
	@Override
	public DbJobProcessor create(IJob job) {
		return new DbJobProcessor(job);
	}
}
