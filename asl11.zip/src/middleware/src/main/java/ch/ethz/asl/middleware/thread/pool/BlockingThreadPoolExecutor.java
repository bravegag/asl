/**
 * BlockingThreadPoolExecutor.java
 */
package ch.ethz.asl.middleware.thread.pool;

import java.util.concurrent.*;

import org.slf4j.*;

import ch.ethz.asl.middleware.processor.*;

/**
 * Concrete {@link ThreadPoolExecutor} subclass that blocks caller thread on the
 * {@link #execute(Runnable)} when all Threads are busy
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 17, 2011
 */
public class BlockingThreadPoolExecutor extends ThreadPoolExecutor {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BlockingThreadPoolExecutor.class);
	private static final boolean UNFAIR = false;
	private static final long NANO_TO_MILLISECONDS = 1000000;

	/**
	 * The Semaphore used to block incoming {@link #execute(Runnable)} requests
	 * when the {@link ThreadPoolExecutor} is saturated
	 */
	private final Semaphore semaphore;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor of {@link BlockingThreadPoolExecutor}
	 *
	 * @param corePoolSize
	 * @param maximumPoolSize
	 * @param keepAliveTime
	 * @param unit
	 * @param workQueue
	 */
	public BlockingThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime,
			TimeUnit unit, BlockingQueue<Runnable> workQueue) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue,
				new NullRejectionPolicy());
		semaphore = new Semaphore(maximumPoolSize, UNFAIR);
	}

	/**
	 * Constructor of {@link BlockingThreadPoolExecutor}
	 *
	 * @param corePoolSize
	 * @param maximumPoolSize
	 * @param keepAliveTime
	 * @param unit
	 * @param workQueue
	 * @param threadFactory
	 */
	public BlockingThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime,
			TimeUnit unit, BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, threadFactory,
				new NullRejectionPolicy());
		semaphore = new Semaphore(maximumPoolSize, UNFAIR);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void execute(Runnable runnable) {
		LOGGER.debug("{} permits available", semaphore.availablePermits());
		LOGGER.debug("attempting to acquire ...");
		semaphore.acquireUninterruptibly();
		LOGGER.debug("attempt to acquire succeeded");
		LOGGER.debug("{} permits available", semaphore.availablePermits());

		if (IJobProcessor.class.isAssignableFrom(runnable.getClass())) {
			IJobProcessor jobProcessor = (IJobProcessor) runnable;
			String jobId = jobProcessor.getJob().getRequestData().getId();
			long currentTime = System.nanoTime();
			currentTime /= NANO_TO_MILLISECONDS;

			LOGGER.info("executing jobId=[{}] time=[{}]", jobId, currentTime);
		}

		super.execute(runnable);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void afterExecute(Runnable runnable, Throwable throwable) {
		super.afterExecute(runnable, throwable);

		semaphore.release();
		LOGGER.debug("released");
		LOGGER.debug("{} permits available", semaphore.availablePermits());
	}

	// ------------------------------------------------------------------------
	// inner classes
	// ------------------------------------------------------------------------
	/**
	 * Do nothing {@link RejectedExecutionHandler} implementation, basically
	 * lets the calling Thread go in and then it will block in the semaphore
	 */
	private static class NullRejectionPolicy implements RejectedExecutionHandler {
		/**
		 * {@inheritDoc}
		 */
		@Override
		public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPool) {
			// do nothing
		}
	}
}