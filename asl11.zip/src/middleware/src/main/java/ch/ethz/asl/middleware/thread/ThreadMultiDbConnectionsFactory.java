/**
 * ThreadMultiDbConnectionsFactory.java
 */
package ch.ethz.asl.middleware.thread;

import java.util.*;
import java.util.concurrent.*;

import javax.sql.*;

import org.apache.commons.lang.*;
import org.slf4j.*;
import org.springframework.beans.*;
import org.springframework.beans.factory.config.*;
import org.springframework.context.*;
import org.springframework.context.support.*;
import org.springframework.jdbc.core.namedparam.*;
import org.springframework.transaction.support.*;

import com.google.common.collect.*;

/**
 * Concrete {@link ThreadFactory} implementation that creates
 * ThreadMultiDbConnections instances.
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 1, 2011
 */
public class ThreadMultiDbConnectionsFactory implements ThreadFactory, ApplicationContextAware {
	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ThreadMultiDbConnectionsFactory.class);
	private static final String XA_DATA_SOURCE_BEAN_NAME = "xaDataSource";

	/**
	 * {@link NamedParameterJdbcOperations} instances associated with this
	 * {@link ThreadFactory}
	 */
	private final NamedParameterJdbcOperations[] jdbcOperations;

	/**
	 * {@link DataSource} instances associated with this {@link ThreadFactory}
	 */
	private final List<DataSource> dataSources = Lists.newArrayList();

	/**
	 * {@link TransactionTemplate} instance associated with this
	 * {@link ThreadFactory}
	 */
	private final TransactionTemplate transactionTemplate;

	/**
	 * The {@link GenericApplicationContext} instance
	 */
	private GenericApplicationContext applicationContext;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor for {@link ThreadMultiDbConnectionsFactory}
	 * 
	 * @param transactionTemplate
	 *            The {@link TransactionTemplate} instance corresponding to one
	 *            single database instance
	 * @param jdbcOperations
	 *            The {@link NamedParameterJdbcOperations} instance
	 *            corresponding to one single database instance
	 */
	public ThreadMultiDbConnectionsFactory(TransactionTemplate transactionTemplate,
			List<DataSource> dataSources, NamedParameterJdbcOperations... jdbcOperations) {
		Validate.notNull(transactionTemplate, "'transactionTemplate' must not be null");
		Validate.notEmpty(dataSources, "'transactionTemplate' must not be null nor empty");
		Validate.notEmpty(jdbcOperations, "'jdbcOperations' must not be null nor empty");

		this.transactionTemplate = transactionTemplate;
		this.dataSources.addAll(dataSources);
		this.jdbcOperations = jdbcOperations;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Thread newThread(Runnable runnable) {
		LOGGER.debug("creating new ThreadMultiDbConnections");

		// create an additional Thread with a correponding JdbcTemplate instance
		Thread processorThread = new ThreadMultiDbConnections(runnable, transactionTemplate,
				jdbcOperations);

		return processorThread;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		LOGGER.debug("setting applicationContext ...");
		this.applicationContext = (GenericApplicationContext) applicationContext;
		LOGGER.debug("applicationContext set");
	}

	/**
	 * Destroy all the XA {@link DataSource} instances
	 */
	public void destroy() {
		assert (applicationContext != null);

		ConfigurableListableBeanFactory beanFactory = applicationContext.getBeanFactory();
		for (DataSource dataSource : dataSources) {
			LOGGER.debug("destroying {} explicitly ...", dataSource);
			try {
				beanFactory.destroyBean(XA_DATA_SOURCE_BEAN_NAME, dataSource);
				LOGGER.debug("dataSource {} destroyed", XA_DATA_SOURCE_BEAN_NAME);
			}
			catch (Throwable exception) {
				exception.printStackTrace();
			}
		}
	}
}