/**
 * IJobProcessorFactory.java
 */
package ch.ethz.asl.middleware.processor;

import java.util.concurrent.*;

import org.perfectjpattern.core.api.creational.factorymethod.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.classic.*;

/**
 * Defines a {@link IFactoryMethod} that creates Job Processors for easier
 * integration with the Executor framework which takes a {@link BlockingQueue}
 * of {@link Runnable} jobs rather than jobs.
 * <br/>
 * <br/>
 *
 * <b>IMPORTANT:</b> Implementations of this interface MUST be stateless, as this
 * same instance is concurrently accessed by multiple {@link ThreadPerClientSocket}
 * running instances.
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 1, 2011
 */
public interface IJobProcessorFactory<JP extends IJobProcessor> extends IFactoryMethod<JP> {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
    /**
     * Returns newly created instance
     *
	 * @param job The {@link Job} to set
     * @return Newly created instance
     */
    public JP create(IJob job);
}
