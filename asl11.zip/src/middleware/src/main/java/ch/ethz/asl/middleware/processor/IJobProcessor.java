/**
 * IJobProcessor.java
 */
package ch.ethz.asl.middleware.processor;

import ch.ethz.asl.common.remoting.*;

/**
 * Abstract definition of {@link Runnable} that processes {@link Job}
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 5, 2011
 */
public interface IJobProcessor extends Runnable {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Returns the {@link IJob}
	 *
	 * @return the {@link IJob}
	 */
	public IJob getJob();
}
