/**
 * JobProcessorFactory.java
 */
package ch.ethz.asl.middleware.processor;

import org.apache.commons.lang.*;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.sql.*;
import ch.ethz.asl.middleware.*;
import ch.ethz.asl.middleware.Parameter.PartitioningMode;

/**
 * Concrete {@link IJobProcessorFactory} implementation that creates different
 * Jobs depending on the current configuration.
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 10, 2011
 */
public class JobProcessorFactory extends AbstractJobProcessorFactory<IJobProcessor> {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(JobProcessorFactory.class);

	private final ForkAndJoinJobProcessorFactory forkAndJoinJobProcessorFactory;
	private final DbJobProcessorFactory dbJobProcessorFactory;
	private final MultiplexerDbTrxJobProcessorFactory multiplexerDbTrxJobProcessorFactory;
	private final PartitioningMode partitioningMode;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link JobProcessorFactory}
	 * 
	 * @param forkAndJoinJobProcessorFactory
	 * @param dbJobProcessorFactory
	 */
	public JobProcessorFactory(ForkAndJoinJobProcessorFactory forkAndJoinJobProcessorFactory,
			DbJobProcessorFactory dbJobProcessorFactory,
			MultiplexerDbTrxJobProcessorFactory multiplexerDbTrxJobProcessorFactory) {
		Validate.notNull(forkAndJoinJobProcessorFactory,
				"'forkAndJoinJobProcessorFactory' must not be null");
		Validate.notNull(dbJobProcessorFactory, "'dbJobProcessorFactory' must not be null");
		Validate.notNull(multiplexerDbTrxJobProcessorFactory,
				"'multiplexerDbTrxJobProcessorFactory' must not be null");

		this.forkAndJoinJobProcessorFactory = forkAndJoinJobProcessorFactory;
		this.dbJobProcessorFactory = dbJobProcessorFactory;
		this.multiplexerDbTrxJobProcessorFactory = multiplexerDbTrxJobProcessorFactory;

		this.partitioningMode = PartitioningMode.valueOf(System
				.getProperty(Parameter.PARTITIONING_MODE.getParameter()));

		LOGGER.debug("running in '" + partitioningMode + "' mode");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public IJobProcessor create(IJob job) {
		IJobProcessorFactory<?> jobProcessorFactory = null;

		// conditions to choose one Job Processor type over another
		TpchWorkload.Type type = job.getRequestData().getWorkload().keySet().iterator().next()
				.getType();
		if (PartitioningMode.REPLICATION == partitioningMode) {
			// REPLICATION
			if (type == TpchWorkload.Type.QUERY) {
				// REPLICATION + QUERY
				job.setDestination(IJob.Destination.ANY);
				jobProcessorFactory = dbJobProcessorFactory;

			}
			else {
				// XA REPLICATION + UPDATE
				assert (type != TpchWorkload.Type.QUERY);
				job.setDestination(IJob.Destination.ALL);
				jobProcessorFactory = multiplexerDbTrxJobProcessorFactory;
			}
		}
		else {
			// SHARDING
			if (type == TpchWorkload.Type.QUERY) {
				// SHARDING + QUERY
				job.setDestination(IJob.Destination.ALL);
				jobProcessorFactory = forkAndJoinJobProcessorFactory;

			}
			else if (type == TpchWorkload.Type.INSERT) {
				// SHARDING + INSERT
				job.setDestination(IJob.Destination.SPECIFIC);
				jobProcessorFactory = dbJobProcessorFactory;

			}
			else if (type == TpchWorkload.Type.DELETE || type == TpchWorkload.Type.UPDATE) {
				// SHARDING + (DELETE || UPDATE)
				job.setDestination(IJob.Destination.ALL);
				jobProcessorFactory = forkAndJoinJobProcessorFactory;

			}
			else {
				throw new UnsupportedOperationException("Unknown TpchWorload Type");
			}
		}

		assert (jobProcessorFactory != null);

		return jobProcessorFactory.create(job);
	}
}
