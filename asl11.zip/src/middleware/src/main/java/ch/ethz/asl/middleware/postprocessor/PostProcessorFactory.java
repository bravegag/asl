/**
 * PostProcessorFactory.java
 */
package ch.ethz.asl.middleware.postprocessor;

import org.perfectjpattern.core.api.creational.factorymethod.*;

import ch.ethz.asl.common.sql.*;

import com.google.common.collect.*;

/**
 * Concrete {@link IFactoryMethod} implementation that creates instances of
 * {@link IPostProcessor}
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 24, 2011
 */
public class PostProcessorFactory implements IFactoryMethod<IPostProcessor> {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private final static ImmutableMap<TpchWorkload, IPostProcessor> POST_PROCESSORS = new ImmutableMap.Builder<TpchWorkload, IPostProcessor>()
			.put(TpchWorkload.QUERY_1, new Query1PostProcessor())
			.put(TpchWorkload.REFRESH_1_1, new Query1PostProcessor())
			.put(TpchWorkload.REFRESH_1_2, new NullPostProcessor())
			.put(TpchWorkload.REFRESH_2_1, new NullPostProcessor())
			.put(TpchWorkload.REFRESH_2_2, new NullPostProcessor()).build();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * {@inheritDoc}
	 */
	@Override
	public IPostProcessor create() {
		throw new UnsupportedOperationException(
				"The Factory requires the TpchWorkload to process in a Stateless fashion");
	}

	/**
	 * Returns the corresponding {@link IPostProcessor} implementation
	 *
	 * @param workload
	 * @return the corresponding {@link IPostProcessor} implementation
	 */
	public IPostProcessor create(TpchWorkload workload) {
		return POST_PROCESSORS.get(workload);
	}
}
