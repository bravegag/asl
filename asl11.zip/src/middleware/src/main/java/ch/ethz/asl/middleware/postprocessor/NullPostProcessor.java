/**
 * NullPostProcessor.java
 */
package ch.ethz.asl.middleware.postprocessor;

import ch.ethz.asl.common.remoting.dto.*;

/**
 * Default {@link IPostProcessor} implementation that does nothing
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 24, 2011
 */
public class NullPostProcessor implements IPostProcessor {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * {@inheritDoc}
	 */
	@Override
	public ResponseData process(ResponseData responseData) {
		return responseData;
	}
}
