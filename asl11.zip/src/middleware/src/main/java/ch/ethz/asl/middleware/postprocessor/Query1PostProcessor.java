/**
 * Query1PostProcessor.java
 */
package ch.ethz.asl.middleware.postprocessor;

import java.math.*;
import java.util.*;

import org.slf4j.*;

import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.common.sql.*;

import com.google.common.base.*;
import com.google.common.collect.*;

/**
 * Post-processes the {@link ResponseData} from {@link TpchWorkload#QUERY_1}
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 24, 2011
 */
public class Query1PostProcessor implements IPostProcessor {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory.getLogger(Query1PostProcessor.class);
	private static final ThreadLocal<Map<String, String>> GROUP_BY = new ThreadLocal<Map<String, String>>();
	private static final String SEPARATOR = "|";

	/**
	 * TPC-H clause 2.1.3.5, page 23 specifies precision for AVG aggregates:
	 * 0.99*v <= round(r,2) <= 1.01*v
	 */
	private static final int AVG_SCALE = 5;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * {@inheritDoc}
	 */
	@Override
	public ResponseData process(ResponseData responseData) {
		// make sure we have a valid groupBy map
		Map<String, String> groupBy = GROUP_BY.get();
		if (groupBy == null) {
			groupBy = Maps.newHashMap();
			GROUP_BY.set(groupBy);
		}
		groupBy.clear();

		// do things in the laziest and stingiest possible way
		List<String> results = responseData.getResults();
		for (String current : results) {
			Iterator<String> iterator = Splitter.on(SEPARATOR).split(current).iterator();
			String returnflag = iterator.next();
			String linestatus = iterator.next();
			String key = returnflag + linestatus;

			String existing = groupBy.get(key);
			if (existing == null) {
				groupBy.put(key, current);
			}
			else {
				String merged = merge(returnflag, linestatus, iterator, existing);
				// overwrite previous
				groupBy.put(key, merged);
			}
		}

		results.clear();
		results.addAll(groupBy.values());
		Collections.sort(results);

		return responseData;
	}

	/**
	 * Returns the merged row
	 *
	 * @param returnflag
	 * @param linestatus
	 * @param iterator
	 * @param existing
	 * @return the merged row
	 */
	private String merge(String returnflag, String linestatus, Iterator<String> iterator,
			String existing) {
		BigDecimal sum_qty = BigDecimal.valueOf(Double.valueOf(iterator.next()));
		BigDecimal sum_base_price = BigDecimal.valueOf(Double.valueOf(iterator.next()));
		BigDecimal sum_disc = BigDecimal.valueOf(Double.valueOf(iterator.next()));
		BigDecimal sum_disc_price = BigDecimal.valueOf(Double.valueOf(iterator.next()));
		BigDecimal sum_charge = BigDecimal.valueOf(Double.valueOf(iterator.next()));
		// skip 3 averages
		iterator.next();
		iterator.next();
		iterator.next();
		BigDecimal count_order = BigDecimal.valueOf(Double.valueOf(iterator.next()));

		// parse existing
		iterator = Splitter.on(SEPARATOR).split(existing).iterator();

		// skip returnflag and linestatus
		iterator.next();
		iterator.next();
		BigDecimal existingSum_qty = BigDecimal.valueOf(Double.valueOf(iterator.next()));
		BigDecimal existingSum_base_price = BigDecimal.valueOf(Double.valueOf(iterator.next()));
		BigDecimal existingSum_disc = BigDecimal.valueOf(Double.valueOf(iterator.next()));
		BigDecimal existingSum_disc_price = BigDecimal.valueOf(Double.valueOf(iterator.next()));
		BigDecimal existingSum_charge = BigDecimal.valueOf(Double.valueOf(iterator.next()));
		// skip 3 averages
		iterator.next();
		iterator.next();
		iterator.next();
		BigDecimal existingCount_order = BigDecimal.valueOf(Double.valueOf(iterator.next()));

		Joiner joiner = Joiner.on(SEPARATOR);
		return joiner.join(
				returnflag,
				linestatus,
				sum_qty.add(existingSum_qty),
				sum_base_price.add(existingSum_base_price),
				sum_disc.add(existingSum_disc),
				sum_disc_price.add(existingSum_disc_price),
				sum_charge.add(existingSum_charge),
				sum_qty.add(existingSum_qty).divide(count_order.add(existingCount_order),
						AVG_SCALE, BigDecimal.ROUND_HALF_UP),
				sum_base_price.add(existingSum_base_price).divide(
						count_order.add(existingCount_order), AVG_SCALE, BigDecimal.ROUND_HALF_UP),
				sum_disc.add(existingSum_disc).divide(count_order.add(existingCount_order),
						AVG_SCALE, BigDecimal.ROUND_HALF_UP), count_order.add(existingCount_order));
	}
}
