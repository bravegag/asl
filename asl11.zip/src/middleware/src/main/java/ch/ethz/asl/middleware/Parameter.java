/**
 * Parameter.java
 */
package ch.ethz.asl.middleware;

import java.sql.*;
import java.util.concurrent.*;

import ch.ethz.asl.common.application.*;

/**
 * Defines the Middleware component parameters with default (example) values.
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 */
public enum Parameter implements IParameter {
	/**
	 * Every Middleware has its identification number. "1" corresponds _ALWAYS_
	 * to the Update Middleware
	 */
	ID("5"),
	/**
	 * For how long shall the Middleware component run (in minutes)
	 */
	TIMEOUT("5"),
	/**
	 * Port to listen to
	 */
	LISTENING_PORT("6666"),
	/**
	 * Username to connect to the database
	 */
	DATABASE_USERNAME("tpch"),
	/**
	 * Password to connect to the database
	 */
	DATABASE_PASSWORD("12345"),
	/**
	 * Semicolon separated list of database URL
	 */
	DATABASE_URL("jdbc:postgresql://localhost:5432/tpch01;jdbc:postgresql://localhost:5432/tpch02"),
	/**
	 * Maximum database pool size
	 */
	DATABASE_CONNECTION_POOL_SIZE("5"),
	/**
	 * Maximum cached {@link PreparedStatement} instances, depends on how many
	 * query types we are supporting
	 */
	DATABASE_MAX_CACHED_STATEMENTS("50"),
	/**
	 * 'REPLICATION' for Full Replication 'SHARDING' for Sharding
	 */
	PARTITIONING_MODE(PartitioningMode.REPLICATION.name()),
	/**
	 * Number of Dispatcher Threads
	 */
	NUMBER_OF_DISPATCHER_THREADS("10"),
	/**
	 * Dispatcher Policy 'RANDOM' or 'ROUND_ROBIN'
	 */
	DISPATCHER_POLICY(DispatcherPolicy.RANDOM.name()),
	/**
	 * Capacity of the Job {@link BlockingQueue}
	 */
	JOB_QUEUE_CAPACITY("10"),
	/**
	 * Path to store log files (relative to current directory)
	 */
	LOG_DIRECTORY("logs"),
	/**
	 * Transaction timeout in seconds for all operations
	 */
	TRANSACTION_TIMEOUT("300");

	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private final String example;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	@Override
	public String getExample() {
		return example;
	}

	@Override
	public String getParameter() {
		return name().toLowerCase();
	}

	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	private Parameter(String example) {
		this.example = example;
	}

	/**
	 * Dispather {@link Thread} policy
	 */
	public static enum DispatcherPolicy {
		ROUND_ROBIN, RANDOM
	};

	/**
	 * Partitioning Mode
	 */
	public static enum PartitioningMode {
		REPLICATION, SHARDING
	};
}
