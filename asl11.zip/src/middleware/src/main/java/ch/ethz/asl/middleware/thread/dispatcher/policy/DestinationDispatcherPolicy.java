/**
 * DestinationDispatcherPolicy.java
 */
package ch.ethz.asl.middleware.thread.dispatcher.policy;

import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.middleware.thread.dispatcher.*;

/**
 * Concrete {@link IDispatcherPolicy} that looks up the right Database instance
 * for a given {@link IJob}
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 13, 2011
 */
public class DestinationDispatcherPolicy extends AbstractDispatcherPolicy {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory.getLogger(DestinationDispatcherPolicy.class);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor for instances of {@link DestinationDispatcherPolicy}
	 * 
	 * @param maxIndex
	 */
	public DestinationDispatcherPolicy(int maxIndex) {
		super(maxIndex);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int nextIndex(IJob job) {
		int nextIndex = job.getRequestData().getPartitionIndex(getMaxIndex());

		return nextIndex;
	}
}
