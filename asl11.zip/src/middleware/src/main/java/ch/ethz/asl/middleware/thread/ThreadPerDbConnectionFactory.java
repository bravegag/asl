/**
 * ThreadPerDbConnectionFactory.java
 */
package ch.ethz.asl.middleware.thread;

import java.util.concurrent.*;

import javax.sql.*;

import org.apache.commons.lang.*;
import org.slf4j.*;
import org.springframework.beans.*;
import org.springframework.context.*;
import org.springframework.context.support.*;
import org.springframework.jdbc.core.namedparam.*;
import org.springframework.transaction.support.*;

/**
 * Concrete {@link ThreadFactory} implementation that creates
 * ThreadPerDbConnection instances.
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 1, 2011
 */
public class ThreadPerDbConnectionFactory implements ThreadFactory, ApplicationContextAware {
	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ThreadPerDbConnectionFactory.class);
	private static final String HEALTH_CHECK_QUERY = "select count(*) from orders";
	private static final String DATA_SOURCE_BEAN_NAME = "dataSource";

	/**
	 * {@link NamedParameterJdbcOperations} instance associated with this
	 * {@link ThreadFactory}
	 */
	private final NamedParameterJdbcOperations jdbcOperations;

	/**
	 * {@link TransactionTemplate} instance associated with this
	 * {@link ThreadFactory}
	 */
	private final TransactionTemplate transactionTemplate;

	/**
	 * {@link DataSource} instance associated with this {@link ThreadFactory}
	 * note that this is only kept for destroying the DataSource explicitly
	 */
	private final DataSource dataSource;

	/**
	 * The {@link GenericApplicationContext} instance
	 */
	private GenericApplicationContext applicationContext;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor for {@link ThreadPerDbConnectionFactory}
	 * 
	 * @param transactionTemplate
	 *            The {@link TransactionTemplate} instance corresponding to one
	 *            single database instance
	 * @param dataSource
	 *            The {@link DataSource} instance corresponding to one single
	 *            database instance
	 * @param jdbcOperations
	 *            The {@link NamedParameterJdbcOperations} instance
	 *            corresponding to one single database instance
	 */
	public ThreadPerDbConnectionFactory(TransactionTemplate transactionTemplate, DataSource dataSource,
			NamedParameterJdbcOperations jdbcOperations) {
		Validate.notNull(transactionTemplate, "'transactionTemplate' must not be null");
		Validate.notNull(dataSource, "'dataSource' must not be null");
		Validate.notNull(jdbcOperations, "'jdbcOperations' must not be null");

		this.transactionTemplate = transactionTemplate;
		this.dataSource = dataSource;
		this.jdbcOperations = jdbcOperations;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Thread newThread(Runnable runnable) {
		LOGGER.debug("creating new ThreadPerDbConnection");

		// create an additional Thread with a correponding JdbcTemplate instance
		Thread processorThread = new ThreadPerDbConnection(runnable, transactionTemplate,
				jdbcOperations);

		return processorThread;
	}

	/**
	 * Executes a health check against the underlying configured Database
	 * 
	 * @param url
	 *            The url used for better description in the Exception only i.e.
	 *            in case the health check test should fail
	 */
	public void healthCheck(String url) {
		// do a database health check
		try {
			int count = jdbcOperations.getJdbcOperations().queryForInt(HEALTH_CHECK_QUERY);
			if (count == 0) {
				throw new IllegalArgumentException("database '" + url + "' contains no orders");
			}
			LOGGER.debug("database contains {} records", count);
		}
		catch (Throwable exception) {
			exception.printStackTrace();
			throw new RuntimeException("database '" + url + "' has a problem.", exception);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		LOGGER.debug("setting applicationContext ...");
		this.applicationContext = (GenericApplicationContext) applicationContext;
		LOGGER.debug("applicationContext set");
	}

	/**
	 * Destroys this {@link ThreadPerDbConnectionFactory} instance
	 */
	public void destroy() {
		assert (applicationContext != null);

		LOGGER.debug("destroying dataSource explicitly ...");
		applicationContext.getBeanFactory().destroyBean(DATA_SOURCE_BEAN_NAME, dataSource);
		LOGGER.debug("dataSource destroyed");
	}
}