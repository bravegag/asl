/**
 * IDispatcherPolicy.java
 */
package ch.ethz.asl.middleware.thread.dispatcher;

import ch.ethz.asl.common.remoting.*;

/**
 * Abstract definition of distribution policy
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 12, 2011
 */
public interface IDispatcherPolicy {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Returns the next index according to this dispatcher policy
	 *
	 * @param job The {@link IJob} at hand to process
	 * @return the next index according to this dispatcher policy
	 */
	public int nextIndex(IJob job);
}
