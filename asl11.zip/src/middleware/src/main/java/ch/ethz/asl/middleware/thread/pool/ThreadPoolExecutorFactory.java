/**
 * ThreadPoolExecutorFactory.java
 */
package ch.ethz.asl.middleware.thread.pool;

import java.util.concurrent.*;

import org.perfectjpattern.core.api.creational.factorymethod.*;

/**
 * Concrete {@link IFactoryMethod} implementation that creates instances of
 * {@link ThreadPoolExecutor}. Allows globally switching the concrete
 * {@link ThreadPoolExecutor} subclass instances used Middleware-wise.
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Nov 6, 2011
 */
public class ThreadPoolExecutorFactory implements IFactoryMethod<ThreadPoolExecutor> {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * {@inheritDoc}
	 */
	@Override
	public ThreadPoolExecutor create() {
		throw new UnsupportedOperationException(
				"The Factory requires the ThreadPoolExecutor parameters in a Stateless fashion");
	}

	/**
	 * Returns a new instance of the appropriate {@link ThreadPoolExecutor}
	 * subclass
	 *
	 * @param corePoolSize
	 * @param maximumPoolSize
	 * @param keepAliveTime
	 * @param unit
	 * @param workQueue
	 * @return a new instance of the appropriate {@link ThreadPoolExecutor}
	 *         subclass
	 */
	public ThreadPoolExecutor create(int corePoolSize, int maximumPoolSize, long keepAliveTime,
			TimeUnit unit, BlockingQueue<Runnable> workQueue) {
		return new BlockingThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime, unit,
				workQueue);
	}

	/**
	 * Returns a new instance of the appropriate {@link ThreadPoolExecutor}
	 * subclass
	 *
	 * @param corePoolSize
	 * @param maximumPoolSize
	 * @param keepAliveTime
	 * @param unit
	 * @param workQueue
	 * @param threadFactory
	 * @return a new instance of the appropriate {@link ThreadPoolExecutor}
	 *         subclass
	 */
	public ThreadPoolExecutor create(int corePoolSize, int maximumPoolSize, long keepAliveTime,
			TimeUnit unit, BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory) {
		return new BlockingThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime, unit,
				workQueue, threadFactory);
	}

}
