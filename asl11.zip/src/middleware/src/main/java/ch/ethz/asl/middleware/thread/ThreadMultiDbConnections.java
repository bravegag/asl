/**
 * ThreadMultiDbConnections.java
 */
package ch.ethz.asl.middleware.thread;

import org.apache.commons.lang.*;
import org.slf4j.*;
import org.springframework.jdbc.core.namedparam.*;
import org.springframework.transaction.support.*;

/**
 * {@link Thread} subclass associated to persistence services.
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 21, 2011
 */
public class ThreadMultiDbConnections extends Thread {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory.getLogger(ThreadMultiDbConnections.class);
	private final NamedParameterJdbcOperations[] jdbcOperations;
	private final TransactionTemplate transactionTemplate;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs an instance of {@link ThreadMultiDbConnections}
	 * 
	 * @param runnable
	 *            The {@link Runnable} instance to execute
	 * @param jdbcOperations
	 *            The concrete {@link NamedParameterJdbcOperations} instance
	 *            associated to this {@link Thread}
	 * @param transactionTemplate
	 *            The {@link TransactionTemplate} instance associated to this
	 *            Thread
	 */
	public ThreadMultiDbConnections(Runnable runnable, TransactionTemplate transactionTemplate,
			NamedParameterJdbcOperations... jdbcOperations) {
		super(runnable);

		Validate.notEmpty(jdbcOperations, "'jdbcOperations' muts not be null nor empty");
		Validate.notNull(transactionTemplate, "'transactionTemplate' must not be null");

		this.jdbcOperations = jdbcOperations;
		this.transactionTemplate = transactionTemplate;

		super.setName(getClass().getSimpleName() + "-Thread");
	}

	/**
	 * Returns the jdbcOperations
	 * 
	 * @return the jdbcOperations
	 */
	public final NamedParameterJdbcOperations[] getJdbcOperations() {
		return jdbcOperations;
	}

	/**
	 * Returns the transactionTemplate
	 * 
	 * @return the transactionTemplate
	 */
	public final TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}
}
