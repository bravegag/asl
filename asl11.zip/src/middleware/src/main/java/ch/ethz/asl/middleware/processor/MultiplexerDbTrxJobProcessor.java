/**
 * MultiplexerDbTrxJobProcessor.java
 */
package ch.ethz.asl.middleware.processor;

import java.util.*;

import javax.sql.*;

import org.slf4j.*;
import org.springframework.jdbc.core.namedparam.*;
import org.springframework.transaction.support.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.middleware.thread.*;

/**
 * Defines a {@link Runnable} Job that processes Database {@link Job}. It
 * processes a single {@link RequestData} against multiple {@link DataSource}
 * instances, doing an over-simplified two-phase commit or actually using XA.
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 18, 2011
 */
public class MultiplexerDbTrxJobProcessor extends AbstractDbJobProcessor {
	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(MultiplexerDbTrxJobProcessor.class);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link MultiplexerDbTrxJobProcessor}
	 *
	 * @param job
	 *            The job to process
	 */
	public MultiplexerDbTrxJobProcessor(IJob job) {
		super(job);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void run() {
		IJob job = super.getJob();

		final RequestData requestData = job.getRequestData();

		LOGGER.debug("running jobId=[{}] type=[{}]", requestData.getId(),
				requestData.isQuery() ? "QUERY" : "REFRESH");

		// create the ResponseData
		ResponseData responseData = new ResponseData();

		// correlate RequestData and ResponseData
		responseData.setId(requestData.getId());

		try {
			LOGGER.debug("executing workload ...");

			ThreadMultiDbConnections threadMultiDbConnections = (ThreadMultiDbConnections) Thread
					.currentThread();
			NamedParameterJdbcOperations[] jdbcOperations = threadMultiDbConnections
					.getJdbcOperations();
			TransactionTemplate transactionTemplate = threadMultiDbConnections
					.getTransactionTemplate();

			final List<String> results = executeWorkload(requestData, transactionTemplate,
					jdbcOperations);
			responseData.setResults(results);

			LOGGER.debug("workload succeeded");
		}
		catch (Throwable exception) {
			exception.printStackTrace();
			responseData.setError(exception.getMessage());
		}
		finally {
			job.getObserver().update(responseData);
		}
	}
}
