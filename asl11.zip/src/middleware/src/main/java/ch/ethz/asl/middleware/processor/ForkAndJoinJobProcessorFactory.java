/**
 * ForkAndJoinJobProcessorFactory.java
 */
package ch.ethz.asl.middleware.processor;

import java.util.*;
import java.util.concurrent.*;

import javax.sql.*;

import org.apache.commons.lang.*;
import org.slf4j.*;

import com.google.common.collect.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.middleware.thread.*;

/**
 * Concrete {@link IJobProcessorFactory} implementation that creates instances
 * of {@link DbJobProcessor}
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 5, 2011
 */
public class ForkAndJoinJobProcessorFactory extends
		AbstractJobProcessorFactory<ForkAndJoinJobProcessor> implements
		IJobProcessorFactory<ForkAndJoinJobProcessor> {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ForkAndJoinJobProcessorFactory.class);

	/**
	 * {@link List} of {@link ThreadPoolExecutor} to consume
	 * {@link ThreadPerDbConnection} instances from. There is one
	 * {@link ThreadPoolExecutor} instance per corresponding {@link DataSource}
	 */
	private final List<ThreadPoolExecutor> threadPools = Lists.newArrayList();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link ForkAndJoinJobProcessor}
	 *
	 * @param threadPools
	 *            The {@link ThreadPoolExecutor} instances to consume
	 *            {@link ThreadPerDbConnection} from
	 */
	public ForkAndJoinJobProcessorFactory(List<ThreadPoolExecutor> threadPools) {
		Validate.notEmpty(threadPools, "'threadPools' must not be null nor empty");

		this.threadPools.addAll(threadPools);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ForkAndJoinJobProcessor create(IJob job) {
		return new ForkAndJoinJobProcessor(job, new DbJobProcessorFactory(), threadPools);
	}
}
