/**
 * AbstractDispatcherPolicy.java
 */
package ch.ethz.asl.middleware.thread.dispatcher.policy;

import org.apache.commons.lang.*;

import ch.ethz.asl.middleware.thread.dispatcher.*;

/**
 * Abstract base reusable definition of {@link IDispatcherPolicy}
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 22, 2011
 */
public abstract class AbstractDispatcherPolicy implements IDispatcherPolicy {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private final int maxIndex;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor for {@link AbstractDispatcherPolicy}
	 */
	public AbstractDispatcherPolicy(int maxIndex) {
		Validate.isTrue(maxIndex > 0, "'maxIndex' must be greater than zero");

		this.maxIndex = maxIndex;
	}

	// ------------------------------------------------------------------------
	// protected
	// ------------------------------------------------------------------------
	/**
	 * Returns the maxIndex
	 * 
	 * @return the maxIndex
	 */
	protected final int getMaxIndex() {
		return maxIndex;
	}
}
