/**
 * AbstractJobProcessorFactory.java
 */
package ch.ethz.asl.middleware.processor;

/**
 * Abstract base reusable implementation of {@link IJobProcessorFactory}
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 1, 2011
 */
abstract public class AbstractJobProcessorFactory<JP extends IJobProcessor> implements
		IJobProcessorFactory<JP> {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * {@inheritDoc}
	 */
	@Override
	public JP create() {
		throw new UnsupportedOperationException(
				"The Factory requires the Job to process in a Stateless fashion");
	}
}
