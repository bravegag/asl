/**
 * IPostProcessor.java
 */
package ch.ethz.asl.middleware.postprocessor;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;

/**
 * Abstract definition of {@link IJob} post-processing services
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 24, 2011
 */
public interface IPostProcessor {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Returns the postprocessed {@link ResponseData} instance
	 *
	 * @param responseData The original {@link ResponseData} instance
	 * @return the postprocessed {@link ResponseData} instance
	 */
	public ResponseData process(ResponseData responseData);
}
