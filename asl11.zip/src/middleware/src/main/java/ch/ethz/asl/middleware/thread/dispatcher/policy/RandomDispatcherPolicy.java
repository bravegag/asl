/**
 * RandomDispatcherPolicy.java
 */
package ch.ethz.asl.middleware.thread.dispatcher.policy;

import java.util.*;

import org.apache.commons.lang.*;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.middleware.thread.dispatcher.*;

/**
 * Concrete {@link IDispatcherPolicy} that generates random index assignments
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 12, 2011
 */
public class RandomDispatcherPolicy extends AbstractDispatcherPolicy {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(RandomDispatcherPolicy.class);
	private final Random random;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	public RandomDispatcherPolicy(int maxIndex, long seed) {
		super(maxIndex);

		Validate.isTrue(seed >= 0, "'seed' must be non-negative");

		random = new Random(999L * seed);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int nextIndex(IJob job) {
		int nextIndex = random.nextInt(super.getMaxIndex());

		LOGGER.debug("next random index is: '" + nextIndex + "'");

		return nextIndex;
	}

}
