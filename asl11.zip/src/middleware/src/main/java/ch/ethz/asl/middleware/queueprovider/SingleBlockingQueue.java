/**
 * SingleBlockingQueue.java
 */
package ch.ethz.asl.middleware.queueprovider;

import java.util.concurrent.*;

import org.apache.commons.lang.*;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.middleware.processor.*;

/**
 * Concrete implementation of {@link IQueueProvider} corresponding for one
 * Single {@link BlockingQueue} instance. This definition is that of a Proxy
 * i.e. controls access to the underlying actual {@link BlockingQueue}
 * implementation.
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 6, 2011
 */
public class SingleBlockingQueue<J extends IJob> implements IQueueProvider<J> {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(SingleBlockingQueue.class);

	/**
	 * Actual {@link BlockingQueue} instance to put {@link IJobProcessor} into
	 */
	private final BlockingQueue<J> actualQueue;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor for instances of {@link SingleBlockingQueue}
	 * 
	 * @param actualQueue
	 *            The actual underlying {@link BlockingQueue} instance
	 */
	public SingleBlockingQueue(BlockingQueue<J> actualQueue) {
		Validate.notNull(actualQueue, "'actualQueue' must not be null");
		Validate.isTrue(actualQueue.isEmpty(), "'actualQueue' must be empty");

		this.actualQueue = actualQueue;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void put(J jobProcessor) throws InterruptedException {
		LOGGER.debug("enqueuing job in the actual queue ...");
		actualQueue.put(jobProcessor);
		LOGGER.debug("done enqueuing job");
	}

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean offer(J jobProcessor) {
        LOGGER.debug("enqueuing job in the actual queue ...");
        boolean succeeded = actualQueue.offer(jobProcessor);
        if (succeeded) {
            LOGGER.debug("done enqueuing job");
        } else {
            LOGGER.debug("queue is full, enqueuing failed");
        }
        
        return succeeded;
    }
}

