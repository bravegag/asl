/**
 * DispatcherThread.java
 */
package ch.ethz.asl.middleware.thread.dispatcher;

import java.util.*;
import java.util.concurrent.*;

import org.apache.commons.lang.*;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.middleware.*;
import ch.ethz.asl.middleware.Parameter.*;
import ch.ethz.asl.middleware.processor.*;
import ch.ethz.asl.middleware.thread.*;
import ch.ethz.asl.middleware.thread.dispatcher.policy.*;

/**
 * {@link Thread} subclass Dispatcher implementation that pushes
 * {@link IJobProcessor} instances from the {@link BlockingQueue} instance to
 * the different types of worker threads:
 * <ul>
 * <li>{@link ThreadPerDbConnection}</li>
 * <li>{@link ThreadMultiDbConnections}</li>
 * </ul>
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 11, 2011
 */
public class DispatcherThread extends Thread {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(DispatcherThread.class);
	private final BlockingQueue<IJob> jobsQueue;
	private final IDispatcherPolicy anyDispatcherPolicy;
	private final DestinationDispatcherPolicy destinationDispatcherPolicy;
	private final List<ThreadPoolExecutor> threadPerDbThreadPools;
	private final ThreadPoolExecutor threadMultiDbThreadPool;
	private final IJobProcessorFactory<?> jobProcessorFactory;
	private final PartitioningMode partitioningMode;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link DispatcherThread}
	 *
	 * @param jobsQueue
	 *            The {@link BlockingQueue} to pull {@link IJobProcessor}
	 *            instances from
	 * @param anyDispatcherPolicy
	 *            The ANY {@link IDispatcherPolicy} instance
	 * @param destinationDispatcherPolicy
	 *            The SPECIFIC s{@link IDispatcherPolicy} instance
	 * @param threadPerDbThreadPools
	 *            {@link List} of database {@link ThreadPoolExecutor} instances
	 * @param threadMultiDbThreadPool
	 *            Fork-and-Join {@link ThreadPoolExecutor} instance
	 * @param jobProcessorFactory
	 *            The general {@link IJobProcessorFactory}
	 * @param dispatcherId
	 *            The Id of this {@link Dispatcher} instance
	 */
	public DispatcherThread(BlockingQueue<IJob> jobsQueue, IDispatcherPolicy anyDispatcherPolicy,
			DestinationDispatcherPolicy destinationDispatcherPolicy,
			List<ThreadPoolExecutor> threadPerDbThreadPools,
			ThreadPoolExecutor threadMultiDbThreadPool,
			IJobProcessorFactory<?> jobProcessorFactory, String dispatcherId) {
		Validate.notNull(jobsQueue, "'jobsQueue' must not be null");
		Validate.notNull(anyDispatcherPolicy, "'anyDispatcherPolicy' must not be null");
		Validate.notNull(destinationDispatcherPolicy,
				"'destinationDispatcherPolicy' must not be null");
		Validate.notEmpty(threadPerDbThreadPools,
				"'threadPerDbThreadPools' must not be null or empty");
		Validate.notNull(threadMultiDbThreadPool, "'threadMultiDbThreadPool' must not be null");
		Validate.notNull(jobProcessorFactory, "'jobProcessorFactory' must not be null");
		Validate.notNull(dispatcherId, "'dispatcherId' must not be null");

		// set the name of this Thread
		super.setName("Dispatcher-" + dispatcherId + "-Thread");

		this.jobsQueue = jobsQueue;
		this.anyDispatcherPolicy = anyDispatcherPolicy;
		this.destinationDispatcherPolicy = destinationDispatcherPolicy;
		this.threadPerDbThreadPools = threadPerDbThreadPools;
		this.threadMultiDbThreadPool = threadMultiDbThreadPool;
		this.jobProcessorFactory = jobProcessorFactory;
		this.partitioningMode = PartitioningMode.valueOf(System
				.getProperty(Parameter.PARTITIONING_MODE.getParameter()));

		LOGGER.debug("created");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void run() {
		LOGGER.debug("started");
		try {
			LOGGER.debug("blocking on queue ...");
			while (true) {
				// this call is blocking!
				IJob job = jobsQueue.take();

				// create the appropriate Job instance, note this can be
				// either a DbJobProcessor or a ForkAndJoinJobProcessor
				IJobProcessor jobProcessor = jobProcessorFactory.create(job);

				String jobId = jobProcessor.getJob().getRequestData().getId();
				LOGGER.debug("running job=[{}]", jobId);

				// destination is expected to be set at this point
				assert (job.getDestination() != null);

				int index = 0;
				switch (job.getDestination()) {
				case ALL:
					// here will be sent to all databases
					threadMultiDbThreadPool.execute(jobProcessor);

					break;

				case ANY:
					// use the ANY dispatcher policy to decide the target
					// database
					index = anyDispatcherPolicy.nextIndex(job);
					threadPerDbThreadPools.get(index).execute(jobProcessor);

					break;

				case SPECIFIC:
					// should only happen in SHARDING
					assert (PartitioningMode.SHARDING == partitioningMode);

					// use the DESTINATION dispatcher policy to decide the
					// specific database
					index = destinationDispatcherPolicy.nextIndex(job);
					threadPerDbThreadPools.get(index).execute(jobProcessor);

					break;

				default:
					throw new RuntimeException("unreachable");
				}

				LOGGER.debug("executing job=[{}]", jobId);
			}
		}
		catch (Throwable exception) {
			LOGGER.warn("operation failed, apparently a stop request");
		}
	}
}
