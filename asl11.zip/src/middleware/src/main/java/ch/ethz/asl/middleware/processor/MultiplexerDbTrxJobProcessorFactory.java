/**
 * MultiplexerDbTrxJobProcessorFactory.java
 */
package ch.ethz.asl.middleware.processor;

import ch.ethz.asl.common.remoting.*;

/**
 * Concrete {@link IJobProcessorFactory} implementation that creates instances
 * of {@link DbJobProcessor}
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 5, 2011
 */
public class MultiplexerDbTrxJobProcessorFactory extends
		AbstractJobProcessorFactory<MultiplexerDbTrxJobProcessor> implements
		IJobProcessorFactory<MultiplexerDbTrxJobProcessor> {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * {@inheritDoc}
	 */
	@Override
	public MultiplexerDbTrxJobProcessor create(IJob job) {
		return new MultiplexerDbTrxJobProcessor(job);
	}
}
