/**
 * ThreadPerDbConnection.java
 */
package ch.ethz.asl.middleware.thread;

import org.apache.commons.lang.*;
import org.slf4j.*;
import org.springframework.jdbc.core.namedparam.*;
import org.springframework.transaction.support.*;

/**
 * {@link Thread} subclass associated to persistence services.
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 1, 2011
 */
public class ThreadPerDbConnection extends Thread {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory.getLogger(ThreadPerDbConnection.class);
	private final NamedParameterJdbcOperations jdbcOperations;
	private final TransactionTemplate transactionTemplate;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs an instance of {@link ThreadPerDbConnection}
	 * 
	 * @param runnable
	 *            The {@link Runnable} instance to execute
	 * @param transactionTemplate
	 *            The {@link TransactionTemplate} instance associated to this
	 *            Thread
	 * @param jdbcOperations
	 *            The concrete {@link NamedParameterJdbcOperations} instance
	 *            associated to this {@link Thread}
	 */
	public ThreadPerDbConnection(Runnable runnable, TransactionTemplate transactionTemplate,
			NamedParameterJdbcOperations jdbcOperations) {
		super(runnable);

		Validate.notNull(transactionTemplate, "'transactionTemplate' must not be null");
		Validate.notNull(jdbcOperations, "'jdbcOperations' muts not be null");

		this.transactionTemplate = transactionTemplate;
		this.jdbcOperations = jdbcOperations;

		super.setName(getClass().getSimpleName() + "-Thread");
	}

	/**
	 * Returns the jdbcOperations
	 * 
	 * @return the jdbcOperations
	 */
	public final NamedParameterJdbcOperations getJdbcOperations() {
		return jdbcOperations;
	}

	/**
	 * Returns the transactionTemplate
	 * 
	 * @return the transactionTemplate
	 */
	public final TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}
}
