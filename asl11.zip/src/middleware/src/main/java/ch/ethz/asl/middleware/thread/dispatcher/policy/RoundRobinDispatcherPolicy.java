/**
 * RoundRobinDispatcherPolicy.java
 */
package ch.ethz.asl.middleware.thread.dispatcher.policy;

import java.util.*;

import org.apache.commons.lang.*;
import org.slf4j.*;

import com.google.common.collect.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.middleware.thread.dispatcher.*;

/**
 * Concrete {@link IDispatcherPolicy} that generates index assignments in a
 * Round Robin fashion
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 12, 2011
 */
public class RoundRobinDispatcherPolicy extends AbstractDispatcherPolicy {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(RoundRobinDispatcherPolicy.class);
	private int nextIndex = 0;
	private final List<Integer> randomIndexes = Lists.newArrayList();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor for instances of {@link RoundRobinDispatcherPolicy}
	 * 
	 * @param maxIndex
	 * @param seed
	 */
	public RoundRobinDispatcherPolicy(int maxIndex, long seed) {
		super(maxIndex);
		
		Validate.isTrue(seed >= 0, "'seed' must be non-negative");
		
		Random random = new Random(999L * seed);
		for (int i = 0; i < maxIndex; i++) {
			randomIndexes.add(i);
		}
		
		assert(randomIndexes.size() == maxIndex);
		
		Collections.shuffle(randomIndexes, random);

		LOGGER.debug("resulting random sequence is {}", randomIndexes);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int nextIndex(IJob job) {
		// keep it within the maxIndex
		if (nextIndex >= getMaxIndex()) {
			nextIndex = 0;
		}

		int randomIndex = randomIndexes.get(nextIndex++);

		LOGGER.debug("next round-robin index is: '" + randomIndex + "'");

		return randomIndex;
	}

}
