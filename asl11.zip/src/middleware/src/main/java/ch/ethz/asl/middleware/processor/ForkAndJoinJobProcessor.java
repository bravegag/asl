/**
 * ForkAndJoinJobProcessor.java
 */
package ch.ethz.asl.middleware.processor;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

import org.apache.commons.lang.*;
import org.perfectjpattern.core.api.behavioral.observer.*;
import org.slf4j.*;

import com.google.common.collect.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.common.sql.*;
import ch.ethz.asl.middleware.postprocessor.*;
import ch.ethz.asl.middleware.thread.*;

/**
 * Defines a {@link Runnable} Job that processes {@link Job} that require
 * Fork/Join
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 1, 2011
 */
public class ForkAndJoinJobProcessor implements IJobProcessor, IObserver<ResponseData> {
	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ForkAndJoinJobProcessor.class);

	/**
	 * {@link Job} to process
	 */
	private final IJob job;

	/**
	 * Creates other {@link IJobProcessor} types
	 */
	private final DbJobProcessorFactory dbJobProcessorFactory;

	/**
	 * Post processing of {@link ResponseData}
	 */
	private final PostProcessorFactory postProcessorFactory = new PostProcessorFactory();

	/**
	 * {@link List} of {@link ThreadPoolExecutor} to consume
	 * {@link ThreadPerDbConnection} instances from
	 */
	private final List<ThreadPoolExecutor> threadPools = Lists.newArrayList();
	private final CountDownLatch countDownLatch;
	final boolean FAIR = true;
	private final Lock updateLock = new ReentrantLock(FAIR);
	private final List<String> results = Lists.newArrayList();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link ForkAndJoinJobProcessor}
	 *
	 * @param job
	 *            The job to process
	 * @param threadPools
	 *            The {@link ThreadPoolExecutor} instances to consume
	 *            {@link ThreadPerDbConnection} from
	 */
	public ForkAndJoinJobProcessor(IJob job, DbJobProcessorFactory dbJobProcessorFactory,
			List<ThreadPoolExecutor> threadPools) {
		Validate.notNull(job, "'job' must not be null");
		Validate.notNull(dbJobProcessorFactory, "'dbJobProcessorFactory' must not be null");
		Validate.notEmpty(threadPools, "'threadPools' must not be null nor empty");

		this.job = job;
		this.dbJobProcessorFactory = dbJobProcessorFactory;
		this.threadPools.addAll(threadPools);
		this.countDownLatch = new CountDownLatch(threadPools.size());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void run() {
		final RequestData requestData = job.getRequestData();

		LOGGER.debug("running jobId=[{}] type=[{}]", requestData.getId(),
				requestData.isQuery() ? "QUERY" : "REFRESH");

		// create the ResponseData
		ResponseData responseData = new ResponseData();

		// correlate RequestData and ResponseData
		responseData.setId(job.getRequestData().getId());

		try {
			LOGGER.debug("fork/join multiple jobs ...");

			// create a "hijacked" job where the actual Observer is this
			// ForkAndJoinJobProcessor instance
			IJob hijackedJob = new Job(requestData, this, job.getDestination());

			for (int i = 0; i < threadPools.size(); i++) {
				DbJobProcessor dbJobProcessor = dbJobProcessorFactory.create(hijackedJob);
				threadPools.get(i).execute(dbJobProcessor);
			}

			// wait for all threads to finish
			countDownLatch.await();

			// set the results
			responseData.setResults(results);

			// post process the results
			TpchWorkload firstWorkload = requestData.getWorkload().keySet().iterator().next();
			IPostProcessor postProcessor = postProcessorFactory.create(firstWorkload);
			responseData = postProcessor.process(responseData);

			// notify that the job is done
			job.getObserver().update(responseData);

			LOGGER.debug("fork/join succeeded");
		}
		catch (Throwable exception) {
			exception.printStackTrace();
			responseData.setError(exception.getMessage());
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	final public IJob getJob() {
		return job;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void update(ResponseData responseData) {
		updateLock.lock();
		try {
			// "merge" the results
			results.addAll(responseData.getResults());
		}
		finally {
			updateLock.unlock();
		}

		// keep the count
		countDownLatch.countDown();
	}
}