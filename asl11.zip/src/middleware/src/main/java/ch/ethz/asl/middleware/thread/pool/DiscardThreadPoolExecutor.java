/**
 * DiscardThreadPoolExecutor.java
 */
package ch.ethz.asl.middleware.thread.pool;

import java.text.*;
import java.util.concurrent.*;

import org.perfectjpattern.core.api.behavioral.observer.*;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.middleware.*;
import ch.ethz.asl.middleware.processor.*;

/**
 * Concrete {@link ThreadPoolExecutor} subclass that discards {@link Runnable}
 * Jobs when all the {@link Thread} instances in this Pool are busy.
 *
 * @see DiscardPolicy
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Nov 6, 2011
 */
public class DiscardThreadPoolExecutor extends ThreadPoolExecutor {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(DiscardThreadPoolExecutor.class);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor of {@link DiscardThreadPoolExecutor}
	 *
	 * @param corePoolSize
	 * @param maximumPoolSize
	 * @param keepAliveTime
	 * @param unit
	 * @param workQueue
	 */
	public DiscardThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime,
			TimeUnit unit, BlockingQueue<Runnable> workQueue) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue,
				new DiscardRejectedExecutionHandler());
	}

	/**
	 * Constructor of {@link DiscardThreadPoolExecutor}
	 *
	 * @param corePoolSize
	 * @param maximumPoolSize
	 * @param keepAliveTime
	 * @param unit
	 * @param workQueue
	 * @param threadFactory
	 */
	public DiscardThreadPoolExecutor(int corePoolSize, int maximumPoolSize, long keepAliveTime,
			TimeUnit unit, BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, threadFactory,
				new DiscardRejectedExecutionHandler());
	}

	// ------------------------------------------------------------------------
	// inner classes
	// ------------------------------------------------------------------------
	/**
	 * Concrete {@link RejectedExecutionHandler} implementation that sends a
	 * failed {@link ResponseData} back to the {@link IObserver}.
	 */
	private static class DiscardRejectedExecutionHandler implements RejectedExecutionHandler {
        private final String middlewareId;

		/**
		 * Constructor for {@link DiscardRejectedExecutionHandler}
		 */
		public DiscardRejectedExecutionHandler() {
			middlewareId = System.getProperty(Parameter.ID.getParameter());
		}

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor) {
			assert (runnable instanceof IJobProcessor);

			IJobProcessor processor = (IJobProcessor) runnable;
			IJob job = processor.getJob();
			String jobId = job.getRequestData().getId();
			LOGGER.debug("rejecting job id={}", jobId);

			ResponseData responseData = new ResponseData();
			responseData.setId(jobId);
			responseData.setError(MessageFormat.format("job rejected, middleware {0} is saturated",
					middlewareId));

			job.getObserver().update(responseData);
		}
	}
}
