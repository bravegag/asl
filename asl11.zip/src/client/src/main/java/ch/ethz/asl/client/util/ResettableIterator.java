/**
 * 
 */
package ch.ethz.asl.client.util;

import java.util.Iterator;

/**
 * Defines an {@link Iterator} whose state can be reset.  Can be used as an
 * alternative to {@link Iterable} to avoid allocating a new {@link Iterator}
 * each time.
 *
 * @author <a href="mailto:zchothia@student.ethz.ch">Zaheer Chothia</a>
 * @since Oct 24, 2011
 */
public interface ResettableIterator<T> extends Iterator<T> {
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Resets the internal state of this {@link Iterator}, such that is yields
	 * the same items as a newly constructed instance.
	 */
	public void reset();
}
