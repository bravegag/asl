/**
 * Parameter.java
 */
package ch.ethz.asl.client;

import ch.ethz.asl.common.application.*;

/**
 * Defines the Client component parameters with default (example) values.
 *
 * @author <a href="mailto:zchothia@student.ethz.ch">Zaheer Chothia</a>
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua Garcia</a>
 */
public enum Parameter implements IParameter {
	/**
	 * Every client has its identification number
	 */
	ID("5"),
	/**
	 * For how long will the Client component run (in minutes)
	 */
	TIMEOUT("5"),
	/**
	 * File that contains the host:port of middleware servers. The one listed
	 * first is the dedicated one. (processes updates only).  If multiple hosts
	 * are specified, the first is assumed to be the dedicated update middleware.
	 */
	SERVERS("ikr01.ethz.ch:6666;ikr09.ethz.ch:7777;ikr13.ethz.ch:8888"),
	/**
	 * Path to workload data (relative to current directory)
	 */
	WORKLOAD_DATA_PATH("workload"),
	/**
	 * Path to store log files (relative to current directory)
	 */
	LOG_DIRECTORY("logs");

	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Example shown in the {@link AbstractMain#showHelp}
	 */
	private final String example;
	
	/**
	 * Default port
	 */
	public static final int DEFAULT_PORT = 22000;
	
	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	@Override
	public String getExample() {
		return example;
	}

	@Override
	public String getParameter() {
		return name().toLowerCase();
	}

	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------
	private Parameter(String example) {
		this.example = example;
	}
}
