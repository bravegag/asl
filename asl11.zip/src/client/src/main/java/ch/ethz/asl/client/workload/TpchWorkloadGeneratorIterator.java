/**
 * TpchWorkloadGeneratorIterator.java
 */
package ch.ethz.asl.client.workload;

import java.text.*;
import java.util.*;
import java.util.concurrent.atomic.*;

import org.apache.commons.lang.*;
import org.slf4j.*;

import ch.ethz.asl.client.workload.TpchWorkloadGenerator.RF1Data;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.common.sql.*;

import com.google.common.collect.*;

/**
 * Implementation of {@link Iterator} used by the {@link TpchWorkloadGenerator}
 * implementation.
 */
class TpchWorkloadGeneratorIterator implements Iterator<RequestData> {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(TpchWorkloadGeneratorIterator.class);

	private static final Range<Integer> Q1_DELTA_RANGE = Ranges.closed(60, 120);
	private static final int Q1_REPEAT_COUNT = 22;

	/**
	 * Used to generate random numbers for query parameter substitution (Clause
	 * 2.1.3, page 22) -> used for {@code DELTA} in Query 1.
	 */
	private final Random randomDelta = new Random();
	private final AtomicLong randomSeed;
	private final Random randomInitial;

	private final ImmutableList<RF1Data> rf1Data;
	private final ImmutableList<Integer> rf2Data;
	private TpchWorkloadGeneratorIterator.State state;
	private int counter;
	private static final ImmutableMap<State, State> STATE_MACHINE = ImmutableMap.of(State.RF1,
			State.Q1, State.Q1, State.RF2, State.RF2, State.RF1);

	/**
	 * TPC-H workload as defined in section 5.3, page 93
	 */
	protected enum State {
		RF1, // RF1
		Q1, // Q1 (repeat Q1_REPEAT_COUNT times)
		RF2, // RF2
		FINISHED
	};

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor for instances of {@link TpchWorkload}
	 *
	 * @param rf1Data
	 * @param rf2Data
	 * @param clientId
	 */
	public TpchWorkloadGeneratorIterator(ImmutableList<RF1Data> rf1Data,
			ImmutableList<Integer> rf2Data, String clientId) {
		Validate.notEmpty(rf1Data, "'rf1Data' must not be null nor empty");
		Validate.notEmpty(rf2Data, "'rf2Data' must not be null nor empty");
		Validate.notNull(clientId, "'clientId' must not be null nor empty");

		this.rf1Data = rf1Data;
		this.rf2Data = rf2Data;

		// seed random Delta generator (Clause 2.1.3.3, page 22)
		// Should be incremented for each new stream.
		String seedString = MessageFormat.format("{0,Date,MMddHHmmss}", new Date());
		this.randomSeed = new AtomicLong((Long.valueOf(seedString)));

		// set the random to generate the initial state
		randomInitial = new Random(Long.valueOf(clientId).longValue());

		// switch to the next State
		nextState();

		assert (Q1_REPEAT_COUNT > 0);
		assert (rf1Data.size() == rf2Data.size());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void remove() {
		throw new IllegalStateException();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean hasNext() {
		return state != State.FINISHED;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public RequestData next() {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}

		RequestData requestData = null;
		assert (counter >= 0);
		switch (state) {
		case RF1: {
			RF1Data rf1 = rf1Data.get(counter);
			requestData = RequestDataBuilder.buildRf1(rf1);

			counter++;
			if (counter == rf1Data.size()) {
				// switch to the next State
				nextState();
			}
			break;
		}
		case Q1: {
			// Section 2.4.1.3, page 28
			// "DELTA is randomly selected within [60 ... 120]"
			Integer low = Q1_DELTA_RANGE.lowerEndpoint();
			Integer high = Q1_DELTA_RANGE.upperEndpoint();
			Integer delta = low + randomDelta.nextInt(high - low + 1);
			requestData = RequestDataBuilder.buildQuery1(delta);

			counter++;
			if (counter == Q1_REPEAT_COUNT) {
				// switch to the next State
				nextState();

				// reset the randomDelta generator
				long seedValue = randomSeed.incrementAndGet();
				LOGGER.debug("seeding random delta generator with {}", seedValue);
				randomDelta.setSeed(seedValue);
			}
			break;
		}
		case RF2: {
			Integer orderKey = rf2Data.get(counter);
			requestData = RequestDataBuilder.buildRf2(orderKey);

			counter++;
			if (counter == rf2Data.size()) {
				// switch to the next State
				nextState();
			}
			break;
		}
		default:
			throw new RuntimeException("unreachable");
		}

		assert (requestData != null);
		return requestData;
	}

	// ------------------------------------------------------------------------
	// protected
	// ------------------------------------------------------------------------
	/**
	 * Sets {@link #state} to the next one based on the {@link #randomState}.
	 */
	protected void nextState() {
		// get the next state
		if (state == null) {
			state = State.values()[randomInitial.nextInt(State.values().length - 1)];
		}
		else {
			state = STATE_MACHINE.get(state);
		}
		assert (state != null && state != State.FINISHED);

		// reset the counter
		this.counter = 0;
	}

	/**
	 * Returns the state
	 *
	 * @return the state
	 */
	protected final TpchWorkloadGeneratorIterator.State getState() {
		return state;
	}
}