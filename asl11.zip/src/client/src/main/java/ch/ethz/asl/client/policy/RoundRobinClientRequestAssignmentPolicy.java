/**
 * RoundRobinClientRequestAssignmentPolicy.java
 */
package ch.ethz.asl.client.policy;

import java.util.*;

import org.apache.commons.lang.*;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.dto.*;

import com.google.common.collect.*;

/**
 * Concrete {@link AbstractClientRequestAssignmentPolicy} that dispatches query
 * requests in round robin fashion.
 * 
 * @author <a href="mailto:zchothia@student.ethz.ch">Zaheer Chothia</a>
 * @since Oct 17, 2011
 */
public class RoundRobinClientRequestAssignmentPolicy extends AbstractClientRequestAssignmentPolicy {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(RoundRobinClientRequestAssignmentPolicy.class);
	private int nextIndex = 0;
	private final int maxIndex;
	private final List<Integer> randomIndexes = Lists.newArrayList();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor for {@link RoundRobinClientRequestAssignmentPolicy}
	 * 
	 * @param numberOfMiddlewares
	 * @param seed
	 */
	public RoundRobinClientRequestAssignmentPolicy(int numberOfMiddlewares, long seed) {
		super(numberOfMiddlewares);

		Validate.isTrue(seed >= 0, "'seed' must be non-negative");

		this.maxIndex = numberOfMiddlewares - 1;
		
		Random random = new Random(999L * seed);
		for (int i = 0; i < maxIndex; i++) {
			randomIndexes.add(i);
		}
		
		assert(randomIndexes.size() == maxIndex);
		
		Collections.shuffle(randomIndexes, random);
		
		LOGGER.debug("resulting random sequence is {}", randomIndexes);
	}

	/**
	 * {@inheritDoc}
	 */
	protected int nextQueryIndex(RequestData request) {
		// keep it within the maxIndex
		if (nextIndex >= maxIndex) {
			nextIndex = 0;
		}

		int randomIndex = randomIndexes.get(nextIndex++) + 1;

		LOGGER.debug("next round-robin index is: '" + randomIndex + "'");

		return randomIndex;
	}
}
