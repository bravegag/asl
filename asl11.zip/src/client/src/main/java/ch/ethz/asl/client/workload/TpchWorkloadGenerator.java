/**
 * TpchWorkloadGenerator.java
 */
package ch.ethz.asl.client.workload;

import java.io.*;
import java.nio.charset.*;
import java.text.*;
import java.util.*;

import org.apache.commons.lang.*;
import org.slf4j.*;

import ch.ethz.asl.client.*;
import ch.ethz.asl.client.util.*;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.common.sql.*;

import com.google.common.base.*;
import com.google.common.collect.*;
import com.google.common.io.*;

/**
 * Generates TPC-H queries following the workload for the Advanced Systems Lab.
 * We only support Query 1 rather than the full set of 22 queries: RF1, 22 * Q1,
 * RF2 In addition, RF2 (delete) will remove the tuples inserted by RF1
 * (insert).
 *
 * <b>Warning</b>: this class is not thread-safe!
 *
 * @author <a href="mailto:zchothia@student.ethz.ch">Zaheer Chothia</a>
 * @since Oct 13, 2011
 */
public class TpchWorkloadGenerator implements Iterable<RequestData> {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TpchWorkloadGenerator.class);
	private static final Charset UTF8_CHARSET = Charset.forName("UTF-8");

	/**
	 * Contains the update workload: RF1: data tuples to insert into ORDERS and
	 * LINEITEM RF2: ORDERKEY to remove from ORDERS and LINEITEM
	 */
	private ImmutableList<RF1Data> rf1Data = null;
	private ImmutableList<Integer> rf2Data = null;
	private final String clientId;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructs a {@link TpchWorkloadGenerator}
	 *
	 * @param dataPath
	 */
	public TpchWorkloadGenerator(File dataPath) {
		Validate.notNull(dataPath, "'dataPath' must not be null");

		this.clientId = System.getProperty(Parameter.ID.getParameter());

		Reader orderReader = null;
		Reader lineitemReader = null;
		Reader deleteReader = null;
		try {
			orderReader = getReader(new File(dataPath, "orders.tbl.u" + clientId));
			lineitemReader = getReader(new File(dataPath, "lineitem.tbl.u" + clientId));
			deleteReader = getReader(new File(dataPath, "delete." + clientId));

			// Read workload data
			LOGGER.debug("Reading workload data");
			try {
				readWorkloadData(orderReader, lineitemReader, deleteReader);
			}
			catch (Exception exception) {
				LOGGER.error("Failed to read/parse workload data!", exception);
				throw Throwables.propagate(exception);
			}
			assert (rf1Data != null);
			assert (rf2Data != null);
		}
		finally {
			// Closeables.close does nothing, if a null Reader is given.
			try {
				Closeables.close(orderReader, false);
			}
			catch (IOException exception) {
				LOGGER.warn("close attempt failed", exception);
			}
			try {
				Closeables.close(lineitemReader, false);
			}
			catch (IOException exception) {
				LOGGER.warn("close attempt failed", exception);
			}
			try {
				Closeables.close(deleteReader, false);
			}
			catch (IOException exception) {
				LOGGER.warn("close attempt failed", exception);
			}
		}
	}

	/**
	 * Returns an iterator which yields {@link RequestData} belonging to a
	 * single sequence of the {@link TpchWorkload}.
	 *
	 * @return an iterator of {@link RequestData} objects.
	 */
	@Override
	public Iterator<RequestData> iterator() {
		return new TpchWorkloadGeneratorIterator(rf1Data, rf2Data, clientId);
	}

	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------

	/**
	 * Reads workload data from the different {@link Reader} input instances
	 *
	 * @param orderReader
	 * @param lineitemReader
	 * @param deleteReader
	 * @throws IOException
	 * @throws ParseException
	 */
	private void readWorkloadData(Reader orderReader, Reader lineitemReader, Reader deleteReader)
			throws IOException, ParseException {
		// read and parse input data
		List<Map<TpchMetadata, Object>> orderTuples = TpchDataUtils.parseTuples(orderReader,
				TpchMetadata.ORDER_COLUMNS);

		List<Map<TpchMetadata, Object>> lineitemTuples = TpchDataUtils.parseTuples(lineitemReader,
				TpchMetadata.LINEITEM_COLUMNS);

		List<String> deleteLines = CharStreams.readLines(deleteReader);
		List<Integer> deleteOrderKeys = Lists.transform(deleteLines,
				new Function<String, Integer>() {
					@Override
					public Integer apply(String from) {
						return Integer.valueOf(from);
					}
				});

		// prepare refresh workload
		rf1Data = prepareRF1(orderTuples, lineitemTuples);

		// check RF2 -> should be complement (DELETE) of RF1 (RF1)
		if (deleteOrderKeys.size() != rf1Data.size()) {
			throw new IOException("Invalid input data: workload sizes don't match");
		}
		for (int i = 0; i < rf1Data.size(); i++) {
			int deleteKey = deleteOrderKeys.get(i);
			int insertKey = rf1Data.get(i).getOrderKey();
			if (deleteKey != insertKey) {
				throw new IOException(String.format(
						"Invalid input data: order key doesn't match between "
								+ "RF1 and RF2 (%d vs. %d)", deleteKey, insertKey));
			}
		}

		rf2Data = ImmutableList.copyOf(deleteOrderKeys);
	}

	/**
	 * Returns {@link List} of {@link RF1Data} instances to execute
	 *
	 * @param orderTuples
	 * @param lineitemTuples
	 * @return {@link List} of {@link RF1Data} instances to execute
	 * @throws IOException
	 */
	private ImmutableList<RF1Data> prepareRF1(List<Map<TpchMetadata, Object>> orderTuples,
			List<Map<TpchMetadata, Object>> lineitemTuples) throws IOException {
		// Group lineitems according to L_ORDERKEY
		Multimap<Object, Map<TpchMetadata, Object>> lineitemGroups = HashMultimap.create();
		for (Map<TpchMetadata, Object> lineitemTuple : lineitemTuples) {
			Object key = lineitemTuple.get(TpchMetadata.L_ORDERKEY);
			assert (key != null);
			lineitemGroups.put(key, lineitemTuple);
		}

		// TODO: unit test (specifically that equality is on order value not
		// Object identity)
		// Join ORDERS and LINEITEM
		ImmutableList.Builder<RF1Data> rf1DataBuilder = ImmutableList.builder();
		for (Map<TpchMetadata, Object> orderTuple : orderTuples) {
			Object orderKey = orderTuple.get(TpchMetadata.O_ORDERKEY);
			List<Map<TpchMetadata, Object>> lineItemTuples = ImmutableList.copyOf(lineitemGroups
					.get(orderKey));
			rf1DataBuilder = rf1DataBuilder.add(new RF1Data((Integer) orderKey, orderTuple,
					lineItemTuples));
		}
		return rf1DataBuilder.build();
	}

	/**
	 * Helper function to create a {@link Reader} for the resource file named
	 * {@link name} using UTF-8 encoding.
	 */
	private Reader getReader(File file) {
		Validate.notNull(file, "'file' must not be null");
		try {
			return new BufferedReader(
					new InputStreamReader(new FileInputStream(file), UTF8_CHARSET));
		}
		catch (FileNotFoundException exception) {
			throw Throwables.propagate(exception);
		}
	}

	// ------------------------------------------------------------------------
	// inner classes
	// ------------------------------------------------------------------------
	/**
	 * Immutable object containing an individual group of ORDER and LINEITEM
	 * tuples for RF1. These belong together in a single RF1 transaction.
	 */
	protected static class RF1Data {
		private final Range<Integer> RF1_LINEITEM_RANGE = Ranges.closed(1, 7);

		private final Integer orderKey;
		private final Map<TpchMetadata, Object> orderTuple;
		private final List<Map<TpchMetadata, Object>> lineitemTuples;

		public RF1Data(Integer orderKey, Map<TpchMetadata, Object> orderTuple,
				List<Map<TpchMetadata, Object>> lineitemTuples) {
			Validate.notNull(orderKey, "'orderKey' must not be null");
			Validate.notEmpty(orderTuple, "'orderTuple' must not be null nor empty");
			Validate.notEmpty(lineitemTuples, "'lineitemTuples' must not be null nor empty");

			for (TpchMetadata attribute : TpchMetadata.ORDER_COLUMNS) {
				Validate.notNull(orderTuple.get(attribute));
			}
			Validate.isTrue(orderTuple.get(TpchMetadata.O_ORDERKEY).equals(orderKey));
			Validate.isTrue(RF1_LINEITEM_RANGE.contains(lineitemTuples.size()));
			for (Map<TpchMetadata, Object> lineitemTuple : lineitemTuples) {
				for (TpchMetadata attribute : TpchMetadata.LINEITEM_COLUMNS) {
					Validate.notNull(lineitemTuple.get(attribute));
				}
				Validate.isTrue(lineitemTuple.get(TpchMetadata.L_ORDERKEY).equals(orderKey));
			}

			this.orderKey = orderKey;
			this.orderTuple = orderTuple;
			this.lineitemTuples = lineitemTuples;
		}

		public Integer getOrderKey() {
			return orderKey;
		}

		public Map<TpchMetadata, Object> getOrderTuple() {
			return orderTuple;
		}

		public List<Map<TpchMetadata, Object>> getLineitemTuples() {
			return lineitemTuples;
		}
	}
}
