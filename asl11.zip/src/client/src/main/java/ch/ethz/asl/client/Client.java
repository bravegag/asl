/**
 * Client.java
 */
package ch.ethz.asl.client;

import java.io.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.atomic.*;

import org.perfectjpattern.core.api.behavioral.observer.*;
import org.perfectjpattern.core.api.creational.factorymethod.*;
import org.slf4j.*;

import ch.ethz.asl.client.policy.*;
import ch.ethz.asl.client.workload.*;
import ch.ethz.asl.common.application.*;
import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.classic.*;
import ch.ethz.asl.common.remoting.dto.*;

import com.google.common.base.*;
import com.google.common.collect.*;
import com.google.common.net.*;

/**
 * Client Component main entry point
 *
 * @author <a href="mailto:zchothia@student.ethz.ch">Zaheer Chothia</a>
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua Garcia</a>
 * @since Oct 6, 2011
 */
public final class Client extends AbstractMain {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Client.class);
	private static final String COMPONENT_NAME = Client.class.getSimpleName();
	private static final long NANO_TO_MILLISECONDS = 1000000;
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");

	/**
	 * Client-side interface to middleware.
	 */
	private IClient clientService;

	/**
	 * This client Id
	 */
	private final Integer clientId;

	/**
	 * Keep track of elapsed time
	 */
	private long elapsedTime = 0;

	/**
	 * Shutdown started flag
	 */
	private final AtomicBoolean shutdownStarted = new AtomicBoolean(false);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * {@link Client} default constructor
	 */
	public Client() {
		clientId = Integer.valueOf(System.getProperty(Parameter.ID.getParameter()));
	}

	/**
	 * Component startup main
	 *
	 * @param arguments
	 */
	public static void main(String[] arguments) {
		List<Parameter> parameterValues = Arrays.asList(Parameter.values());

		// when all parameters are OK, start the Client component
		if (reusableMain(COMPONENT_NAME, parameterValues)) {
			// print component parameters
			printParameters(COMPONENT_NAME, parameterValues);

			final Client client = new Client();

			LOGGER.debug("setting up shutdown hook ...");
			Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
				@Override
				public void run() {
					client.shutdownComponent();
				}
			}));

			LOGGER.debug("starting component ...");
			client.startComponent();
			LOGGER.debug("component started");

			// setup timeout
			long timeout = Long.valueOf(System.getProperty(Parameter.TIMEOUT.getParameter()));
			client.setupTimeoutAndWait(timeout);
		}
	}

	// ------------------------------------------------------------------------
	// protected
	// ------------------------------------------------------------------------
	/**
	 * Initiates the client and starts sending requests.
	 */
	@SuppressWarnings("unchecked")
	protected void startComponent() {
		LOGGER.debug("Client {} is being started", clientId);

		// read and validate middleware host:port strings
		ImmutableList<HostAndPort> middlewareHosts = getMiddlewareHosts(System
				.getProperty(Parameter.SERVERS.getParameter()));
		int numberOfMiddlewares = middlewareHosts.size();

		// prepare workload
		File dataPath = new File(System.getProperty(Parameter.WORKLOAD_DATA_PATH.getParameter()))
				.getAbsoluteFile();
		LOGGER.debug("Workload data path: {}", dataPath);
		final TpchWorkloadGenerator workloadGenerator = new TpchWorkloadGenerator(dataPath);

		// whether to retry the previous request due to failure
		final AtomicBoolean retry = new AtomicBoolean(false);

		LOGGER.debug("Creating client service and request factory");
		IFactoryMethod<RequestData> requestFactory = new IFactoryMethod<RequestData>() {
			private int jobCount = 0;
			private final Iterator<RequestData> workload = workloadGenerator.iterator();
			private RequestData previousRequestData = null;

			@Override
			public RequestData create() {
				RequestData requestData = null;
				if (retry.get()) {
					requestData = previousRequestData;
				}
				else {
					requestData = workload.next();
				}
				assert (requestData != null);

				long currentTime = System.nanoTime();

				// measure response time from here
				elapsedTime = currentTime;
				currentTime /= NANO_TO_MILLISECONDS;

				requestData.setId(MessageFormat.format("{0}-{1}", clientId, jobCount++));
				LOGGER.info("sending request jobId=[{}] clientId=[{}] time=[{}] request=[{}]",
						new Object[] { requestData.getId(), clientId, currentTime, requestData });

				// always save the previous request data
				previousRequestData = requestData;

				return requestData;
			}
		};

		Integer seed = clientId;
		this.clientService = new BlockingIOClient(requestFactory, clientId.toString(),
				new RoundRobinClientRequestAssignmentPolicy(numberOfMiddlewares, seed));

		LOGGER.debug("attaching response observer");
		IObserver<ResponseData> responseObserver = new IObserver<ResponseData>() {
			@Override
			public void update(ResponseData responseData) {

				// measure response time
				long currentTime = System.nanoTime();
				elapsedTime = (currentTime - elapsedTime) / NANO_TO_MILLISECONDS;
				currentTime /= NANO_TO_MILLISECONDS;

				// print the results to INFO only if there are no errors
				if (responseData.isSuccessful()) {
					String results = LINE_SEPARATOR + responseData.getResults().toString();
					LOGGER.info(
							"received response jobId=[{}] clientId=[{}] time=[{}] elapsed=[{}ms] results=[{}]",
							new Object[] { responseData.getId(), clientId, currentTime,
									Long.valueOf(elapsedTime),
									results.replaceAll(",", LINE_SEPARATOR) });
					retry.set(false);
				}
				else {
					LOGGER.warn(
							"request failed jobId=[{}] clientId=[{}] time=[{}] elapsed=[{}ms] error=[{}], will retry ...",
							new Object[] { responseData.getId(), clientId, currentTime,
									elapsedTime, responseData.getError() });

					// if failure then retry
					retry.set(true);
				}
			}
		};
		clientService.attach(responseObserver);

		LOGGER.debug("connecting to middleware");
		clientService.connect(middlewareHosts);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void shutdownComponent() {
		// shutdown only if it hasn't started yet
		if (!shutdownStarted.getAndSet(true)) {
			LOGGER.debug("client {} shutdown requested", clientId);

			// stop the client service
			clientService.stop();
			clientService.waitFor();

			LOGGER.debug("client {} shutdown complete", clientId);
		}
	}

	// ------------------------------------------------------------------------
	// private
	// ------------------------------------------------------------------------

	/**
	 * Returns the list of {@link HostAndPort} instances corresponding to the
	 * Middleware servers
	 *
	 * @param hostList
	 * @return the list of {@link HostAndPort} instances corresponding to the
	 *         Middleware servers
	 */
	private ImmutableList<HostAndPort> getMiddlewareHosts(String hostList) {
		Iterable<String> splitServers = Splitter.on(';').trimResults().omitEmptyStrings()
				.split(hostList);
		ImmutableList<HostAndPort> hosts = ImmutableList.copyOf(Iterables.transform(splitServers,
				new Function<String, HostAndPort>() {
					@Override
					public HostAndPort apply(String hostPortString) {
						return HostAndPort.fromString(hostPortString).withDefaultPort(
								Parameter.DEFAULT_PORT);
					}
				}));
		return hosts;
	}
}
