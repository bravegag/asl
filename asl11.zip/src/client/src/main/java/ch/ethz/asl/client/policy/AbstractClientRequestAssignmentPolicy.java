/**
 * AbstractClientRequestAssignmentPolicy.java
 */
package ch.ethz.asl.client.policy;

import org.apache.commons.lang.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;

/**
 * Concrete definition {@link IClientRequestAssignmentPolicy}, which implements
 * {@link #nextIndex(RequestData)} to handles update requests and single
 * middleware case.
 *
 * @author <a href="mailto:zchothia@student.ethz.ch">Zaheer Chothia</a>
 * @since Oct 17, 2011
 */
public abstract class AbstractClientRequestAssignmentPolicy implements
		IClientRequestAssignmentPolicy {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	private final int numberOfMiddlewares;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Constructor for {@link AbstractClientRequestAssignmentPolicy}
	 *
	 * @param numberOfMiddlewares
	 */
	public AbstractClientRequestAssignmentPolicy(int numberOfMiddlewares) {
		Validate.isTrue(numberOfMiddlewares > 0, "'numberOfMiddlewares' must be greater than zero");

		this.numberOfMiddlewares = numberOfMiddlewares;
	}

	/**
	 * {@inheritDoc}
	 */
	public int nextIndex(RequestData requestData) {
		// by default covers the 1-Middleware server case and QUERY
		int result = 0;

		if (numberOfMiddlewares > 1 && requestData.isQuery()) {
			result = nextQueryIndex(requestData);
		}

		return result;
	}

	// ------------------------------------------------------------------------
	// protected
	// ------------------------------------------------------------------------
	/**
	 * Returns the next Query index to be executed
	 *
	 * @param requestData
	 *            The {@link RequestData} in consideration
	 * @return the next Query index to be executed
	 */
	protected abstract int nextQueryIndex(RequestData requestData);

	/**
	 * Returns the numberOfMiddlewares
	 *
	 * @return the numberOfMiddlewares
	 */
	protected final int getNumberOfMiddlewares() {
		return numberOfMiddlewares;
	}
}
