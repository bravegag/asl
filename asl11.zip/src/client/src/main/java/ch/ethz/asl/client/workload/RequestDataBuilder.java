/**
 * RequestDataBuilder.java
 */
package ch.ethz.asl.client.workload;

import java.util.*;

import org.apache.commons.lang.*;
import org.slf4j.*;

import ch.ethz.asl.client.workload.TpchWorkloadGenerator.RF1Data;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.common.sql.*;

import com.google.common.collect.*;

/**
 * Builds {@link RequestData} for all supported TPC-H query types. (Currently:
 * RF1, RF2 and Q1)
 *
 * @author <a href="mailto:zchothia@student.ethz.ch">Zaheer Chothia</a>
 * @since Oct 13, 2011
 */
public class RequestDataBuilder {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(RequestDataBuilder.class);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Returns built {@link RequestData} based on a {@link RF1Data}
	 *
	 * @param rf1
	 * @return built {@link RequestData} based on a {@link RF1Data}
	 */
	public static RequestData buildRf1(RF1Data rf1) {
		// Integer orderKey,
		Validate.notNull(rf1);
		Integer orderKey = rf1.getOrderKey();
		Map<TpchMetadata, Object> orderTuple = rf1.getOrderTuple();
		List<Map<TpchMetadata, Object>> lineitemTuples = rf1.getLineitemTuples();
		LOGGER.debug("Building RF1 with ORDERKEY = {}", orderKey);

		RequestData requestData = new RequestData();
		requestData.addWorkload(TpchWorkload.REFRESH_1_1, transformTuple(orderTuple));
		for (Map<TpchMetadata, Object> lineitemTuple : lineitemTuples) {
			requestData.addWorkload(TpchWorkload.REFRESH_1_2, transformTuple(lineitemTuple));
		}
		return requestData;
	}

	/**
	 * Returns built {@link RequestData} corresponding to Query 1
	 *
	 * @param delta
	 * @return built {@link RequestData} corresponding to Query 1
	 */
	public static RequestData buildQuery1(Integer delta) {
		LOGGER.debug("Building Query 1 with interval DELTA = {}", delta);

		RequestData requestData = new RequestData();
		requestData.addWorkload(TpchWorkload.QUERY_1,
				ImmutableMap.of("delta", (Object) (delta.toString() + " day")));
		return requestData;
	}

	/**
	 * Returns built {@link RequestData} corresponding to RF2
	 *
	 * @param orderKey
	 * @return built {@link RequestData} corresponding to RF2
	 */
	public static RequestData buildRf2(Integer orderKey) {
		LOGGER.debug("Building RF2 with ORDERKEY = {}", orderKey);

		// Important: take note of the reversed order (compared to RF1).
		// This is needed so that all LINEITEM are deleted before their
		// corresponding ORDERS
		RequestData requestData = new RequestData();
		requestData.addWorkload(TpchWorkload.REFRESH_2_2,
				transformTuple(ImmutableMap.of(TpchMetadata.L_ORDERKEY, (Object) orderKey)));
		requestData.addWorkload(TpchWorkload.REFRESH_2_1,
				transformTuple(ImmutableMap.of(TpchMetadata.O_ORDERKEY, (Object) orderKey)));
		return requestData;
	}

	// ------------------------------------------------------------------------
	// private implementation
	// ------------------------------------------------------------------------
	/**
	 * Transforms safe tuples ({@link TpchMetadata key}) into wire-format (
	 * {@link String key}) using column key.
	 */
	private static Map<String, Object> transformTuple(Map<TpchMetadata, Object> inputTuple) {
		ImmutableMap.Builder<String, Object> outputTupleBuilder = ImmutableMap.builder();
		for (Map.Entry<TpchMetadata, Object> entry : inputTuple.entrySet()) {
			outputTupleBuilder = outputTupleBuilder.put(entry.getKey().getColumnName(),
					entry.getValue());
		}
		return outputTupleBuilder.build();
	}
}
