/**
 * RoundRobinClientRequestAssignmentPolicyTest.java
 */
package ch.ethz.asl.client.policy;

import static org.junit.Assert.*;

import java.math.*;

import org.junit.*;
import org.slf4j.*;

import ch.ethz.asl.common.remoting.*;
import ch.ethz.asl.common.remoting.dto.*;
import ch.ethz.asl.common.sql.*;

import com.google.common.collect.*;

/**
 * Test suite for the {@link RoundRobinClientRequestAssignmentPolicy}
 * implementation
 * 
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 20, 2011
 */
public class RoundRobinClientRequestAssignmentPolicyTest {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	public static final Logger LOGGER = LoggerFactory
			.getLogger(RoundRobinClientRequestAssignmentPolicyTest.class);

	private final RequestData queryRequestData = new RequestData();
	private final RequestData insertRequestData = new RequestData();
	private final RequestData deleteRequestData = new RequestData();

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	@Before
	public void setUp() throws Exception {
		// create a few RequestData instances
		queryRequestData.addWorkload(
				TpchWorkload.QUERY_1,
				new ImmutableMap.Builder<String, Object>()
						.put(TpchMetadata.L_ORDERKEY.getColumnName(), 3)
						.put(TpchMetadata.O_TOTALPRICE.getColumnName(),
								BigDecimal.valueOf(-0.00009)).build());

		insertRequestData.addWorkload(
				TpchWorkload.REFRESH_1_1,
				new ImmutableMap.Builder<String, Object>()
						.put(TpchMetadata.L_ORDERKEY.getColumnName(), 3)
						.put(TpchMetadata.O_TOTALPRICE.getColumnName(),
								BigDecimal.valueOf(-0.00009)).build());

		deleteRequestData.addWorkload(
				TpchWorkload.REFRESH_2_1,
				new ImmutableMap.Builder<String, Object>()
						.put(TpchMetadata.L_ORDERKEY.getColumnName(), 3)
						.put(TpchMetadata.O_TOTALPRICE.getColumnName(),
								BigDecimal.valueOf(-0.00009)).build());
	}

	/**
	 * Tests that the {@link RequestData} assignments are correct under
	 * different scenarios
	 */
	@Test
	public void testRequestAssignment() {
		// create new Policy
		int numberOfMiddlewares = 1;
		int seed = 0;
		IClientRequestAssignmentPolicy policy = new RoundRobinClientRequestAssignmentPolicy(
				numberOfMiddlewares, seed);

		// test for only one Middleware
		int nextIndex = 0;
		nextIndex = policy.nextIndex(queryRequestData);
		assertSame("One Middleware and QUERY", 0, nextIndex);
		nextIndex = policy.nextIndex(queryRequestData);
		assertSame("One Middleware and QUERY", 0, nextIndex);

		nextIndex = policy.nextIndex(insertRequestData);
		assertSame("One Middleware and INSERT", 0, nextIndex);
		nextIndex = policy.nextIndex(insertRequestData);
		assertSame("One Middleware and INSERT", 0, nextIndex);

		nextIndex = policy.nextIndex(deleteRequestData);
		assertSame("One Middleware and DELETE", 0, nextIndex);
		nextIndex = policy.nextIndex(deleteRequestData);
		assertSame("One Middleware and DELETE", 0, nextIndex);

		// test for two Middlewares
		numberOfMiddlewares = 2;
		policy = new RoundRobinClientRequestAssignmentPolicy(numberOfMiddlewares, seed);

		nextIndex = policy.nextIndex(queryRequestData);
		assertSame("Two Middlewares and QUERY", 1, nextIndex);
		nextIndex = policy.nextIndex(queryRequestData);
		assertSame("Two Middlewares and QUERY", 1, nextIndex);
		nextIndex = policy.nextIndex(queryRequestData);
		assertSame("Two Middlewares and QUERY", 1, nextIndex);

		nextIndex = policy.nextIndex(insertRequestData);
		assertSame("Two Middlewares and INSERT", 0, nextIndex);
		nextIndex = policy.nextIndex(insertRequestData);
		assertSame("Two Middlewares and INSERT", 0, nextIndex);

		nextIndex = policy.nextIndex(deleteRequestData);
		assertSame("Two Middlewares and DELETE", 0, nextIndex);
		nextIndex = policy.nextIndex(deleteRequestData);
		assertSame("Two Middlewares and DELETE", 0, nextIndex);

		// test for three Middlewares
		numberOfMiddlewares = 3;
		policy = new RoundRobinClientRequestAssignmentPolicy(numberOfMiddlewares, seed);

		nextIndex = policy.nextIndex(queryRequestData);
		assertSame("Three Middlewares and QUERY", 1, nextIndex);
		nextIndex = policy.nextIndex(queryRequestData);
		assertSame("Three Middlewares and QUERY", 2, nextIndex);
		nextIndex = policy.nextIndex(queryRequestData);
		assertSame("Three Middlewares and QUERY", 1, nextIndex);
		nextIndex = policy.nextIndex(queryRequestData);
		assertSame("Three Middlewares and QUERY", 2, nextIndex);

		nextIndex = policy.nextIndex(insertRequestData);
		assertSame("Three Middlewares and INSERT", 0, nextIndex);
		nextIndex = policy.nextIndex(insertRequestData);
		assertSame("Three Middlewares and INSERT", 0, nextIndex);
		nextIndex = policy.nextIndex(insertRequestData);
		assertSame("Three Middlewares and INSERT", 0, nextIndex);

		nextIndex = policy.nextIndex(deleteRequestData);
		assertSame("Three Middlewares and DELETE", 0, nextIndex);
		nextIndex = policy.nextIndex(deleteRequestData);
		assertSame("Three Middlewares and DELETE", 0, nextIndex);
		nextIndex = policy.nextIndex(deleteRequestData);
		assertSame("Three Middlewares and DELETE", 0, nextIndex);
	}
}
