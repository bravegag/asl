/**
 * TpchDataUtilsTest.java
 */
package ch.ethz.asl.client.util;

import static org.junit.Assert.*;

import java.io.*;
import java.math.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.Date;

import org.junit.*;
import org.slf4j.*;

import ch.ethz.asl.common.sql.*;

import com.google.common.collect.*;

/**
 * Unit Tests for the {@link TpchDataUtils}
 * 
 * @author <a href="mailto:zchothia@student.ethz.ch">Zaheer Chothia</a>
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Oct 13, 2011
 */
public class TpchDataUtilsTest {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	public static final Logger LOGGER = LoggerFactory.getLogger(TpchDataUtilsTest.class);

	private static final ImmutableList<TpchMetadata> BASIC_ATTRIBUTES = ImmutableList.of(
			TpchMetadata.L_ORDERKEY, TpchMetadata.O_TOTALPRICE, TpchMetadata.O_ORDERDATE);
	private final DateFormat TIMESTAMP_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	private final ImmutableList<ImmutableMap<TpchMetadata, Object>> EXPECTED_TUPLE_DATA;

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	public TpchDataUtilsTest() throws Exception {
		EXPECTED_TUPLE_DATA = ImmutableList.of(
				new ImmutableMap.Builder<TpchMetadata, Object>()
						.put(TpchMetadata.L_ORDERKEY, 1)
						.put(TpchMetadata.O_TOTALPRICE, BigDecimal.valueOf(3.25))
						.put(TpchMetadata.O_ORDERDATE,
								new Timestamp(((Date) TIMESTAMP_FORMAT.parseObject("2005-07-09"))
										.getTime())).build(),
				new ImmutableMap.Builder<TpchMetadata, Object>()
						.put(TpchMetadata.L_ORDERKEY, 2)
						.put(TpchMetadata.O_TOTALPRICE, BigDecimal.valueOf(4.56666))
						.put(TpchMetadata.O_ORDERDATE,
								new Timestamp(((Date) TIMESTAMP_FORMAT.parseObject("1999-05-14"))
										.getTime())).build(),
				new ImmutableMap.Builder<TpchMetadata, Object>()
						.put(TpchMetadata.L_ORDERKEY, 3)
						.put(TpchMetadata.O_TOTALPRICE, BigDecimal.valueOf(-0.00009))
						.put(TpchMetadata.O_ORDERDATE,
								new Timestamp(((Date) TIMESTAMP_FORMAT.parseObject("2013-12-31"))
										.getTime())).build());
	}

	/**
	 * Tests basic tuples with different data Types. Checks that the different
	 * Data types are parsed correctly.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testParseBasicTuples() throws Exception {
		String TUPLE_LINE = "1|3.25|2005-07-09\n2|4.56666|1999-05-14\n3|-0.000090|2013-12-31";

		List<Map<TpchMetadata, Object>> tuples = TpchDataUtils.parseTuples(new StringReader(
				TUPLE_LINE), BASIC_ATTRIBUTES);
		assertEquals(EXPECTED_TUPLE_DATA, tuples);
	}

	/**
	 * Test the same as before but this time placing trailing separators
	 * 
	 * @throws Exception
	 */
	@Test
	public void testParseBasicTuplesWithTrailingSeparator() throws Exception {
		String TUPLE_LINE = "1|3.25|2005-07-09|\n2|4.56666|1999-05-14|\n3|-0.000090|2013-12-31";

		List<Map<TpchMetadata, Object>> tuples = TpchDataUtils.parseTuples(new StringReader(
				TUPLE_LINE), BASIC_ATTRIBUTES);
		assertEquals(EXPECTED_TUPLE_DATA, tuples);
	}

	/**
	 * Test the same as before but this time placing trailing spaces at
	 * different places.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testParseBasicTuplePreservesWhitespace() throws Exception {
		String TUPLE_LINE = " 1|3.25|2005-07-09|\n 2|4.56666|1999-05-14|\n 3|-0.000090|2013-12-31 | ";

		List<Map<TpchMetadata, Object>> tuples = TpchDataUtils.parseTuples(new StringReader(
				TUPLE_LINE), BASIC_ATTRIBUTES);
		assertEquals(EXPECTED_TUPLE_DATA, tuples);
	}

	@Test
	public void testParseValidLineitem() throws IOException, ParseException {
		String TUPLE_LINE = "9|11252|775|1|27|31407.75|0.10|0.00|N|O|1995-11-28|1995-12-06|1995-12-06|TAKE BACK RETURN|AIR|ilent packages. final, regu|";
		ImmutableList<ImmutableMap<TpchMetadata, Object>> TUPLE_DATA = ImmutableList
				.of(new ImmutableMap.Builder<TpchMetadata, Object>()
						.put(TpchMetadata.L_ORDERKEY, TpchMetadata.L_ORDERKEY.toObject("9"))
						.put(TpchMetadata.L_PARTKEY, TpchMetadata.L_PARTKEY.toObject("11252"))
						.put(TpchMetadata.L_SUPPKEY, TpchMetadata.L_SUPPKEY.toObject("775"))
						.put(TpchMetadata.L_LINENUMBER, TpchMetadata.L_LINENUMBER.toObject("1"))
						.put(TpchMetadata.L_QUANTITY, TpchMetadata.L_QUANTITY.toObject("27"))
						.put(TpchMetadata.L_EXTENDEDPRICE,
								TpchMetadata.L_EXTENDEDPRICE.toObject("31407.75"))
						.put(TpchMetadata.L_DISCOUNT, TpchMetadata.L_DISCOUNT.toObject("0.10"))
						.put(TpchMetadata.L_TAX, TpchMetadata.L_TAX.toObject("0.00"))
						.put(TpchMetadata.L_RETURNFLAG, TpchMetadata.L_RETURNFLAG.toObject("N"))
						.put(TpchMetadata.L_LINESTATUS, TpchMetadata.L_LINESTATUS.toObject("O"))
						.put(TpchMetadata.L_SHIPDATE,
								TpchMetadata.L_SHIPDATE.toObject("1995-11-28"))
						.put(TpchMetadata.L_COMMITDATE,
								TpchMetadata.L_COMMITDATE.toObject("1995-12-06"))
						.put(TpchMetadata.L_RECEIPTDATE,
								TpchMetadata.L_RECEIPTDATE.toObject("1995-12-06"))
						.put(TpchMetadata.L_SHIPINSTRUCT,
								TpchMetadata.L_SHIPINSTRUCT.toObject("TAKE BACK RETURN"))
						.put(TpchMetadata.L_SHIPMODE, TpchMetadata.L_SHIPMODE.toObject("AIR"))
						.put(TpchMetadata.L_COMMENT,
								TpchMetadata.L_COMMENT.toObject("ilent packages. final, regu"))
						.build());

		List<Map<TpchMetadata, Object>> tuples = TpchDataUtils.parseTuples(new StringReader(
				TUPLE_LINE), TpchMetadata.LINEITEM_COLUMNS);
		assertEquals(tuples, TUPLE_DATA);
	}

	@Test(expected = ParseException.class)
	public void testParseInvalidLineitem() throws IOException, ParseException {
		String TUPLE_LINE = "extra|9|11252|775|1|27|31407.75|0.10|0.00|N|O|1995-11-28|1995-12-06|1995-12-06|TAKE BACK RETURN|AIR|ilent packages. final, regu|";
		TpchDataUtils.parseTuples(new StringReader(TUPLE_LINE), TpchMetadata.LINEITEM_COLUMNS);
	}

	@Test
	public void testParseValidOrder() throws IOException, ParseException {
		String TUPLE_LINE = "9|10096|O|70670.35|1995-10-13|3-MEDIUM|Clerk#000000052|0|ts promise slyly. express packages above the carefully ironic account|";
		ImmutableList<ImmutableMap<TpchMetadata, Object>> TUPLE_DATA = ImmutableList
				.of(new ImmutableMap.Builder<TpchMetadata, Object>()
						.put(TpchMetadata.O_ORDERKEY, TpchMetadata.O_ORDERKEY.toObject("9"))
						.put(TpchMetadata.O_CUSTKEY, TpchMetadata.O_CUSTKEY.toObject("10096"))
						.put(TpchMetadata.O_ORDERSTATUS, TpchMetadata.O_ORDERSTATUS.toObject("O"))
						.put(TpchMetadata.O_TOTALPRICE,
								TpchMetadata.O_TOTALPRICE.toObject("70670.35"))
						.put(TpchMetadata.O_ORDERDATE,
								TpchMetadata.O_ORDERDATE.toObject("1995-10-13"))
						.put(TpchMetadata.O_ORDERPRIORITY,
								TpchMetadata.O_ORDERPRIORITY.toObject("3-MEDIUM"))
						.put(TpchMetadata.O_CLERK, TpchMetadata.O_CLERK.toObject("Clerk#000000052"))
						.put(TpchMetadata.O_SHIPPRIORITY, TpchMetadata.O_SHIPPRIORITY.toObject("0"))
						.put(TpchMetadata.O_COMMENT,
								TpchMetadata.O_COMMENT
										.toObject("ts promise slyly. express packages above the carefully ironic account"))
						.build());

		List<Map<TpchMetadata, Object>> tuples = TpchDataUtils.parseTuples(new StringReader(
				TUPLE_LINE), TpchMetadata.ORDER_COLUMNS);
		assertEquals(tuples, TUPLE_DATA);
	}

	@Test(expected = ParseException.class)
	public void testParseInvalidOrder() throws IOException, ParseException {
		String TUPLE_LINE = "extra|9|10096|O|70670.35|1995-10-13|3-MEDIUM|Clerk#000000052|0|ts promise slyly. express packages above the carefully ironic account|";
		TpchDataUtils.parseTuples(new StringReader(TUPLE_LINE), TpchMetadata.ORDER_COLUMNS);
	}
}
