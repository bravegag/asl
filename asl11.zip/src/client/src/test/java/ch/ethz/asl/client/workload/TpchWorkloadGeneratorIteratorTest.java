/**
 * TpchWorkloadGeneratorIteratorTest.java
 */
package ch.ethz.asl.client.workload;

import java.util.*;

import junit.framework.*;

import org.easymock.*;
import org.junit.Test;
import org.slf4j.*;

import ch.ethz.asl.client.workload.TpchWorkloadGenerator.RF1Data;
import ch.ethz.asl.client.workload.TpchWorkloadGeneratorIterator.State;

import com.google.common.collect.*;

/**
 * Test suite for the {@link TpchWorkloadGeneratorIterator} implementation
 *
 * @author <a href="mailto:azuagarg@student.ethz.ch">Giovanni Azua</a>
 * @since Nov 2, 2011
 */
public class TpchWorkloadGeneratorIteratorTest extends TestCase {
	// ------------------------------------------------------------------------
	// members
	// ------------------------------------------------------------------------
	/**
	 * Logging for this class
	 */
	public static final Logger LOGGER = LoggerFactory
			.getLogger(TpchWorkloadGeneratorIteratorTest.class);

	// ------------------------------------------------------------------------
	// public
	// ------------------------------------------------------------------------
	/**
	 * Tests that the {@link TpchWorkloadGeneratorIterator#nextState()}
	 * implementation generates correct sequences
	 */
	@Test
	@SuppressWarnings("unchecked")
	public void testNextState() {
		final String clientId = "1";
		ImmutableList<RF1Data> rf1Data = EasyMock.createNiceMock(ImmutableList.class);
		ImmutableList<Integer> rf2Data = EasyMock.createNiceMock(ImmutableList.class);

		// fool the TpchWorkloadGeneratorIterator validation
		EasyMock.expect(rf1Data.size()).andReturn(1);
		EasyMock.expect(rf2Data.size()).andReturn(1);
		EasyMock.replay(rf1Data, rf2Data);

		TpchWorkloadGeneratorIterator iterator = new TpchWorkloadGeneratorIterator(rf1Data,
				rf2Data, clientId);

		// keep track of the counts per State
		Map<State, Integer> stats = Maps.newHashMap();
		for (State state : State.values()) {
			stats.put(state, Integer.valueOf(0));
		}

		StringBuilder builder = new StringBuilder();

		// call this 200 times
		final int REPETITIONS = 200;
		int count = 0;
		for (int i = 0; i < REPETITIONS; i++) {
			iterator.nextState();

			State state = iterator.getState();
			if (state == State.RF1) {
				count++;
			}
			else if (state == State.RF2) {
				count--;
			}

			stats.put(state, Integer.valueOf(stats.get(state) + 1));

			assertTrue("After every RF1 there must be an RF2 ", count <= 1);

			// print the sequence
			builder.append(state);
			if (i < (REPETITIONS - 1)) {
				builder.append(' ');
			}
		}

		// print the results
		LOGGER.debug("resulting sequence is: {}", builder.toString());
		LOGGER.debug("resulting statistics are: {}", stats);

		// now check the statistics that they are not far from each other
		assertTrue("RF statistics must be correct", stats.get(State.RF1) < stats.get(State.RF2));

		final int THRESHOLD = 1;
		assertTrue(
				"Q/RF statistics must be correct",
				Math.abs(stats.get(State.Q1) - stats.get(State.RF2)) <= THRESHOLD
						&& Math.abs(stats.get(State.Q1) - stats.get(State.RF1)) <= THRESHOLD);
	}

	/**
	 * Tests that the initial state is always randomly chosen
	 */
	@SuppressWarnings("unchecked")
	public void testInitialStateRandom() {
		// keep track of the counts per State
		Map<State, Integer> stats = Maps.newHashMap();
		for (State state : State.values()) {
			stats.put(state, Integer.valueOf(0));
		}

		StringBuilder builder = new StringBuilder();

		// number of clients to test
		final int REPETITIONS = 128;
		for (int i = 0; i < REPETITIONS; i++) {
			final String clientId = String.valueOf(i);
			ImmutableList<RF1Data> rf1Data = EasyMock.createNiceMock(ImmutableList.class);
			ImmutableList<Integer> rf2Data = EasyMock.createNiceMock(ImmutableList.class);

			// fool the TpchWorkloadGeneratorIterator validation
			EasyMock.expect(rf1Data.size()).andReturn(1);
			EasyMock.expect(rf2Data.size()).andReturn(1);
			EasyMock.replay(rf1Data, rf2Data);

			TpchWorkloadGeneratorIterator iterator = new TpchWorkloadGeneratorIterator(rf1Data,
					rf2Data, clientId);

			State state = iterator.getState();
			stats.put(state, Integer.valueOf(stats.get(state) + 1));

			// print the sequence
			builder.append(state);
			if (i < (REPETITIONS - 1)) {
				builder.append(' ');
			}
		}

		// print the results
		LOGGER.debug("resulting sequence is: {}", builder.toString());
		LOGGER.debug("resulting statistics are: {}", stats);

		// now check the statistics that they are not far from each other
		assertTrue("RF statistics must be correct", stats.get(State.RF1) < stats.get(State.RF2));

		final int THRESHOLD = 3;
		assertTrue(
				"Q/RF statistics must be correct",
				Math.abs(stats.get(State.Q1) - stats.get(State.RF2)) <= THRESHOLD
						&& Math.abs(stats.get(State.Q1) - stats.get(State.RF1)) <= THRESHOLD);
	}
}
