# =========================================================================================
# Advanced Systems Lab 
# Milestone 2 : 2^k experiment and ANOVA
# Author: Giovanni Azua
# Date: 10 November 2011
# =========================================================================================

rm(list=ls())                                                        # clear workspace

library(boot)                                                        # use boot library
library(ggplot2)                                                     # use ggplot2 library
library(doBy)                                                        # use doBy library
library(utils)                                                       # use utils library
library(nlme)                                                        # use utils library
library(MASS)                                                        # use MASS library
library(Hmisc)

# =========================================================================================
# Parameters
# =========================================================================================

decouple <- FALSE
workload <- "RF"
no_clients <- 64
warmup_cooldown_minutes <- 5
sample_size <- 1 # in minutes

# =========================================================================================
# Define utility functions
# =========================================================================================

## ************************************ COPIED FROM ********************************************
## http://wiki.stdout.org/rcookbook/Graphs/Plotting%20means%20and%20error%20bars%20%28ggplot2%29
## *********************************************************************************************
## Summarizes data.
## Gives count, mean, standard deviation, standard error of the mean, and confidence interval (default 95%).
## If there are within-subject variables, calculate adjusted values using method from Morey (2008).
##   data: a data frame.
##   measurevar: the name of a column that contains the variable to be summariezed
##   groupvars: a vector containing names of columns that contain grouping variables
##   na.rm: a boolean that indicates whether to ignore NA's
##   conf.interval: the percent range of the confidence interval (default is 95%)
##
summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE, conf.interval=.95) {
    require(doBy)

    # New version of length which can handle NA's: if na.rm==T, don't count them
    length2 <- function (x, na.rm=FALSE) {
        if (na.rm) 
        	sum(!is.na(x))
        else   
        	length(x)
    }

    # Collapse the data
    formula <- as.formula(paste(measurevar, paste(groupvars, collapse=" + "), sep=" ~ "))
    datac <- summaryBy(formula, data=data, FUN=c(length2,mean,sd), na.rm=na.rm)

    # Rename columns
    names(datac)[ names(datac) == paste(measurevar, ".mean", sep="") ] <- measurevar
    names(datac)[ names(datac) == paste(measurevar, ".sd", sep="") ] <- "sd"
    names(datac)[ names(datac) == paste(measurevar, ".length2", sep="") ] <- "N"
    
    datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
    
    # Confidence interval multiplier for standard error
    # Calculate t-statistic for confidence interval: 
    # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
    ciMult <- qt(conf.interval/2 + .5, datac$N-1)
    datac$ci <- datac$se * ciMult
    
    return(datac)
}

# =========================================================================================
# Plotting
# =========================================================================================

##
## Use splines to better fit the mu's
##
smooth.spline2 <- function(formula, data, ...) {
  mat <- model.frame(formula, data)

  smooth.spline(x=mat[, 2], y=mat[, 1], spar=0.15)
}

predictdf.smooth.spline <- function(model, xseq, se, level) {
  pred <- predict(model, xseq)
  data.frame(x = xseq, y = pred$y)
} 

##
## Compute the Y-break step automatically
##
y_break_step <- function(y,se) {
	possibility1 <- floor((max(y) + max(se))/100)*10
	possibility2 <- max(10,floor((max(y)-min(y))/20)*10) 
	result <- floor(mean(c(possibility1, possibility2))/10)*10 
	return(max(5,possibility1))
}

##
## Compute the Y-limit automatically
##
y_limit_top <- function(y,se) {
	break_step <- y_break_step(y,se)
	result <- (floor((max(y) + max(se))/break_step)*break_step) + break_step 
	return(result)
}

subplot <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)

mmplot <- function(p1, p2, p3, p4) {
    grid.newpage()
	Layout <- grid.layout(nrow = 2, ncol = 2, widths = unit(c(1, 1), 
		c("null", "null")), heights = unit(c(1, 1), c("null", "null")))
    pushViewport(viewport(layout = Layout))
#   grid.show.layout(Layout)
	
	print(p1, vp = subplot(1, 1))
    print(p2, vp = subplot(1, 2))
    print(p3, vp = subplot(2, 1))
    print(p4, vp = subplot(2, 2))
}

mmplot2 <- function(p1, p2, p3, p4, p5, p6) {
    grid.newpage()
	Layout <- grid.layout(nrow = 3, ncol = 2, widths = unit(c(1, 1), 
		c("null", "null")), heights = unit(c(1, 1, 1), c("null", "null", "null")))
    pushViewport(viewport(layout = Layout))
#   grid.show.layout(Layout)

	print(p1, vp = subplot(1, 1))
    print(p2, vp = subplot(1, 2))
    print(p3, vp = subplot(2, 1))
    print(p4, vp = subplot(2, 2))
    print(p5, vp = subplot(3, 1))
    print(p6, vp = subplot(3, 2))
}

plot_effects <- function(data,column,ylabel) {
	# plot effects for the different factors and levels
	method <- "boxplot"
	#method <- "jitter"
	alpha_den <- 8
	p1 <- qplot(x=No_databases,y=column,data=data,geom=method) + 
		xlab("Number of Databases") + ylab(ylabel) + theme_bw() + scale_y_log10() + geom_jitter(alpha=I(1/alpha_den)) 
	p2 <- qplot(x=No_middlewares,y=column,data=data,geom=method) + 
		xlab("Number of Middlewares") + ylab(ylabel) + theme_bw() + scale_y_log10() + geom_jitter(alpha=I(1/alpha_den))  
	p3 <- qplot(x=Partitioning,y=column,data=data,geom=method) + 
		xlab("Partitioning") + ylab(ylabel) + theme_bw() + scale_y_log10() + geom_jitter(alpha=I(1/alpha_den)) 
	p4 <- qplot(x=Queue_size,y=column,data=data,geom=method) + 
		xlab("Queue size") + ylab(ylabel) + theme_bw() + scale_y_log10() + geom_jitter(alpha=I(1/alpha_den)) 
	mmplot(p1,p2,p3,p4)
}

plot_interactions <- function(data,ylabel) {
	alpha_den <- 8
	data_sharding <- subset(data, data$Partitioning == "sharding")		
	data_replication <- subset(data, data$Partitioning == "replication")
	
	data_s <- ddply(data_sharding,.(No_middlewares,No_databases),summarise,Throughput=mean(Throughput))
	p1 <- ggplot(data_sharding, aes(x=No_middlewares,y=Throughput,colour=No_databases)) + 
    	geom_boxplot() + scale_y_log10() + opts(title="Sharding") +
    	geom_point(data=data_s, aes(y=Throughput)) + ylab(ylabel) +
    	geom_line(data=data_s, aes(y=Throughput,group=No_databases)) + 
    	theme_bw() + geom_jitter(alpha=I(1/alpha_den)) 
	data_s <- ddply(data_replication,.(No_middlewares,No_databases),summarise,Throughput=mean(Throughput))
	p2 <- ggplot(data_replication, aes(x=No_middlewares,y=Throughput,colour=No_databases)) + 
    	geom_boxplot() + scale_y_log10() +  opts(title="Replication") +
    	geom_point(data=data_s, aes(y=Throughput)) + ylab(ylabel) +
    	geom_line(data=data_s, aes(y=Throughput,group=No_databases)) + 
    	theme_bw() + geom_jitter(alpha=I(1/alpha_den)) 

	data_s <- ddply(data_sharding,.(No_middlewares,Queue_size),summarise,Throughput=mean(Throughput))
	p3 <- ggplot(data_sharding, aes(x=No_middlewares,y=Throughput,colour=Queue_size)) + 
    	geom_boxplot() + scale_y_log10() + opts(title="Sharding") +
    	geom_point(data=data_s, aes(y=Throughput)) + ylab(ylabel) +
    	geom_line(data=data_s, aes(y=Throughput,group=Queue_size)) + 
    	theme_bw() + geom_jitter(alpha=I(1/alpha_den)) 
	data_s <- ddply(data_replication,.(No_middlewares,Queue_size),summarise,Throughput=mean(Throughput))
	p4 <- ggplot(data_replication, aes(x=No_middlewares,y=Throughput,colour=Queue_size)) + 
    	geom_boxplot() + scale_y_log10() + opts(title="Replication") +
    	geom_point(data=data_s, aes(y=Throughput)) + ylab(ylabel) +
    	geom_line(data=data_s, aes(y=Throughput,group=Queue_size)) + 
    	theme_bw() + geom_jitter(alpha=I(1/alpha_den)) 

	data_s <- ddply(data_sharding,.(No_databases,Queue_size),summarise,Throughput=mean(Throughput))
	p5 <- ggplot(data_sharding, aes(x=No_databases,y=Throughput,colour=Queue_size)) + 
    	geom_boxplot() + scale_y_log10() + opts(title="Sharding") +
    	geom_point(data=data_s, aes(y=Throughput)) + ylab(ylabel) +
    	geom_line(data=data_s, aes(y=Throughput,group=Queue_size)) + 
    	theme_bw() + geom_jitter(alpha=I(1/alpha_den)) 
	data_s <- ddply(data_replication,.(No_databases,Queue_size),summarise,Throughput=mean(Throughput))
	p6 <- ggplot(data_replication, aes(x=No_databases,y=Throughput,colour=Queue_size)) + 
    	geom_boxplot() + scale_y_log10() + opts(title="Replication") +
    	geom_point(data=data_s, aes(y=Throughput)) + ylab(ylabel) +
    	geom_line(data=data_s, aes(y=Throughput,group=Queue_size)) + 
    	theme_bw() + geom_jitter(alpha=I(1/alpha_den)) 

	mmplot2(p1,p2,p3,p4,p5,p6)
}

pca.biplot <- function(PC, x="PC1", y="PC2") {
    # PC being a prcomp object
    data <- data.frame(obsnames=row.names(PC$x), PC$x)
    plot <- ggplot(data, aes_string(x=x, y=y)) + geom_text(alpha=.4, size=3, aes(label=obsnames))
    plot <- plot + geom_hline(aes(0), size=.2) + geom_vline(aes(0), size=.2)
    datapc <- data.frame(varnames=rownames(PC$rotation), PC$rotation)
    mult <- min(
        (max(data[,y]) - min(data[,y])/(max(datapc[,y])-min(datapc[,y]))),
        (max(data[,x]) - min(data[,x])/(max(datapc[,x])-min(datapc[,x])))
        )
    datapc <- transform(datapc,
            v1 = .7 * mult * (get(x)),
            v2 = .7 * mult * (get(y))
            )
    plot <- plot + coord_equal() + geom_text(data=datapc, aes(x=v1, y=v2, label=varnames), size = 5, vjust=1, color="red")
    plot <- plot + geom_segment(data=datapc, aes(x=0, y=0, xend=v1, yend=v2), arrow=arrow(length=unit(0.2,"cm")), alpha=0.75, color="red")
    plot
}

# =========================================================================================
# main
# =========================================================================================

#basedir <- "/Users/bravegag/code/asl11/data/2k-r1-20111112_data/"
#basedir <- "/Users/bravegag/code/asl11/data/"

# define the 2^k experimental design (factors and levels)
experiments <- expand.grid(no_databases   = c(1, 4), 
		   	  			   partitioning   = c("sharding", "replication"), 
		   	  			   no_middlewares = c(1, 2, 4), 
		   	  			   queue_size     = c(40, 100))
replications <- as.list(c(1))
throughput <- NULL
throughput_s <- NULL
response <- NULL
response_s <- NULL

# iterate all the experiments
for (j in 1:length(replications)) {
print(paste("****************************************************************************** "))
print(paste("                      Processing replication", replications[[j]]))
print(paste("****************************************************************************** "))
basedir <- paste("/Users/bravegag/code/asl11/data/2k-r", replications[[j]], "_", no_clients, "cl_data/",sep="")
for (i in 1:nrow(experiments)) {
    experiment <- experiments[i,]
	pattern <- paste("logs\\-.*\\-", no_clients,"cl\\-", 
		experiment$no_middlewares,"mw\\-", experiment$no_databases, "db\\-", 
			experiment$partitioning, "\\-", experiment$queue_size,"queue\\-client\\.dat",sep="")
	all_files <- dir(path=basedir, pattern=pattern)
	data_file <- all_files[1]
	
	if (is.na(data_file)) {
		print(paste("**", pattern, "is MISSING", "!"))
		next
	}
	
	df <- read.table(paste(basedir, data_file, sep=""))              # read the data as a data frame
	names(df)[names(df)=="V1"] <- "Time"
	names(df)[names(df)=="V2"] <- "Partitioning"
	names(df)[names(df)=="V3"] <- "Workload"
	names(df)[names(df)=="V4"] <- "Response_Time"
	head(df)
	
	print(paste("processing ", data_file, "... (min=", min(df$Time), ",max=", max(df$Time), ")",sep=""))

	# get rid of first and last n minutes 
	df <- subset(df, df$Time > warmup_cooldown_minutes)
	df <- subset(df, df$Time < (max(df$Time) - warmup_cooldown_minutes))
	df$Time_group <- floor(df$Time/sample_size) + 1               	# generate Time groups of "samples"

	# =========================================================================================
	# Throughput
	# =========================================================================================
	if (decouple) {
		dft <- aggregate(x=df$Time, by=list(df$Time_group,df$Workload), FUN=length)
		names(dft)[names(dft)=="Group.1"] <- "Time"           
		names(dft)[names(dft)=="Group.2"] <- "Workload"
		names(dft)[names(dft)=="x"] <- "Throughput"
		
	} else {
		dft <- aggregate(x=df$Time, by=list(df$Time_group), FUN=length)
		names(dft)[names(dft)=="Group.1"] <- "Time"           
		names(dft)[names(dft)=="x"] <- "Throughput"
		dft$Workload <- "All"
	}
	dft_s <- summarySE(dft, measurevar="Throughput", groupvars=c("Workload"))
	
	dft$No_databases <- as.factor(experiment$no_databases)
	dft$Partitioning <- experiment$partitioning
	dft$No_middlewares <- as.factor(experiment$no_middlewares)
	dft$Queue_size <- as.factor(experiment$queue_size)
	dft$No_clients <- as.factor(no_clients)
	dft$Experimental_error <- as.factor(replications[[j]])

	dft_s$No_databases <- as.factor(experiment$no_databases)
	dft_s$Partitioning <- experiment$partitioning
	dft_s$No_middlewares <- as.factor(experiment$no_middlewares)
	dft_s$Queue_size <- as.factor(experiment$queue_size)
	dft_s$No_clients <- as.factor(no_clients)
	dft_s$Experimental_error <- as.factor(replications[[j]])
		
	if (is.null(throughput)) {
		throughput <- dft
		throughput_s <- dft_s
	} else {
		throughput <- rbind(throughput, dft)
		throughput_s <- rbind(throughput_s, dft_s)	
	}

	# =========================================================================================
	# Response Time
	# =========================================================================================
	dfr <- df
	if (decouple) {
		dfr <- aggregate(x=df$Response_Time, by=list(df$Time_group,df$Workload), FUN=mean)
		names(dfr)[names(dfr)=="Group.1"] <- "Time"           
		names(dfr)[names(dfr)=="Group.2"] <- "Workload"
		names(dfr)[names(dfr)=="x"] <- "Response_Time"
		dfr_s <- summarySE(dfr, measurevar="Response_Time", groupvars=c("Workload"))
		
	} else {
		dfr <- aggregate(x=df$Response_Time, by=list(df$Time_group), FUN=mean)
		names(dfr)[names(dfr)=="Group.1"] <- "Time"           
		names(dfr)[names(dfr)=="x"] <- "Response_Time"		
		dfr$Time_group <- 1
		dfr_s <- summarySE(dfr, measurevar="Response_Time", groupvars=c("Time_group"))
	}

	dfr$No_databases <- as.factor(experiment$no_databases)
	dfr$Partitioning <- experiment$partitioning
	dfr$No_middlewares <- as.factor(experiment$no_middlewares)
	dfr$Queue_size <- as.factor(experiment$queue_size)
	dfr$No_clients <- as.factor(no_clients)
	dfr$Experimental_error <- as.factor(replications[[j]])

	dfr_s$No_databases <- as.factor(experiment$no_databases)
	dfr_s$Partitioning <- experiment$partitioning
	dfr_s$No_middlewares <- as.factor(experiment$no_middlewares)
	dfr_s$Queue_size <- as.factor(experiment$queue_size)
	dfr_s$No_clients <- as.factor(no_clients)
	dfr_s$Experimental_error <- as.factor(replications[[j]])

	if (is.null(response)) {
		response <- dfr
		response_s <- dfr_s
	} else {
		response <- rbind(response, dfr)
		response_s <- rbind(response_s, dfr_s)
	}
}}

if (decouple) {
	if (workload == "Q1") {
		throughput <- subset(throughput, throughput$Workload == workload)
		response <- subset(response, response$Workload == workload)
	} else {
		throughput <- subset(throughput, !(throughput$Workload == workload))		
		response <- subset(response, !(response$Workload == workload))		
	}
}

# =========================================================================================
# Throughput
# =========================================================================================

# drop unnecessary columns
drops <- c("Time_group","N", "No_clients")
throughput_s <- throughput_s[,!(names(throughput_s) %in% drops)]
throughput_s <- throughput_s[with(throughput_s, order(-Throughput, sd, se)), ]

# run ANOVA on the Throughput
#throughput_s.aov <- aov(log(Throughput)~No_databases+Partitioning+No_middlewares+Queue_size,data=throughput_s)
str(throughput)
head(throughput)

throughput.aov <- aov(log(Throughput)~(No_databases*No_middlewares)+Partitioning+Queue_size+
						Experimental_error, data=throughput)
summary(throughput.aov)
coef(throughput.aov)
                             # Df Sum Sq Mean Sq   F value    Pr(>F)    
# No_databases                  1 960.61  960.61 1079.8361 < 2.2e-16 ***
# No_middlewares                2  53.48   26.74   30.0572 2.248e-13 ***
# Partitioning                  1  31.71   31.71   35.6498 3.360e-09 ***
# Queue_size                    1   3.45    3.45    3.8802   0.04915 *  
# Experimental_error            1   5.36    5.36    6.0219   0.01431 *  
# No_databases:No_middlewares   2 295.43  147.71  166.0468 < 2.2e-16 ***
# Residuals                   928 825.54    0.89                        
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1 
# > coef(throughput.aov)
                  # (Intercept)                 No_databases4               No_middlewares2 
                    # 5.7970922                     0.4420483                    -1.9851522 
              # No_middlewares4       Partitioningreplication                 Queue_size100 
                   # -1.2207142                     0.3354844                     0.1559241 
          # Experimental_error2 No_databases4:No_middlewares2 No_databases4:No_middlewares4 
                   # -0.1188325                     2.7077888                     1.9333240 


# print the coefficients of the model
alias(throughput.aov)
# table of effects
model.tables(throughput.aov,type="means",se=TRUE)
effects(throughput.aov)
dev.new()
par(mfrow=c(2,2))
plot(throughput.aov)
dev.new()
par(mfrow=c(2,2))
plot(TukeyHSD(throughput.aov,c("No_databases", "No_middlewares", "Partitioning", "Queue_size"),ordered=TRUE))

# build table of percent of variations
dfv <- data.frame(factor=c('No_databases','No_middlewares','Partitioning','Queue_size',
						   'Experimental_error','No_databases:No_middlewares','Residuals'),
                  ss=c(960.61,53.48,31.71,3.45,5.36,295.43,825.54))                  
dfv$percent <- (dfv$ss / sum(dfv$ss)) * 100
dfv

# or
throughput.fit <- glm(log(Throughput)~(No_databases*No_middlewares)+Partitioning+Queue_size+Experimental_error,
					data=throughput)
throughput.fit
summary(throughput.fit)
dev.new()
par(mfrow=c(2,2))
plot(throughput.fit)
throughput.aov <- anova(throughput.fit)
throughput.aov
plot(throughput)
abline(reg=throughput.fit,lty=1)
dfc <- summarySE(throughput, measurevar="Throughput", groupvars=c("Time", "No_databases"))
dev.new()
p <- ggplot(dfc, aes(x=Time,y=Throughput,colour=No_databases,group=No_databases,shape=No_databases))
p + geom_point(fill="white", size=3) + geom_errorbar(aes(ymin=Throughput-se, ymax=Throughput+se), width=.5) +
    theme_bw() + xlab("Minute") + ylab("Throughput (rpm)") + geom_point(data=throughput,fill="white",size=1) +
    stat_smooth(method="smooth.spline2",se=FALSE) + opts(title="2^k*r Throughput") +
    scale_y_continuous(breaks=seq(0,y_limit_top(dfc$Throughput,dfc$se), y_break_step(dfc$Throughput,dfc$se)), limits=c(0, y_limit_top(dfc$Throughput,dfc$se))) + 
    scale_x_continuous(breaks=0:max(dfc$Time)+1, labels=as.character(0:max(dfc$Time)*sample_size), limits=c(0, max(dfc$Time)+1)) +
    geom_vline(xintercept = min(dfc$Time)-1, linetype=2) + 
    geom_vline(xintercept = max(dfc$Time)+1, linetype=2)

dev.new()
plot_effects(data=throughput,column=throughput$Throughput,ylabel="Throughput (rpm)")
dev.new()
plot_interactions(data=throughput,ylabel="Throughput (rpm)")

# =========================================================================================
# Response Time
# =========================================================================================

# drop unnecessary columns
drops <- c("Time_group","N", "No_clients")
response_s <- response_s[,!(names(response_s) %in% drops)]
response_s <- response_s[with(response_s, order(Response_Time, sd, se)), ]

# check the pairs plot 
#pairs(Response_Time~No_databases+Partitioning+No_middlewares+Queue_size,data=response)

# run ANOVA on the Response Time
response.aov <- aov(log(Response_Time)~No_databases+Partitioning+No_middlewares+Queue_size,data=response)
#response.aov <- aov(log(Response_Time)~No_databases*Partitioning*No_middlewares*Queue_size,data=response)
summary(response.aov)
# print the coefficients of the model
coef(response.aov)
model.tables(response.aov,type="effects",se=TRUE)
dev.new()
par(mfrow=c(2,2))
plot(response.aov)
dev.new()
par(mfrow=c(2,2))
plot(TukeyHSD(response.aov,ordered=TRUE))
# or
response.anova <- anova(lm(Response_Time~No_databases+Partitioning+No_middlewares+Queue_size,data=response))
response.anova

dev.new()
plot_effects(data=response,column=response$Response_Time,ylabel="Response Time (ms)")

# # try using PCA
# drops <- c("Time","Workload", "No_clients","Experimental_error")
# throughput2 <- throughput[,!(names(throughput) %in% drops)]
# throughput2$Throughput <- log(throughput$Throughput)
# throughput2$No_databases <- as.numeric(throughput$No_databases)
# throughput2$Partitioning <- as.numeric(throughput$Partitioning)
# throughput2$No_middlewares <- as.numeric(throughput$No_middlewares)
# throughput2$Queue_size <- as.numeric(throughput$Queue_size)
# throughput2.pca <- prcomp(~No_databases+Partitioning+No_middlewares+Queue_size,data=throughput2,, retx=TRUE, center=TRUE)
# str(throughput2.pca)
# summary(throughput2.pca)
# dev.new()
# plot(throughput2.pca)
# dev.new()
# pca.biplot(throughput2.pca)

# check the pairs plot 
#pairs(Throughput~No_databases+Partitioning+No_middlewares+Queue_size,data=throughput)

# remove outliers
#throughput <- throughput[c(-18,-19,-20,-100,-250,-251,-252,-420),]

# toothInt <- ddply(ToothGrowth,.(dose,supp),summarise,val= mean(len))
# p <- ggplot(ToothGrowth, aes(x=factor(dose),y=len,colour=supp)) + 
		# geom_boxplot() + geom_point(data = toothInt, aes(y = val)) + 
		# geom_line(data = toothInt, aes(y = val, group = supp)) + 
		# theme_bw()

