# =========================================================================================
# Advanced Systems Lab 
# Milestone 2: Scale up plot
# Author: Giovanni Azua
# Date: 17 November 2011
# =========================================================================================

rm(list=ls())                                                        # clear workspace

library(boot)                                                        # use boot library
library(ggplot2)                                                     # use ggplot2 library
library(doBy)                                                        # use doBy library

# =========================================================================================
# Parameters
# =========================================================================================

decouple <- FALSE
warmup_cooldown_minutes <- 4

# =========================================================================================
# Define utility functions
# =========================================================================================

## ************************************ COPIED FROM ********************************************
## http://wiki.stdout.org/rcookbook/Graphs/Plotting%20means%20and%20error%20bars%20%28ggplot2%29
## *********************************************************************************************
## Summarizes data.
## Gives count, mean, standard deviation, standard error of the mean, and confidence interval (default 95%).
## If there are within-subject variables, calculate adjusted values using method from Morey (2008).
##   data: a data frame.
##   measurevar: the name of a column that contains the variable to be summariezed
##   groupvars: a vector containing names of columns that contain grouping variables
##   na.rm: a boolean that indicates whether to ignore NA's
##   conf.interval: the percent range of the confidence interval (default is 95%)
##
summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE, conf.interval=.95) {
    require(doBy)

    # New version of length which can handle NA's: if na.rm==T, don't count them
    length2 <- function (x, na.rm=FALSE) {
        if (na.rm) 
        	sum(!is.na(x))
        else   
        	length(x)
    }

    # Collapse the data
    formula <- as.formula(paste(measurevar, paste(groupvars, collapse=" + "), sep=" ~ "))
    datac <- summaryBy(formula, data=data, FUN=c(length2,mean,sd), na.rm=na.rm)

    # Rename columns
    names(datac)[ names(datac) == paste(measurevar, ".mean", sep="") ] <- measurevar
    names(datac)[ names(datac) == paste(measurevar, ".sd", sep="") ] <- "sd"
    names(datac)[ names(datac) == paste(measurevar, ".length2", sep="") ] <- "N"
    
    datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
    
    # Confidence interval multiplier for standard error
    # Calculate t-statistic for confidence interval: 
    # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
    ciMult <- qt(conf.interval/2 + .5, datac$N-1)
    datac$ci <- datac$se * ciMult
    
    return(datac)
}

##
## Use splines to better fit the mu's
##
smooth.spline2 <- function(formula, data, ...) {
  mat <- model.frame(formula, data)

  smooth.spline(x=mat[, 2], y=mat[, 1], spar=0.15)
}

predictdf.smooth.spline <- function(model, xseq, se, level) {
  pred <- predict(model, xseq)
  data.frame(x = xseq, y = pred$y)
} 

##
## Compute the Y-break step automatically
##
y_break_step <- function(y,se) {
	possibility1 <- floor((max(y) + max(se))/100)*10
	possibility2 <- max(10,floor((max(y)-min(y))/20)*10) 
	result <- floor(mean(c(possibility1, possibility2))/10)*10 
	return(max(1,possibility1))
}

##
## Compute the Y-limit automatically
##
y_limit_top <- function(y,se) {
	break_step <- y_break_step(y,se)
	result <- (floor((max(y) + max(se))/break_step)*break_step) + break_step 
	return(result)
}

# =========================================================================================
# main
# =========================================================================================

# data directory
#basedir <- "/Users/bravegag/code/asl11/data/speed_scale_20111117_data/"
basedir <- "/Users/bravegag/code/asl11/data/speed_scale_replication_20111203_data/"

# =========================================================================================
# Scale up
# =========================================================================================

No_databases <- c(1, 2, 4)
Scale <- c(0.1, 0.2, 0.4)
response <- NULL
for (i in 1:3) {
	pattern <- paste("scale_up\\-", No_databases[i], "db\\-", Scale[i], "scale\\-.*-client\\.dat",sep="")
	all_files <- dir(path=basedir, pattern=pattern)
	file_name <- all_files[1]

	print(paste("processing", file_name, "..."))

	df <- read.table(paste(basedir, file_name, sep=""))              # read the data as a data frame
	names(df)[names(df)=="V1"] <- "Time"
	names(df)[names(df)=="V2"] <- "Partitioning"
	names(df)[names(df)=="V3"] <- "Workload"
	names(df)[names(df)=="V4"] <- "Y"

	# get rid of first and last n minutes 
	df <- subset(df, df$Time > warmup_cooldown_minutes)
	df <- subset(df, df$Time < (max(df$Time) - warmup_cooldown_minutes))
	
	# =========================================================================================
	# Response Time
	# =========================================================================================
	dfr <- df
	if (!decouple) {
		dfr$Workload <- "All"
	}
	dfr <- summarySE(dfr, measurevar="Y", groupvars=c("Workload"))
	dfr$No_databases <- No_databases[i]
	dfr$Scale <- Scale[i]
	if (is.null(response)) {
		response <- dfr
	} else {
		response <- rbind(response, dfr)
	}
}

#dfr <- response[-1,]
dfr <- response

# add the constant scale up
temp <- dfr
temp$Workload <- "Ideal (constant)"
temp$Y <- 11340
temp$se <- 0
dfr <- rbind(dfr, temp)

# show the plot in a new window
dev.new()
# mu + se error bar
p <- ggplot(dfr, aes(x=No_databases, y=Y, group=Workload, shape=Workload, colour=Workload)) 
title <- paste("Scale Up: 2x Middlewares, Replication, Queue Size 100")
p + geom_point(fill="white", size=3) + geom_line() + geom_errorbar(aes(ymin=Y-se, ymax=Y+se)) + 
    theme_bw() + xlab(paste("Number of Databases - Scale factor")) + ylab("Response Time (ms)") + 
    scale_y_continuous(breaks=seq(0,y_limit_top(dfr$Y,0), y_break_step(dfr$Y,0)), limits=c(0, y_limit_top(dfr$Y,0))) + opts(title=title) + 
    scale_x_continuous(breaks=seq(0,length(dfr$No_databases)/2), labels=c(as.character(0),"1 - 0.1","2 - 0.2","4 - 0.4"), limits=c(0, max(dfr$No_databases)+1)) 

