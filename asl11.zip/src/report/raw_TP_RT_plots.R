# =========================================================================================
# Advanced Systems Lab 
# Milestone 2: Plots the results of the n_clients experiment
# Author: Giovanni Azua
# Date: 08 November 2011
# =========================================================================================

rm(list=ls())                                                        # clear workspace

library(boot)                                                        # use boot library
library(ggplot2)                                                     # use ggplot2 library
library(doBy)                                                        # use doBy library

# =========================================================================================
# Parameters
# =========================================================================================

decouple <- FALSE
warmup_cooldown_minutes <- 0

# given a directory name, it will iterate all files that match the given pattern
#basedir <- "/Users/bravegag/code/asl11/data/"
#basedir <- "/Users/bravegag/code/asl11/data/2k-r1-20111112_data/"
#basedir <- "/Users/bravegag/code/asl11/data/nclients_2_128-20111110_data/"
#basedir <- "/Users/bravegag/code/asl11/data/speed_scale_20111117_data/"

#pattern <- paste("logs.*64cl\\-.*mw\\-.*db\\-.*\\-.*queue\\-client\\.dat",sep="")
#pattern <- paste("logs.*64cl\\-.*mw\\-4db\\-sharding\\-100queue\\-client\\.dat",sep="")
#pattern <- paste("logs.*cl\\-.*mw\\-.*db\\-.*\\-client\\.dat",sep="")
#pattern <- paste("scale_out.*\\-client\\.dat",sep="")

basedir <- "/Users/bravegag/code/asl11/data/nclients_2_256-replication-20111102_data/"
#basedir <- "/Users/bravegag/code/asl11/data/2k-r1_64cl_data/"
pattern <- paste(".*-client.dat",sep="")
#pattern <- paste("stress\\_20111118\\-134020\\-256cl\\-2mw\\-4db\\-replication\\-100queue\\-client.dat",sep="")

# =========================================================================================
# Define utility functions
# =========================================================================================

## ************************************ COPIED FROM ********************************************
## http://wiki.stdout.org/rcookbook/Graphs/Plotting%20means%20and%20error%20bars%20%28ggplot2%29
## *********************************************************************************************
## Summarizes data.
## Gives count, mean, standard deviation, standard error of the mean, and confidence interval (default 95%).
## If there are within-subject variables, calculate adjusted values using method from Morey (2008).
##   data: a data frame.
##   measurevar: the name of a column that contains the variable to be summariezed
##   groupvars: a vector containing names of columns that contain grouping variables
##   na.rm: a boolean that indicates whether to ignore NA's
##   conf.interval: the percent range of the confidence interval (default is 95%)
##
summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE, conf.interval=.95) {
    require(doBy)

    # New version of length which can handle NA's: if na.rm==T, don't count them
    length2 <- function (x, na.rm=FALSE) {
        if (na.rm) 
        	sum(!is.na(x))
        else   
        	length(x)
    }

    # Collapse the data
    formula <- as.formula(paste(measurevar, paste(groupvars, collapse=" + "), sep=" ~ "))
    datac <- summaryBy(formula, data=data, FUN=c(length2,mean,sd), na.rm=na.rm)

    # Rename columns
    names(datac)[ names(datac) == paste(measurevar, ".mean", sep="") ] <- measurevar
    names(datac)[ names(datac) == paste(measurevar, ".sd", sep="") ] <- "sd"
    names(datac)[ names(datac) == paste(measurevar, ".length2", sep="") ] <- "N"
    
    datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
    
    # Confidence interval multiplier for standard error
    # Calculate t-statistic for confidence interval: 
    # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
    ciMult <- qt(conf.interval/2 + .5, datac$N-1)
    datac$ci <- datac$se * ciMult
    
    return(datac)
}

##
## Use splines to better fit the mu's
##
smooth.spline2 <- function(formula, data, ...) {
  mat <- model.frame(formula, data)

  smooth.spline(x=mat[, 2], y=mat[, 1], spar=0.15)
}

predictdf.smooth.spline <- function(model, xseq, se, level) {
  pred <- predict(model, xseq)
  data.frame(x = xseq, y = pred$y)
} 

##
## Compute the Y-break step automatically
##
y_break_step <- function(y,se) {
	possibility1 <- floor((max(y) + max(se))/100)*10
	possibility2 <- max(10,floor((max(y)-min(y))/20)*10) 
	result <- floor(mean(c(possibility1, possibility2))/10)*10 
	return(max(5,possibility1))
}

##
## Compute the Y-limit automatically
##
y_limit_top <- function(y,se) {
	break_step <- y_break_step(y,se)
	result <- (floor((max(y) + max(se))/break_step)*break_step) + break_step 
	return(result)
}

plot_raw <- function(data,connect=TRUE,y_break=500,y_top=-1,label="",ylab="") {
	dev.new()
	title <- paste(label, sep="")
	if (y_top == -1) {
		y_top <- max(data$Y)		
	}
	
	if (!decouple) {
		# add fake group
		data$Workload <- 'All'
	}
	
	p <- ggplot(data,aes(x=Time,y=Y,group=Workload,shape=Workload,colour=Workload)) + ylab(ylab) +
		geom_point(fill="white", size=3) + scale_y_continuous(breaks=seq(0,max(data$Y),y_break), limits=c(0, y_top)) + 
		scale_y_continuous(breaks=seq(0,y_limit_top(data$Y,data$se), y_break_step(data$Y,data$se)), 
				limits=c(0, y_limit_top(data$Y,data$se))) + 
    	opts(title=title) + theme_bw() + geom_errorbar(aes(ymin=Y-se, ymax=Y+se), width=.5)
    	scale_x_continuous(breaks=data$Time, labels=as.character(data$Time))		 

    if (connect) {
    	print(p + geom_line())
    } else {
    	print(p)
    }
}

# =========================================================================================
# main
# =========================================================================================

all_files <- dir(path=basedir, pattern=pattern)

throughput <- NULL
response <- NULL

#file_name <- all_files[1]

# iterate all clients
for (file_name in all_files) {
	print(paste("processing", file_name, "..."))

	df <- read.table(paste(basedir, file_name, sep=""))              # read the data as a data frame
	names(df)[names(df)=="V1"] <- "Time"
	names(df)[names(df)=="V2"] <- "Partitioning"
	names(df)[names(df)=="V3"] <- "Workload"
	names(df)[names(df)=="V4"] <- "Y"

	# get rid of first and last n minutes 
	df <- subset(df, df$Time > warmup_cooldown_minutes)
	df <- subset(df, df$Time < (max(df$Time) - warmup_cooldown_minutes))
	print(paste("max time is ",max(df$Time)))
	
	# =========================================================================================
	# Throughput
	# =========================================================================================
	if (decouple) {
		dft <- aggregate(x=df$Time, by=list(df$Time,df$Workload), FUN=length)
		names(dft)[names(dft)=="Group.1"] <- "Time"           
		names(dft)[names(dft)=="Group.2"] <- "Workload"
		names(dft)[names(dft)=="x"] <- "Y"
		
	} else {
		dft <- aggregate(x=df$Time, by=list(df$Time), FUN=length)
		names(dft)[names(dft)=="Group.1"] <- "Time"           
		names(dft)[names(dft)=="x"] <- "Y"
	}
	dft$se <- 0
	plot_raw(dft,connect=TRUE,label=file_name,ylab="Throughput")

	# =========================================================================================
	# Response Time
	# =========================================================================================
	if (decouple) {
		dfr <- summarySE(df, measurevar="Y", groupvars=c("Time", "Workload"))
	} else {
		dfr <- summarySE(df, measurevar="Y", groupvars=c("Time"))
	}

	plot_raw(dfr,connect=TRUE,label=file_name,ylab="Response Time (ms)")
}