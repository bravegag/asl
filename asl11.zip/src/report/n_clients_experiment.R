# =========================================================================================
# Advanced Systems Lab 
# Milestone 1 : N Clients Experiment
# Author: Giovanni Azua
# Date: 22 October 2011
# =========================================================================================

rm(list=ls())                                                        # clear workspace

library(boot)                                                        # use boot library
library(ggplot2)                                                     # use ggplot2 library
library(doBy)                                                        # use doBy library

# =========================================================================================
# Parameters
# =========================================================================================

decouple <- FALSE
warmup_cooldown_minutes <- 5

# =========================================================================================
# Define utility functions
# =========================================================================================

## ************************************ COPIED FROM ********************************************
## http://wiki.stdout.org/rcookbook/Graphs/Plotting%20means%20and%20error%20bars%20%28ggplot2%29
## *********************************************************************************************
## Summarizes data.
## Gives count, mean, standard deviation, standard error of the mean, and confidence interval (default 95%).
## If there are within-subject variables, calculate adjusted values using method from Morey (2008).
##   data: a data frame.
##   measurevar: the name of a column that contains the variable to be summariezed
##   groupvars: a vector containing names of columns that contain grouping variables
##   na.rm: a boolean that indicates whether to ignore NA's
##   conf.interval: the percent range of the confidence interval (default is 95%)
##
summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE, conf.interval=.95) {
    require(doBy)

    # New version of length which can handle NA's: if na.rm==T, don't count them
    length2 <- function (x, na.rm=FALSE) {
        if (na.rm) 
        	sum(!is.na(x))
        else   
        	length(x)
    }

    # Collapse the data
    formula <- as.formula(paste(measurevar, paste(groupvars, collapse=" + "), sep=" ~ "))
    datac <- summaryBy(formula, data=data, FUN=c(length2,mean,sd), na.rm=na.rm)

    # Rename columns
    names(datac)[ names(datac) == paste(measurevar, ".mean", sep="") ] <- measurevar
    names(datac)[ names(datac) == paste(measurevar, ".sd", sep="") ] <- "sd"
    names(datac)[ names(datac) == paste(measurevar, ".length2", sep="") ] <- "N"
    
    datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
    
    # Confidence interval multiplier for standard error
    # Calculate t-statistic for confidence interval: 
    # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
    ciMult <- qt(conf.interval/2 + .5, datac$N-1)
    datac$ci <- datac$se * ciMult
    
    return(datac)
}

##
## Use splines to better fit the mu's
##
smooth.spline2 <- function(formula, data, ...) {
  mat <- model.frame(formula, data)

  smooth.spline(x=mat[, 2], y=mat[, 1], spar=0.3)
}

predictdf.smooth.spline <- function(model, xseq, se, level) {
  pred <- predict(model, xseq)
  data.frame(x = xseq, y = pred$y)
} 

##
## Compute the Y-break step automatically
##
y_break_step <- function(y,se) {
	possibility1 <- floor((max(y) + max(se))/100)*10
	possibility2 <- max(10,floor((max(y)-min(y))/20)*10) 
	result <- floor(mean(c(possibility1, possibility2))/10)*10 
	return(max(5,possibility1))
}

##
## Compute the Y-limit automatically
##
y_limit_top <- function(y,se) {
	break_step <- y_break_step(y,se)
	result <- (floor((max(y) + max(se))/break_step)*break_step) + break_step 
	return(result)
}

plot_experiment <- function(data,label,ylab,smooth=TRUE) {
	title_suffix <- paste("\nReplication ", no_middlewares, "x Middleware ", no_middlewares, "x Database",sep="")
	if (decouple) {
		title <- paste(label, title_suffix)
	} else {
		title <- paste(label, title_suffix)
	}

	# show the plot in new plot window
	dev.new()
	if (!decouple) {
		# add fake group
		data$Workload <- 'All'
	}
	p <- ggplot(data, aes(x=no_clients,y=Y,group=Workload,shape=Workload,colour=Workload)) 
	p <- p + geom_point(fill="white", size=3) + 
			geom_errorbar(aes(ymin=Y-se, ymax=Y+se)) +
    		theme_bw() + xlab(paste("# Clients")) + ylab(paste(label," (",ylab,")",sep="")) + 
			scale_y_continuous(breaks=seq(0,y_limit_top(data$Y,data$se), y_break_step(data$Y,data$se)), 
				limits=c(0, y_limit_top(data$Y,data$se))) + 
			opts(title=title) +
    		scale_x_continuous(breaks=data$no_clients, labels=as.character(data$no_clients), 
    			limits=c(0, max(data$no_clients)+5))
   	if (smooth) {
		p + geom_smooth(method="smooth.spline2",se=FALSE)

   	} else {
		p + geom_line()   		
   	}	 
}

# =========================================================================================
# main
# =========================================================================================

no_clients <- 2
no_middlewares <- 1
no_databases <- 1

#basedir <- "/Users/bravegag/code/asl11/data/nclients_2_128-20111110_data/"
basedir <- "/Users/bravegag/code/asl11/data/nclients_2_256-replication-20111102_data/"

#no_clients <- 2

throughput <- NULL
response <- NULL

# iterate all clients
for (no_clients in 2^seq(1,8)) {
	pattern <- paste("logs\\-.*\\-.*\\-", no_clients,"cl\\-", no_middlewares,"mw\\-", no_databases,  
		"db\\-replication\\-client\\.dat",sep="")
	all_files <- dir(path=basedir, pattern=pattern)
	data_file <- all_files[1]
	print(paste("processing", data_file, "..."))

	df <- read.table(paste(basedir, data_file, sep=""))              # read the data as a data frame
	names(df)[names(df)=="V1"] <- "Time"
	names(df)[names(df)=="V2"] <- "Partitioning"
	names(df)[names(df)=="V3"] <- "Workload"
	names(df)[names(df)=="V4"] <- "Runtime"
	head(df)
	
	# get rid of first and last n minutes 
	df <- subset(df, df$Time > warmup_cooldown_minutes)
	df <- subset(df, df$Time < (max(df$Time) - warmup_cooldown_minutes))
	
	# =========================================================================================
	# Throughput
	# =========================================================================================
	if (decouple) {
		dft <- aggregate(x=df$Runtime, by=list(df$Time,df$Workload), FUN=length)
		names(dft)[names(dft)=="Group.1"] <- "Time"           
		names(dft)[names(dft)=="Group.2"] <- "Workload"
		names(dft)[names(dft)=="x"] <- "Y"
		dft <- summarySE(dft, measurevar="Y", groupvars=c("Workload"))
		
	} else {
		dft <- aggregate(x=df$Runtime, by=list(df$Time), FUN=length)
		names(dft)[names(dft)=="Group.1"] <- "Time"           
		names(dft)[names(dft)=="x"] <- "Y"
		dft$Time_group <- 1
		dft <- summarySE(dft, measurevar="Y", groupvars=c("Time_group"))
	}
	dft$no_clients <- no_clients	
	if (is.null(throughput)) {
		throughput <- dft		
	} else {
		throughput <- rbind(throughput, dft)
	}

	# =========================================================================================
	# Response Time
	# =========================================================================================
	dfr <- df
	names(dfr)[names(dfr)=="Runtime"] <- "Y"
	if (decouple) {
		dfr <- summarySE(dfr, measurevar="Y", groupvars=c("Workload"))
		
	} else {
		dfr$Time_group <- 1
		dfr <- summarySE(dfr, measurevar="Y", groupvars=c("Time_group"))
	}
	dfr$no_clients <- no_clients
	if (is.null(response)) {
		response <- dfr		
	} else {
		response <- rbind(response, dfr)
	}
}

# drop unnecessary columns
drops <- c("Time_group","N")
throughput <- throughput[,!(names(throughput) %in% drops)]
response <- response[,!(names(response) %in% drops)]

plot_experiment(throughput,"Throughput","rpm",smooth=FALSE)

#response <- subset(response, !(response$no_clients == 128))

plot_experiment(response,"Response Time","ms",smooth=TRUE)

