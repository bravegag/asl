# =========================================================================================
# Advanced Systems Lab 
# Milestone 1
# Author: Giovanni Azua
# Date: 22 October 2011
# =========================================================================================

rm(list=ls())                                                        # clear workspace

library(boot)                                                        # use boot library
library(ggplot2)                                                     # use ggplot2 library
library(doBy)                                                        # use doBy library

# =========================================================================================
# Script parameters
# =========================================================================================

use_client <- TRUE
decouple <- FALSE
decouple2 <- FALSE
decouple_current <- "Replication"
decouple_current2 <- "Q1"
group_by_partitioning <- FALSE
group_by_workload <- FALSE
samples <- 10
warmup_cooldown_minutes <- 0

No_clients <- 256
No_middlewares <- 2
No_databases <- 4
Queue_size <- 100

#basedir <- "/Users/bravegag/code/asl11/data/nclients_2_128-20111104_data/"
#basedir <- "/Users/bravegag/code/asl11/data/"
basedir <- "/Users/bravegag/code/asl11/data/speed_scale_20111117_data/"

pattern <- paste("stress\\_20111118\\-134020\\-256cl\\-2mw\\-4db\\-replication\\-100queue\\-client.dat",sep="")
#pattern <- paste("logs\\-20111109\\-222207\\-128cl\\-1mw\\-1db\\-sharding\\-client\\.dat",sep="")
#pattern <- paste("logs\\-20111109\\-162702\\-128cl\\-1mw\\-1db\\-sharding\\-client\\.dat",sep="")
#pattern <- paste("logs\\-20111109\\-143958\\-128cl\\-1mw\\-1db\\-sharding\\-client\\.dat",sep="")

#pattern <- paste("logs\\-.*\\-.*\\-",No_clients,"cl\\-", No_middlewares,"mw\\-", No_databases, 
#	"db\\-sharding\\-client\\.dat",sep="")

if (use_client) {
	component <- "Client"
} else {
	component <- "Middleware"
}

# just to be sure
if (decouple) {
	group_by_partitioning <- FALSE
	group_by_workload <- TRUE
}

if (group_by_partitioning) {
	group_by_name <- "Partitioning"
} else
if (group_by_workload) {
	group_by_name <- "Workload"	
}

# =========================================================================================
# ETL Step
# =========================================================================================

all_files <- dir(path=basedir, pattern=pattern)
data_file <- all_files[1]
data_file

df <- read.table(paste(basedir, data_file, sep=""))                  # reads the data as data frame
class(df)                                                            # show the class to be 'list' 
names(df)                                                            # data is prepared correcly in Python
str(df)
head(df)

names(df)[names(df)=="V1"] <- "Time"                                 # change column names
names(df)[names(df)=="V2"] <- "Partitioning"
names(df)[names(df)=="V3"] <- "Workload"
names(df)[names(df)=="V4"] <- "Runtime"
str(df)

# get rid of first and last n minutes 
df <- subset(df, df$Time > warmup_cooldown_minutes)
df <- subset(df, df$Time < (max(df$Time) - warmup_cooldown_minutes))

if (decouple) {
	df <- subset(df, df$Partitioning == decouple_current)
	print(nrow(df) == nrow(subset(df, df$Partitioning == decouple_current)))
}

if (decouple2) {
	if (decouple_current2 == "Q1") {
		df <- subset(df, (df$Workload == decouple_current2))
		print(nrow(df) == nrow(subset(df, (df$Workload == decouple_current2))))		
	} else {
		df <- subset(df, !(df$Workload == "Q1"))
		print(nrow(df) == nrow(subset(df, !(df$Workload == "Q1"))))		
	}
}

head(df)

# =========================================================================================
# Define utility functions
# =========================================================================================

## ************************************ COPIED FROM ********************************************
## http://wiki.stdout.org/rcookbook/Graphs/Plotting%20means%20and%20error%20bars%20%28ggplot2%29
## *********************************************************************************************
## Summarizes data.
## Gives count, mean, standard deviation, standard error of the mean, and confidence interval (default 95%).
## If there are within-subject variables, calculate adjusted values using method from Morey (2008).
##   data: a data frame.
##   measurevar: the name of a column that contains the variable to be summariezed
##   groupvars: a vector containing names of columns that contain grouping variables
##   na.rm: a boolean that indicates whether to ignore NA's
##   conf.interval: the percent range of the confidence interval (default is 95%)
##
summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE, conf.interval=.95) {
    require(doBy)

    # New version of length which can handle NA's: if na.rm==T, don't count them
    length2 <- function (x, na.rm=FALSE) {
        if (na.rm) 
        	sum(!is.na(x))
        else   
        	length(x)
    }

    # Collapse the data
    formula <- as.formula(paste(measurevar, paste(groupvars, collapse=" + "), sep=" ~ "))
    datac <- summaryBy(formula, data=data, FUN=c(length2,mean,sd), na.rm=na.rm)

    # Rename columns
    names(datac)[ names(datac) == paste(measurevar, ".mean", sep="") ] <- measurevar
    names(datac)[ names(datac) == paste(measurevar, ".sd", sep="") ] <- "sd"
    names(datac)[ names(datac) == paste(measurevar, ".length2", sep="") ] <- "N"
    
    datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
    
    # Confidence interval multiplier for standard error
    # Calculate t-statistic for confidence interval: 
    # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
    ciMult <- qt(conf.interval/2 + .5, datac$N-1)
    datac$ci <- datac$se * ciMult
    
    return(datac)
}

##
## Use splines to better fit the mu's
##
smooth.spline2 <- function(formula, data, ...) {
  mat <- model.frame(formula, data)

  smooth.spline(x=mat[, 2], y=mat[, 1], spar=0.15)
}

predictdf.smooth.spline <- function(model, xseq, se, level) {
  pred <- predict(model, xseq)
  data.frame(x = xseq, y = pred$y)
} 

##
## Compute the Y-break step automatically
##
y_break_step <- function(y,se) {
	possibility1 <- floor((max(y) + max(se))/100)*10
	possibility2 <- max(10,floor((max(y)-min(y))/20)*10) 
	result <- floor(mean(c(possibility1, possibility2))/10)*10 
	return(max(5,possibility1))
}

##
## Compute the Y-limit automatically
##
y_limit_top <- function(y,se) {
	break_step <- y_break_step(y,se)
	result <- (floor((max(y) + max(se))/break_step)*break_step) + break_step 
	return(result)
}

plot_raw <- function(rawdata,connect=TRUE,y_break=500,y_top=-1,label="") {
	dev.new()
	title <- paste(label, " ", No_clients, "x Clients", sep="")
	if (y_top == -1) {
		y_top <- max(rawdata$Y)		
	}
	p <- ggplot(rawdata,aes(x=Time,y=Y)) + geom_point() + 
    		scale_y_continuous(breaks=seq(0,max(rawdata$Y),y_break), limits=c(0, y_top)) + 	
    		opts(title=title)
    if (connect) {
    	p + geom_line()
    } else {
    	p
    }
}

plot_raw_decoupled <- function(rawdata,connect=TRUE,y_break=500,y_top=-1,label="") {
	dev.new()
	title <- paste(label, " ", No_clients, "x Clients", sep="")
	if (y_top == -1) {
		y_top <- max(rawdata$Y)		
	}
	p <- ggplot(rawdata,aes(x=Time,y=Y,group=Workload,shape=Workload,colour=Workload)) + 
	     geom_point(fill="white", size=3) + scale_y_continuous(breaks=seq(0,max(rawdata$Y),y_break), limits=c(0, y_top)) + 	
    	 opts(title=title)
    if (connect) {
    	p + geom_line()
    } else {
    	p
    }
}

# =========================================================================================
# Prepare the Throughput data
# =========================================================================================

if (group_by_partitioning) {
	throughput <- aggregate(x=df$Runtime, by=list(df$Time,df$Partitioning), FUN=length)
	names(throughput)[names(throughput)=="Group.1"] <- "Time"           # change column names
	names(throughput)[names(throughput)=="Group.2"] <- group_by_name
	names(throughput)[names(throughput)=="x"] <- "Y"
	
} else 
if (group_by_workload) {
	throughput <- aggregate(x=df$Runtime, by=list(df$Time,df$Workload), FUN=length)
	names(throughput)[names(throughput)=="Group.1"] <- "Time"           # change column names
	names(throughput)[names(throughput)=="Group.2"] <- group_by_name
	names(throughput)[names(throughput)=="x"] <- "Y"

} else {
	throughput <- aggregate(x=df$Runtime, by=list(df$Time), FUN=length)
	names(throughput)[names(throughput)=="Runtime"] <- "Y"              # change column names	
	names(throughput)[names(throughput)=="Group.1"] <- "Time"           # change column names
	names(throughput)[names(throughput)=="x"] <- "Y"
}

throughput$Time_group <- floor(throughput$Time/samples) + 1             # generate Time groups of "samples"

if (group_by_partitioning || group_by_workload) {
	dfc <- summarySE(throughput, measurevar="Y", groupvars=c("Time_group", group_by_name),na.rm=TRUE)
} else {
	dfc <- summarySE(throughput, measurevar="Y", groupvars=c("Time_group"),na.rm=TRUE)
	dfc$Workload <- "All"
}

dfc$Time <- dfc$Time_group
dfc <- subset(dfc, !is.na(dfc$se))
last <- length(dfc$Time)
if (group_by_partitioning || group_by_workload) {
	dfc <- dfc[c(-1,-2,-3,-(last-2),-(last-1),-last),]	
} else {
	dfc <- dfc[c(-1,-last),]
}
head(dfc)

# mu + se error bar
if (group_by_partitioning) {
	p <- ggplot(dfc, aes(x=Time, y=Y, group=Partitioning, shape=Partitioning, colour=Partitioning))
} else {
	p <- ggplot(dfc, aes(x=Time, y=Y, group=Workload, shape=Workload, colour=Workload)) 
} 

title_suffix <- paste("\n", No_clients, "x Clients ", No_middlewares, "x Middlewares ", No_databases, "x Databases",sep="")
if (decouple) {
	title <- paste("Throughput Replication", component, decouple_current, title_suffix)
} else {
	title <- paste("Throughput Replication", component, title_suffix)
}

# show the plot in new plot window
dev.new()
p + geom_point(fill="white", size=3) +
    geom_line() + 
#   geom_smooth(method="smooth.spline2",se=FALSE) + 
    geom_errorbar(aes(ymin=Y-se, ymax=Y+se), width=.5, position="dodge") + 
    theme_bw() + xlab(paste("Minutes")) + ylab("Throughput (rpm)") + 
	scale_y_continuous(breaks=seq(0,y_limit_top(dfc$Y,dfc$se), y_break_step(dfc$Y,dfc$se)), limits=c(0, y_limit_top(dfc$Y,dfc$se))) + 
    opts(title=title) + 
    scale_x_continuous(breaks=0:max(dfc$Time)+1, labels=as.character(0:max(dfc$Time)*samples), limits=c(0, max(dfc$Time)+1)) +
    geom_vline(xintercept = min(dfc$Time)-1, linetype=2) + 
    geom_vline(xintercept = max(dfc$Time)+1, linetype=2)

# =========================================================================================
# Prepare the Response Time data
# =========================================================================================

runtime <- df
names(runtime)[names(runtime)=="Runtime"] <- "Y"
head(runtime)

runtime$Time_group <- floor(runtime$Time/samples) + 1                # generate Time groups of "samples"

if (group_by_partitioning || group_by_workload) {
	dfc <- summarySE(runtime, measurevar="Y", groupvars=c("Time_group", group_by_name))
} else {
	dfc <- summarySE(runtime, measurevar="Y", groupvars=c("Time_group"))
	dfc$Workload <- "All"
}

dfc$Time <- dfc$Time_group
dfc <- subset(dfc, !is.na(dfc$se))
last <- length(dfc$Time)
if (group_by_partitioning || group_by_workload) {
	dfc <- dfc[c(-1,-2,-3,-(last-2),-(last-1),-last),]	
} else {
	dfc <- dfc[c(-1,-2,-last),]
}
head(dfc)

# mu + se error bar
if (group_by_partitioning) {
	p <- ggplot(dfc, aes(x=Time, y=Y, group=Partitioning, shape=Partitioning, colour=Partitioning))
} else {
	p <- ggplot(dfc, aes(x=Time, y=Y, group=Workload, shape=Workload, colour=Workload))
}
 
title_suffix <- paste("\n", No_clients, "x Clients ", No_middlewares, "x Middlewares ", No_databases, "x Databases",sep="")
if (decouple) {
	title <- paste("Response Time Replication", component, decouple_current, title_suffix)
} else {
	title <- paste("Response Time Replication", component, title_suffix)
}

# show the plot in new plot window
dev.new()
p + geom_point(fill="white", size=3) + geom_errorbar(aes(ymin=Y-se, ymax=Y+se), width=.5) + 
    theme_bw() + xlab(paste("Minutes")) + ylab("Response Time (ms)") + 
    geom_line() + 
#   stat_smooth(method="smooth.spline2",se=FALSE) +
    scale_y_continuous(breaks=seq(0,y_limit_top(dfc$Y,dfc$se), y_break_step(dfc$Y,dfc$se)), limits=c(0, y_limit_top(dfc$Y,dfc$se))) + 
    opts(title=title) + 
    scale_x_continuous(breaks=0:max(dfc$Time)+1, labels=as.character(0:max(dfc$Time)*samples), limits=c(0, max(dfc$Time)+1)) +
    geom_vline(xintercept = min(dfc$Time)-1, linetype=2) + 
    geom_vline(xintercept = max(dfc$Time)+1, linetype=2)
    
