
# The errorbars overlapped, so use position_dodge to move them horizontally
pd <- position_dodge(.1) # move them .05 to the left and right

ggplot(dfc, aes(x=time, y=y)) + 
    geom_point(position=pd) +
    geom_line(position=pd) +
    geom_errorbar(aes(ymin=y-se, ymax=y+se),
                  width=.1, position=pd)


# Use 95% confidence interval instead of SEM
ggplot(dfc, aes(x=time, y=y)) + 
    geom_point(position=pd) +
    geom_line(position=pd) +
    geom_errorbar(aes(ymin=y-ci, ymax=y+ci),
                  width=.1, position=pd)














y.mu <- aggregate(x=throughput$y, by=list(throughput$group), FUN=mean)
y.sd <- aggregate(x=throughput$y, by=list(throughput$group), FUN=sd)
y.se <- aggregate(x=throughput$y, by=list(throughput$group), FUN=se)
y.ci  <- y.se * qt(0.95, degfree)

# get rid of last and first
last <- length(y.mu$x)
y.mu <- y.mu[-last,]
y.sd <- y.sd[-last,]
y.se <- y.se[-last,]
y.ci <- y.ci[-last,]
y.mu <- y.mu[-1,]
y.sd <- y.sd[-1,]
y.se <- y.se[-1,]
y.ci <- y.ci[-1,]

throughput_stats <- data.frame(x=seq(1,length(y.mu$x)), mu=y.mu$x, sd=y.sd$x, se=y.se$x, 
	ymin=y.mu$x-y.se$x, ymax=y.mu$x+y.se$x)
throughput_stats

color <- 'red'
p <- ggplot(throughput_stats, aes(x=x,y=mu))  
p + geom_point(colour=color) + geom_line(colour=color) + xlab("Minute") + ylab("Throughput (reqs/min)") + 
	geom_errorbar(aes(ymin=throughput_stats$ymin, ymax=throughput_stats$ymax), colour=color, width=0.5) 
	
#	+ scale_x_discrete(breaks=1:length(y.mu$x), labels=c('1','2','3','4','5','6','7','8','9','10','11'))
#	+ coord_cartesian(xlim = c(0, 13), ylim = c(0, 300))

# =========================================================================================
# Prepare the Runtime data
# =========================================================================================

runtime <- lapply(data, function(x) sum(x))