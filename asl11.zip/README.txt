Advanced Systems Lab (Fall 2011)
Class 2, Group 2:
    Giovanni Azua Garcia <azuagarg@student.ethz.ch>
    Zaheer Chothia <zchothia@student.ethz.ch>

--------------------------------------------------------------------------------

Overview
========
Our TPC-H system is implemented in Java and can be found in the 'trunk' directory.
In order to build the project you will need:
* Java SE 6+
  http://www.oracle.com/technetwork/java/javase/downloads/
* Apache Maven 3
  http://maven.apache.org/download.html

From the 'trunk' directory run:
  $ mvn clean install
This will download all dependencies, compile the source code, run tests and
package as a JAR file.  The build output can be found in the 'target' directory.

In addition, we have several supporting scripts to setup the database, run
experiments and analyze logs.  These are located in the directory 'trunk/scripts'.
To run these you will need:
* Python 2.6+ (not Python 3!)
  http://python.org/download/

The main script 'manage.py' has two sub-commands:
* 'setup': Compile and install PostgreSQL and TPC-H dbgen.
* 'initdb': Create a new database and populate it with data.
  This task entails:
  - Generating data with the TPC-H DBGEN tool:
    http://www.tpc.org/tpch/spec/tpch_2_14_0.tgz
  - Initializing a new database (initdb, createdb)
  - Importing the schema (dss.ddl) and setting table constraints (dss.ri).
    This will implicitly create a unique index on the primary key of each table.
  - 'VACUUM ANALYZE': examines tables and updates statistics used by the query planner.
* 'workload': Generate update workload.
  Runs DBGEN and modifies RF2 to delete all items inserted during RF1.

To run the experiment script ('experiment.py') you will need an SSH library.
Run the following from the 'trunk/scripts' directory:
  $ curl http://python-distribute.org/distribute_setup.py | python
  $ curl https://raw.github.com/pypa/pip/master/contrib/get-pip.py | python
  $ pip install virtualenv
  $ virtualenv --distribute venv
  $ . venv/bin/activate
  $ pip install -r venv-requirements.txt

zchothia: I have setup several useful tools on the cluster.  You can use my account
by following the instructions in 'trunk/scripts/sshkey/README'

--------------------------------------------------------------------------------

Port numbers
============
To avoid conflicts, we should prefix port numbers with our class/group number.
Please try to use the following port assignments:
  220xx: Database
  221xx: Middleware
  222xx: JVM Monitoring (Middleware)
  223xx: JVM Monitoring (Client)

Application parameters
======================
Simply running the JAR with no arguments will print the usage with expected
parameters and their default values.

Recommended heap sizes:
  Client:
    -Xms128m -Xmx512m
  Middleware:
    -Xms256m -Xmx1024m

JVM Notes
=========
For the default Oracle JVM or OpenJDK we use the following options:
  -server  # default on machine with 2 cores and at least 2 GB RAM
  -Xms128m  #  initial heap size (default: 1/64th of RAM)
  -Xmx1024m  #  maximum heap size (default: 1/4th of RAM up to 1 GB max)
  -XX:+AggressiveOpts  # enable optimizations expected to be on by default in upcoming releases
  -XX:+DoEscapeAnalysis
  -XX:+UseFastAccessorMethods
  -XX:+OptimizeStringConcat

References:
  Java HotSpot VM Options
    http://www.oracle.com/technetwork/java/javase/tech/vmoptions-jsp-140102.html
  Java Tuning White Paper
    http://www.oracle.com/technetwork/java/tuning-139912.html
  IBM developerWorks: Robust Java benchmarking, Part 1: Issues
    http://www.ibm.com/developerworks/java/library/j-benchmark1/

On the cluster machines we use the JRockit JVM and its excellent Mission Control
tool.  These are the default JVM flags we use:
  -server
  -Xms:128m  # initial and minimum heap size (default: 25% of free memory, at least 8 MB and up to 64 MB)
  -Xmx:1024m  # maximum heap size (default: 75% of RAM up to 3 GB on 64-bit platforms)
  -Xmanagement:ssl=false,authenticate=false,port=7099
  -XX:+FlightRecorder
  -XX:FlightRecorderOptions=defaultrecording=true,disk=true,dumponexit=true,dumponexitpath=flightRecording/success
  -XX:+FlightRecordingDumpOnUnhandledException
  -XX:FlightRecordingDumpPath=flightRecording/dump
  # Additional options - need experiments to ensure these don't interact with
  # our system in unknown ways:
  # -XX:+UseCallProfiling
  # -XX:+UseNewHashFunction
  #
  # -XXaggressive is not recommended for prodction use and has a different
  #               meaning compared to the default JVM.

Here are several interesting links:
  Download:
    http://www.oracle.com/technetwork/middleware/jrockit/downloads/
  Documentation:
    http://download.oracle.com/docs/cd/E15289_01/index.htm
  Command-Line Reference
    http://download.oracle.com/docs/cd/E15289_01/doc.40/e15062/toc.htm
  Migrating Applications to the JRockit JDK
    http://download.oracle.com/docs/cd/E15289_01/doc.40/e15058/migrate.htm#i1001048

NOTE: do not enable JMX (monitoring) for experiments as it can have an adverse
effect on performance.  For development, however, the profiler and tools in
JVisualVM are very handy:
  http://download.oracle.com/javase/6/docs/technotes/guides/visualvm/index.html
With JRockit this is not a concern since it piggybacks on data already needed
for the JIT compiler (typically < 1% overhead).

TODO:
* Do we need to specify -XX:StartFlightRecording=defaultrecording=true|false,filename=name,name=identifier
  -> it seems the new 'dumponexit' parameter in R28.1 does what we want.
* Tune the garbage collector:
  Default JVM:
    -XX:+UseParallelGC  # parallel (throughput) garbage collector
    -XX:+UseConcMarkSweepGC  # concurrent (low pause time) garbage collector
  JRockit:
    -Xgc:throughput (default) OR -Xgc:deterministic, ...
    http://download.oracle.com/docs/cd/E15289_01/doc.40/e15062/optionx.htm#i1011879

Tests on Cluster
================
NOTE: on the cluster machines you will need to skip tests by passing the flag
'-DskipTests' to Maven.  This is because the BlockingIOTest fails with the error
"Too many open files".  Explanation:
    $ sysctl -a | grep net.ipv4
      ...
      net.ipv4.ip_local_port_range = 32768    61000
      net.ipv4.tcp_fin_timeout = 60
      ...
We can only have (61000 - 32768) / 60 = 470 open connections at any given time.
